; ModuleID = 'start'
source_filename = "start"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-linux-gnu"

define void @cleanup(i64 zeroext %0, i64 zeroext %1, i64 zeroext %2) local_unnamed_addr {
top:
  %3 = inttoptr i64 %0 to i8*
  %4 = getelementptr i8, i8* %3, i64 24
  %coercion = bitcast i8* %4 to i64*
  %pointerref = load i64, i64* %coercion, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not = icmp eq i64 %pointerref, 0
  br i1 %.not, label %L19, label %L11

L11:                                              ; preds = %top
  %5 = inttoptr i64 %pointerref to i8*
  call fastcc void @julia_cleanup_2015u2017(i8* nonnull %5)
  br label %L19

L19:                                              ; preds = %L11, %top
  call fastcc void @julia_cleanup_2015u2017(i8* nonnull %3)
  %6 = inttoptr i64 %1 to i8*
  call fastcc void @julia_cleanup_2015u2019(i8* %6)
  %7 = inttoptr i64 %2 to i8*
  call fastcc void @julia_cleanup_2015u2020(i8* %7)
  call fastcc void @julia_cleanup_2015u2021()
  ret void
}

define internal fastcc void @julia_cleanup_2015u2017(i8* %ptr) unnamed_addr {
entry:
  call void @free(i8* %ptr)
  ret void
}

; Function Attrs: nounwind
declare void @free(i8*) local_unnamed_addr #0

define internal fastcc void @julia_cleanup_2015u2019(i8* %renderer) unnamed_addr {
entry:
  call void @SDL_DestroyRenderer(i8* %renderer)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_DestroyRenderer(i8*) local_unnamed_addr #0

define internal fastcc void @julia_cleanup_2015u2020(i8* %window) unnamed_addr {
entry:
  call void @SDL_DestroyWindow(i8* %window)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_DestroyWindow(i8*) local_unnamed_addr #0

define internal fastcc void @julia_cleanup_2015u2021() unnamed_addr {
entry:
  call void @SDL_Quit()
  ret void
}

; Function Attrs: nounwind
declare void @SDL_Quit() local_unnamed_addr #0

attributes #0 = { nounwind }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = !{!3, !3, i64 0}
!3 = !{!"jtbaa_data", !4, i64 0}
!4 = !{!"jtbaa", !5, i64 0}
!5 = !{!"jtbaa"}
!6 = !{!7}
!7 = !{!"jnoalias_data", !8}
!8 = !{!"jnoalias"}
!9 = !{!10, !11, !12, !13}
!10 = !{!"jnoalias_gcframe", !8}
!11 = !{!"jnoalias_stack", !8}
!12 = !{!"jnoalias_typemd", !8}
!13 = !{!"jnoalias_const", !8}
