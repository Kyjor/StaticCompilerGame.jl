; ModuleID = 'start'
source_filename = "start"
target datalayout = "e-m:o-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-apple-darwin"

define void @cleanup(i64 zeroext %0, i64 zeroext %1, i64 zeroext %2) local_unnamed_addr {
top:
  %3 = inttoptr i64 %0 to i8*
  %4 = getelementptr i8, i8* %3, i64 160
  %5 = bitcast i8* %4 to i64*
  %6 = load i64, i64* %5, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not = icmp eq i64 %6, 0
  br i1 %.not, label %L33, label %L11

L11:                                              ; preds = %top
  %7 = inttoptr i64 %6 to i64*
  %8 = load i64, i64* %7, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not11 = icmp eq i64 %8, 0
  br i1 %.not11, label %L29, label %L21

L21:                                              ; preds = %L11
  %9 = inttoptr i64 %8 to i8*
  call fastcc void @julia_cleanup_1880u1882(i8* nonnull %9)
  br label %L29

L29:                                              ; preds = %L21, %L11
  %10 = inttoptr i64 %6 to i8*
  call fastcc void @julia_cleanup_1880u1882(i8* nonnull %10)
  br label %L33

L33:                                              ; preds = %L29, %top
  %11 = getelementptr i8, i8* %3, i64 168
  %12 = bitcast i8* %11 to i64*
  %13 = load i64, i64* %12, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not3 = icmp eq i64 %13, 0
  br i1 %.not3, label %L65, label %L43

L43:                                              ; preds = %L33
  %14 = inttoptr i64 %13 to i64*
  %15 = load i64, i64* %14, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not10 = icmp eq i64 %15, 0
  br i1 %.not10, label %L61, label %L53

L53:                                              ; preds = %L43
  %16 = inttoptr i64 %15 to i8*
  call fastcc void @julia_cleanup_1880u1882(i8* nonnull %16)
  br label %L61

L61:                                              ; preds = %L53, %L43
  %17 = inttoptr i64 %13 to i8*
  call fastcc void @julia_cleanup_1880u1882(i8* nonnull %17)
  br label %L65

L65:                                              ; preds = %L61, %L33
  %18 = getelementptr i8, i8* %3, i64 176
  %19 = bitcast i8* %18 to i64*
  %20 = load i64, i64* %19, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not4 = icmp eq i64 %20, 0
  br i1 %.not4, label %L97, label %L75

L75:                                              ; preds = %L65
  %21 = inttoptr i64 %20 to i64*
  %22 = load i64, i64* %21, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not9 = icmp eq i64 %22, 0
  br i1 %.not9, label %L93, label %L85

L85:                                              ; preds = %L75
  %23 = inttoptr i64 %22 to i8*
  call fastcc void @julia_cleanup_1880u1882(i8* nonnull %23)
  br label %L93

L93:                                              ; preds = %L85, %L75
  %24 = inttoptr i64 %20 to i8*
  call fastcc void @julia_cleanup_1880u1882(i8* nonnull %24)
  br label %L97

L97:                                              ; preds = %L93, %L65
  %25 = getelementptr i8, i8* %3, i64 104
  %26 = bitcast i8* %25 to i64*
  %27 = load i64, i64* %26, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not5 = icmp eq i64 %27, 0
  br i1 %.not5, label %L135, label %L117

L117:                                             ; preds = %L97
  %28 = inttoptr i64 %27 to { i64, i32, i32, i32, i32, i32, i32, i8, i8 }*
  %.sroa.0.0..sroa_idx = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %28, i64 0, i32 0
  %.sroa.0.0.copyload = load i64, i64* %.sroa.0.0..sroa_idx, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.32.0..sroa_idx = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %28, i64 0, i32 7
  %.sroa.32.0.copyload = load i8, i8* %.sroa.32.0..sroa_idx, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %29 = and i8 %.sroa.32.0.copyload, 1
  %.not7 = icmp eq i8 %29, 0
  %.not8 = icmp eq i64 %.sroa.0.0.copyload, 0
  %or.cond = select i1 %.not7, i1 true, i1 %.not8
  br i1 %or.cond, label %L130, label %L127

L127:                                             ; preds = %L117
  %30 = inttoptr i64 %.sroa.0.0.copyload to i8*
  call fastcc void @julia_cleanup_1880u1888(i8* nonnull %30)
  br label %L130

L130:                                             ; preds = %L127, %L117
  %31 = inttoptr i64 %27 to i8*
  call fastcc void @julia_cleanup_1880u1882(i8* nonnull %31)
  br label %L135

L135:                                             ; preds = %L130, %L97
  %32 = getelementptr i8, i8* %3, i64 72
  %33 = bitcast i8* %32 to i64*
  %34 = load i64, i64* %33, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %35 = inttoptr i64 %34 to i8*
  call fastcc void @julia_cleanup_1880u1882(i8* %35)
  %36 = getelementptr i8, i8* %3, i64 64
  %37 = bitcast i8* %36 to i64*
  %38 = load i64, i64* %37, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %39 = inttoptr i64 %38 to i8*
  call fastcc void @julia_cleanup_1880u1882(i8* %39)
  %40 = getelementptr i8, i8* %3, i64 80
  %41 = bitcast i8* %40 to i64*
  %42 = load i64, i64* %41, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %43 = inttoptr i64 %42 to i8*
  call fastcc void @julia_cleanup_1880u1882(i8* %43)
  %44 = inttoptr i64 %1 to i8*
  call fastcc void @julia_cleanup_1880u1885(i8* %44)
  %45 = inttoptr i64 %2 to i8*
  call fastcc void @julia_cleanup_1880u1886(i8* %45)
  call fastcc void @julia_cleanup_1880u1887()
  ret void
}

define internal fastcc void @julia_cleanup_1880u1882(i8* %ptr) unnamed_addr {
entry:
  call void @free(i8* %ptr)
  ret void
}

; Function Attrs: nounwind
declare void @free(i8*) local_unnamed_addr #0

define internal fastcc void @julia_cleanup_1880u1885(i8* %renderer) unnamed_addr {
entry:
  call void @SDL_DestroyRenderer(i8* %renderer)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_DestroyRenderer(i8*) local_unnamed_addr #0

define internal fastcc void @julia_cleanup_1880u1886(i8* %window) unnamed_addr {
entry:
  call void @SDL_DestroyWindow(i8* %window)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_DestroyWindow(i8*) local_unnamed_addr #0

define internal fastcc void @julia_cleanup_1880u1887() unnamed_addr {
entry:
  call void @SDL_Quit()
  ret void
}

; Function Attrs: nounwind
declare void @SDL_Quit() local_unnamed_addr #0

define internal fastcc void @julia_cleanup_1880u1888(i8* %texture) unnamed_addr {
entry:
  call void @SDL_DestroyTexture(i8* %texture)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_DestroyTexture(i8*) local_unnamed_addr #0

attributes #0 = { nounwind }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = !{!3, !3, i64 0}
!3 = !{!"jtbaa_data", !4, i64 0}
!4 = !{!"jtbaa", !5, i64 0}
!5 = !{!"jtbaa"}
!6 = !{!7}
!7 = !{!"jnoalias_data", !8}
!8 = !{!"jnoalias"}
!9 = !{!10, !11, !12, !13}
!10 = !{!"jnoalias_gcframe", !8}
!11 = !{!"jnoalias_stack", !8}
!12 = !{!"jnoalias_typemd", !8}
!13 = !{!"jnoalias_const", !8}
!14 = !{!4, !4, i64 0}
!15 = !{!7, !11}
!16 = !{!10, !12, !13}
