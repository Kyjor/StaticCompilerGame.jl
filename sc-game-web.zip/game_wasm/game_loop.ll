; ModuleID = 'start'
source_filename = "start"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-linux-gnu"

@_j_const5 = private unnamed_addr constant [16 x i8] c"Selected: Sand\0A\00", align 1
@_j_const6 = private unnamed_addr constant [17 x i8] c"Selected: Water\0A\00", align 1
@_j_const8 = private unnamed_addr constant [17 x i8] c"Selected: Stone\0A\00", align 1
@_j_const9 = private unnamed_addr constant [17 x i8] c"Selected: Erase\0A\00", align 1
@_j_const10 = private unnamed_addr constant [19 x i8] c"Inexact conversion\00", align 1

define i64 @game_loop(i64 zeroext %0, i64 zeroext %1, i64 zeroext %2) local_unnamed_addr {
top:
  %3 = call fastcc i64 @julia_game_loop_1849u1851()
  %4 = inttoptr i64 %0 to i8*
  %5 = getelementptr i8, i8* %4, i64 8
  %coercion = bitcast i8* %5 to i64*
  %pointerref = load i64, i64* %coercion, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %6 = sub i64 %3, %pointerref
  %7 = uitofp i64 %6 to double
  %8 = call fastcc i64 @julia_game_loop_1849u1852()
  %9 = uitofp i64 %8 to double
  %10 = fdiv double %7, %9
  store i64 %3, i64* %coercion, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.inv = fcmp ogt double %10, 1.000000e-01
  %11 = select i1 %.inv, double 1.000000e-01, double %10
  call fastcc void @julia_handle_input_1870(i64 zeroext %0)
  call fastcc void @julia_update_physics_1868(i64 zeroext %0, double %11)
  call fastcc void @julia_render_simulation_1857(i64 zeroext %0, i64 zeroext %1)
  call fastcc void @julia_game_loop_1849u1856(i32 16)
  ret i64 %0
}

define internal fastcc i64 @julia_game_loop_1849u1851() unnamed_addr {
entry:
  %result = call i64 @SDL_GetPerformanceCounter()
  ret i64 %result
}

; Function Attrs: nounwind
declare i64 @SDL_GetPerformanceCounter() local_unnamed_addr #0

define internal fastcc i64 @julia_game_loop_1849u1852() unnamed_addr {
entry:
  %result = call i64 @SDL_GetPerformanceFrequency()
  ret i64 %result
}

; Function Attrs: nounwind
declare i64 @SDL_GetPerformanceFrequency() local_unnamed_addr #0

define internal fastcc void @julia_game_loop_1849u1856(i32 %ms) unnamed_addr {
entry:
  call void @SDL_Delay(i32 %ms)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_Delay(i32) local_unnamed_addr #0

define internal fastcc void @julia_render_simulation_1857(i64 zeroext %0, i64 zeroext %1) unnamed_addr {
top:
  %2 = inttoptr i64 %1 to i8*
  call fastcc void @julia_render_simulation_1857u1859(i8* %2, i8 50, i8 50, i8 64, i8 -1)
  call fastcc void @julia_render_simulation_1857u1860(i8* %2)
  %3 = inttoptr i64 %0 to i8*
  %4 = getelementptr i8, i8* %3, i64 24
  %coercion = bitcast i8* %4 to i64*
  %pointerref = load i64, i64* %coercion, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %5 = call fastcc i8* @julia_handle_input_1870u1872(i32 16)
  %coercion2 = inttoptr i64 %pointerref to i8*
  %coercion4 = bitcast i8* %5 to i32*
  %6 = getelementptr i8, i8* %5, i64 4
  %coercion5 = bitcast i8* %6 to i32*
  %coercion6 = getelementptr i8, i8* %5, i64 8
  %memcpy_refined_dst = bitcast i8* %coercion6 to i32*
  %coercion7 = getelementptr i8, i8* %5, i64 12
  %memcpy_refined_dst9 = bitcast i8* %coercion7 to i32*
  br label %L21.preheader

L21.preheader:                                    ; preds = %L77, %top
  %indvars.iv16 = phi i64 [ 0, %top ], [ %indvars.iv.next17, %L77 ]
  %7 = mul nuw nsw i64 %indvars.iv16, 160
  br label %L25

L25:                                              ; preds = %L75, %L21.preheader
  %indvars.iv = phi i64 [ 0, %L21.preheader ], [ %indvars.iv.next, %L75 ]
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %pointerref_idx = add nuw i64 %indvars.iv, %7
  %8 = getelementptr inbounds i8, i8* %coercion2, i64 %pointerref_idx
  %pointerref3 = load i8, i8* %8, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  switch i8 %pointerref3, label %L52 [
    i8 0, label %L75
    i8 1, label %L38
    i8 2, label %L44
    i8 3, label %L50
  ]

L38:                                              ; preds = %L25
  call fastcc void @julia_render_simulation_1857u1859(i8* %2, i8 -1, i8 -91, i8 0, i8 -1)
  br label %L52

L44:                                              ; preds = %L25
  call fastcc void @julia_render_simulation_1857u1859(i8* %2, i8 0, i8 121, i8 -15, i8 -1)
  br label %L52

L50:                                              ; preds = %L25
  call fastcc void @julia_render_simulation_1857u1859(i8* %2, i8 -126, i8 -126, i8 -126, i8 -1)
  br label %L52

L52:                                              ; preds = %L50, %L44, %L38, %L25
  %indvars.iv.tr = trunc i64 %indvars.iv to i32
  %9 = shl i32 %indvars.iv.tr, 2
  store i32 %9, i32* %coercion4, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %indvars.iv16.tr = trunc i64 %indvars.iv16 to i32
  %10 = shl i32 %indvars.iv16.tr, 2
  store i32 %10, i32* %coercion5, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i32 4, i32* %memcpy_refined_dst, align 1
  store i32 4, i32* %memcpy_refined_dst9, align 1
  call fastcc void @julia_render_simulation_1857u1863(i8* %2, i8* %5)
  br label %L75

L75:                                              ; preds = %L52, %L25
  %exitcond = icmp eq i64 %indvars.iv.next, 160
  br i1 %exitcond, label %L77, label %L25

L77:                                              ; preds = %L75
  %indvars.iv.next17 = add nuw nsw i64 %indvars.iv16, 1
  %exitcond19 = icmp eq i64 %indvars.iv.next17, 160
  br i1 %exitcond19, label %L79, label %L21.preheader

L79:                                              ; preds = %L77
  call fastcc void @julia_handle_input_1870u1883(i8* %5)
  call fastcc void @julia_render_simulation_1857u1867(i8* %2)
  ret void
}

define internal fastcc void @julia_render_simulation_1857u1859(i8* %renderer, i8 %r, i8 %g, i8 %b, i8 %a) unnamed_addr {
entry:
  %result = call i32 @SDL_SetRenderDrawColor(i8* %renderer, i8 %r, i8 %g, i8 %b, i8 %a)
  ret void
}

; Function Attrs: nounwind
declare i32 @SDL_SetRenderDrawColor(i8*, i8, i8, i8, i8) local_unnamed_addr #0

define internal fastcc void @julia_render_simulation_1857u1860(i8* %renderer) unnamed_addr {
entry:
  %result = call i32 @SDL_RenderClear(i8* %renderer)
  ret void
}

; Function Attrs: nounwind
declare i32 @SDL_RenderClear(i8*) local_unnamed_addr #0

; Function Attrs: nounwind
declare noalias i8* @malloc(i32) local_unnamed_addr #0

define internal fastcc void @julia_render_simulation_1857u1863(i8* %renderer, i8* %rect) unnamed_addr {
entry:
  %result = call i32 @SDL_RenderFillRect(i8* %renderer, i8* %rect)
  ret void
}

; Function Attrs: nounwind
declare i32 @SDL_RenderFillRect(i8*, i8*) local_unnamed_addr #0

; Function Attrs: nounwind
declare void @free(i8*) local_unnamed_addr #0

define internal fastcc void @julia_render_simulation_1857u1867(i8* %renderer) unnamed_addr {
entry:
  call void @SDL_RenderPresent(i8* %renderer)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_RenderPresent(i8*) local_unnamed_addr #0

define internal fastcc void @julia_update_physics_1868(i64 zeroext %0, double %1) unnamed_addr {
top:
  %coercion = inttoptr i64 %0 to double*
  %pointerref = load double, double* %coercion, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %2 = fadd double %pointerref, %1
  store double %2, double* %coercion, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %3 = fcmp uge double %2, 2.000000e-02
  br i1 %3, label %L22, label %common.ret

common.ret:                                       ; preds = %L472, %top
  ret void

L22:                                              ; preds = %top
  %4 = fadd double %2, -2.000000e-02
  store double %4, double* %coercion, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %5 = inttoptr i64 %0 to i8*
  %6 = getelementptr i8, i8* %5, i64 24
  %coercion7 = bitcast i8* %6 to i64*
  %pointerref8 = load i64, i64* %coercion7, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion10 = inttoptr i64 %pointerref8 to i8*
  %7 = getelementptr i8, i8* %5, i64 16
  %coercion41 = bitcast i8* %7 to i32*
  br label %L46.preheader

L46.preheader:                                    ; preds = %L472, %L22
  %indvars.iv228 = phi i64 [ 158, %L22 ], [ %indvars.iv.next229, %L472 ]
  %8 = mul nuw nsw i64 %indvars.iv228, 160
  %9 = add nuw nsw i64 %8, 161
  %10 = or i64 %8, 2
  br label %L50

L50:                                              ; preds = %L470, %L46.preheader
  %indvars.iv = phi i64 [ 0, %L46.preheader ], [ %indvars.iv.next, %L470 ]
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %11 = add nuw nsw i64 %indvars.iv.next, %8
  %pointerref_idx = add i64 %indvars.iv, %8
  %12 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx
  %pointerref11 = load i8, i8* %12, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  switch i8 %pointerref11, label %L470 [
    i8 1, label %L60
    i8 2, label %L222
  ]

L60:                                              ; preds = %L50
  %13 = add nuw nsw i64 %9, %indvars.iv
  %pointerref_idx12 = add nsw i64 %13, -1
  %14 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx12
  %pointerref14 = load i8, i8* %14, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  switch i8 %pointerref14, label %L109 [
    i8 0, label %L70
    i8 2, label %L89
    i8 3, label %L470
  ]

L70:                                              ; preds = %L60
  store i8 1, i8* %14, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L89:                                              ; preds = %L60
  store i8 1, i8* %14, align 1
  store i8 2, i8* %12, align 1
  br label %L470

L109:                                             ; preds = %L60
  %15 = icmp eq i64 %indvars.iv, 0
  br i1 %15, label %L141, label %L124

L124:                                             ; preds = %L109
  %16 = add nuw nsw i64 %indvars.iv, 160
  %17 = add nuw nsw i64 %16, %8
  %pointerref_idx113 = add nsw i64 %17, -1
  %18 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx113
  %pointerref115 = load i8, i8* %18, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %19 = icmp eq i8 %pointerref115, 0
  %20 = zext i1 %19 to i8
  %21 = icmp ugt i64 %indvars.iv, 158
  br i1 %21, label %L180.thread, label %L141

L141:                                             ; preds = %L124, %L109
  %value_phi116177 = phi i8 [ %20, %L124 ], [ 0, %L109 ]
  %22 = add nuw nsw i64 %indvars.iv, 162
  %23 = add nuw nsw i64 %22, %8
  %pointerref_idx117 = add nsw i64 %23, -1
  %24 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx117
  %pointerref119 = load i8, i8* %24, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %25 = icmp ne i8 %pointerref119, 0
  %.not171 = icmp eq i8 %value_phi116177, 0
  %or.cond = select i1 %.not171, i1 true, i1 %25
  br i1 %or.cond, label %L180, label %L144

L144:                                             ; preds = %L141
  %pointerref122 = load i32, i32* %coercion41, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %26 = mul i32 %pointerref122, 1103515245
  %27 = add i32 %26, 12345
  store i32 %27, i32* %coercion41, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %28 = and i32 %27, 1
  %.not173 = icmp eq i32 %28, 0
  %. = select i1 %.not173, i64 4294967295, i64 1
  %29 = add i64 %., %13
  %sext238 = shl i64 %29, 32
  %30 = ashr exact i64 %sext238, 32
  %pointerset_idx125 = add nsw i64 %30, -1
  %pointerset_ptr128 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerset_idx125
  store i8 1, i8* %pointerset_ptr128, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L180:                                             ; preds = %L141
  br i1 %.not171, label %L198, label %L180.L181_crit_edge

L180.L181_crit_edge:                              ; preds = %L180
  %.pre = add nuw nsw i64 %indvars.iv, 160
  %.pre231 = add nuw nsw i64 %.pre, %8
  %.pre233 = add nsw i64 %.pre231, -1
  br label %L181

L180.thread:                                      ; preds = %L124
  br i1 %19, label %L181, label %L470

L181:                                             ; preds = %L180.thread, %L180.L181_crit_edge
  %pointerset_idx133.pre-phi = phi i64 [ %.pre233, %L180.L181_crit_edge ], [ %pointerref_idx113, %L180.thread ]
  %pointerset_ptr136 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerset_idx133.pre-phi
  store i8 1, i8* %pointerset_ptr136, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L198:                                             ; preds = %L180
  br i1 %25, label %L470, label %L199

L199:                                             ; preds = %L198
  store i8 1, i8* %24, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L222:                                             ; preds = %L50
  %31 = add nuw nsw i64 %9, %indvars.iv
  %pointerref_idx20 = add nsw i64 %31, -1
  %32 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx20
  %pointerref22 = load i8, i8* %32, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not158 = icmp eq i8 %pointerref22, 0
  br i1 %.not158, label %L232, label %L248

L232:                                             ; preds = %L222
  store i8 2, i8* %32, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L248:                                             ; preds = %L222
  %33 = icmp eq i64 %indvars.iv, 0
  br i1 %33, label %L294, label %L270

L270:                                             ; preds = %L248
  %34 = add nuw nsw i64 %indvars.iv, 160
  %35 = add nuw nsw i64 %34, %8
  %pointerref_idx31 = add nsw i64 %35, -1
  %36 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx31
  %pointerref33 = load i8, i8* %36, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %37 = icmp eq i8 %pointerref33, 0
  %38 = zext i1 %37 to i8
  %39 = icmp ugt i64 %indvars.iv, 158
  br i1 %39, label %L333.thread, label %L294

L294:                                             ; preds = %L270, %L248
  %value_phi35194 = phi i8 [ %38, %L270 ], [ 0, %L248 ]
  %40 = add nuw nsw i64 %indvars.iv, 162
  %41 = add nuw nsw i64 %40, %8
  %pointerref_idx36 = add nsw i64 %41, -1
  %42 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx36
  %pointerref38 = load i8, i8* %42, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %43 = icmp ne i8 %pointerref38, 0
  %.not159 = icmp eq i8 %value_phi35194, 0
  %or.cond151 = select i1 %.not159, i1 true, i1 %43
  br i1 %or.cond151, label %L333, label %L297

L297:                                             ; preds = %L294
  %pointerref42 = load i32, i32* %coercion41, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %44 = mul i32 %pointerref42, 1103515245
  %45 = add i32 %44, 12345
  store i32 %45, i32* %coercion41, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %46 = and i32 %45, 1
  %.not161 = icmp eq i32 %46, 0
  %.152 = select i1 %.not161, i64 4294967295, i64 1
  %47 = add i64 %.152, %31
  %sext = shl i64 %47, 32
  %48 = ashr exact i64 %sext, 32
  %pointerset_idx45 = add nsw i64 %48, -1
  %pointerset_ptr48 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerset_idx45
  store i8 2, i8* %pointerset_ptr48, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L333:                                             ; preds = %L294
  br i1 %.not159, label %L351, label %L333.L334_crit_edge

L333.L334_crit_edge:                              ; preds = %L333
  %.pre250 = add nuw nsw i64 %indvars.iv, 160
  %.pre251 = add nuw nsw i64 %.pre250, %8
  %.pre253 = add nsw i64 %.pre251, -1
  br label %L334

L333.thread:                                      ; preds = %L270
  br i1 %37, label %L334, label %L437.thread

L334:                                             ; preds = %L333.thread, %L333.L334_crit_edge
  %pointerset_idx53.pre-phi = phi i64 [ %.pre253, %L333.L334_crit_edge ], [ %pointerref_idx31, %L333.thread ]
  %pointerset_ptr56 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerset_idx53.pre-phi
  store i8 2, i8* %pointerset_ptr56, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L351:                                             ; preds = %L333
  br i1 %43, label %L369, label %L352

L352:                                             ; preds = %L351
  store i8 2, i8* %42, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L369:                                             ; preds = %L351
  br i1 %33, label %L437.thread248, label %L399

L437.thread248:                                   ; preds = %L369
  %pointerref_idx73243 = or i64 %8, 1
  %49 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx73243
  %pointerref75244 = load i8, i8* %49, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not = icmp eq i8 %pointerref75244, 0
  br i1 %.not, label %L455, label %L470

L399:                                             ; preds = %L369
  %pointerref_idx69 = add nsw i64 %pointerref_idx, -1
  %50 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx69
  %pointerref71 = load i8, i8* %50, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %51 = icmp ne i8 %pointerref71, 0
  %52 = add nuw nsw i64 %10, %indvars.iv
  %pointerref_idx73 = add nsw i64 %52, -1
  %53 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx73
  %pointerref75 = load i8, i8* %53, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %54 = icmp ne i8 %pointerref75, 0
  %or.cond154 = select i1 %51, i1 true, i1 %54
  br i1 %or.cond154, label %L437, label %L402

L402:                                             ; preds = %L399
  %pointerref78 = load i32, i32* %coercion41, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %55 = mul i32 %pointerref78, 1103515245
  %56 = add i32 %55, 12345
  store i32 %56, i32* %coercion41, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %57 = and i32 %56, 1
  %.not166 = icmp eq i32 %57, 0
  %.155 = select i1 %.not166, i64 4294967295, i64 1
  %58 = add i64 %.155, %11
  %sext237 = shl i64 %58, 32
  %59 = ashr exact i64 %sext237, 32
  %pointerset_idx81 = add nsw i64 %59, -1
  %pointerset_ptr84 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerset_idx81
  store i8 2, i8* %pointerset_ptr84, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L437:                                             ; preds = %L399
  br i1 %51, label %L454, label %L438

L437.thread:                                      ; preds = %L333.thread
  %pointerref_idx69239 = add nsw i64 %pointerref_idx, -1
  %60 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerref_idx69239
  %pointerref71240 = load i8, i8* %60, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %61 = icmp eq i8 %pointerref71240, 0
  br i1 %61, label %L438, label %L470

L438:                                             ; preds = %L437.thread, %L437
  %pointerset_idx89.pre-phi = phi i64 [ %pointerref_idx69239, %L437.thread ], [ %pointerref_idx69, %L437 ]
  %pointerset_ptr92 = getelementptr inbounds i8, i8* %coercion10, i64 %pointerset_idx89.pre-phi
  store i8 2, i8* %pointerset_ptr92, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L454:                                             ; preds = %L437
  br i1 %54, label %L470, label %L455

L455:                                             ; preds = %L454, %L437.thread248
  %62 = phi i8* [ %49, %L437.thread248 ], [ %53, %L454 ]
  store i8 2, i8* %62, align 1
  store i8 0, i8* %12, align 1
  br label %L470

L470:                                             ; preds = %L455, %L454, %L438, %L437.thread, %L402, %L437.thread248, %L352, %L334, %L297, %L232, %L199, %L198, %L181, %L180.thread, %L144, %L89, %L70, %L60, %L50
  %exitcond = icmp eq i64 %indvars.iv.next, 160
  br i1 %exitcond, label %L472, label %L50

L472:                                             ; preds = %L470
  %indvars.iv.next229 = add nsw i64 %indvars.iv228, -1
  %63 = icmp slt i64 %indvars.iv228, 1
  br i1 %63, label %common.ret, label %L46.preheader
}

define internal fastcc void @julia_place_cells_1887(i64 zeroext %0, i32 signext %1, i32 signext %2, i32 signext %3, i8 zeroext %4) unnamed_addr {
pass:
  %5 = sdiv i32 %3, 2
  %6 = sub nsw i32 0, %5
  %.not10 = icmp sgt i32 %3, 1
  br i1 %.not10, label %L7.lr.ph, label %L34

L7.lr.ph:                                         ; preds = %pass
  %coercion = inttoptr i64 %0 to i8*
  br label %L12.lr.ph

L12.lr.ph:                                        ; preds = %L32, %L7.lr.ph
  %value_phi11 = phi i32 [ %6, %L7.lr.ph ], [ %18, %L32 ]
  %7 = add i32 %value_phi11, %1
  %8 = icmp ugt i32 %7, 159
  %9 = add i32 %7, 1
  br label %L12

L12:                                              ; preds = %L30, %L12.lr.ph
  %value_phi19 = phi i32 [ %6, %L12.lr.ph ], [ %17, %L30 ]
  %10 = add i32 %value_phi19, %2
  %11 = icmp slt i32 %10, 0
  %or.cond4 = select i1 %8, i1 true, i1 %11
  %12 = icmp sgt i32 %10, 159
  %or.cond6 = select i1 %or.cond4, i1 true, i1 %12
  br i1 %or.cond6, label %L30, label %L24

L24:                                              ; preds = %L12
  %13 = mul nuw nsw i32 %10, 160
  %14 = add nuw nsw i32 %9, %13
  %15 = zext i32 %14 to i64
  %pointerset_idx = add nsw i64 %15, -1
  %16 = getelementptr inbounds i8, i8* %coercion, i64 %pointerset_idx
  store i8 %4, i8* %16, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  br label %L30

L30:                                              ; preds = %L24, %L12
  %17 = add nsw i32 %value_phi19, 1
  %exitcond.not = icmp eq i32 %17, %5
  br i1 %exitcond.not, label %L32, label %L12

L32:                                              ; preds = %L30
  %18 = add nsw i32 %value_phi11, 1
  %exitcond12.not = icmp eq i32 %18, %5
  br i1 %exitcond12.not, label %L34, label %L12.lr.ph

L34:                                              ; preds = %L32, %pass
  ret void
}

define internal fastcc void @julia_handle_input_1870(i64 zeroext %0) unnamed_addr {
top:
  %1 = alloca [16 x i8], align 16
  %.sub = getelementptr inbounds [16 x i8], [16 x i8]* %1, i64 0, i64 0
  %2 = alloca [17 x i8], align 16
  %.sub56 = getelementptr inbounds [17 x i8], [17 x i8]* %2, i64 0, i64 0
  %3 = alloca [17 x i8], align 16
  %.sub57 = getelementptr inbounds [17 x i8], [17 x i8]* %3, i64 0, i64 0
  %4 = alloca [17 x i8], align 16
  %.sub58 = getelementptr inbounds [17 x i8], [17 x i8]* %4, i64 0, i64 0
  %5 = call fastcc i8* @julia_handle_input_1870u1872(i32 56)
  %6 = call fastcc i32 @julia_handle_input_1870u1873(i8* %5)
  %.not72 = icmp eq i32 %6, 0
  br i1 %.not72, label %L189, label %L12.lr.ph

L12.lr.ph:                                        ; preds = %top
  %coercion = bitcast i8* %5 to i32*
  %7 = inttoptr i64 %0 to i8*
  %8 = getelementptr i8, i8* %7, i64 24
  %coercion44 = bitcast i8* %8 to i64*
  %coercion46 = getelementptr i8, i8* %7, i64 20
  %pointerref3.sroa.1.0..sroa_idx55 = getelementptr inbounds i8, i8* %5, i64 20
  %9 = bitcast i8* %pointerref3.sroa.1.0..sroa_idx55 to i32*
  %coercion35 = getelementptr i8, i8* %7, i64 21
  br label %L12

L12:                                              ; preds = %L188, %L12.lr.ph
  %pointerref = load i32, i32* %coercion, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  switch i32 %pointerref, label %L146 [
    i32 256, label %L16
    i32 768, label %L24
  ]

L16:                                              ; preds = %L12
  store i8 1, i8* %coercion35, align 1
  br label %L188

L24:                                              ; preds = %L12
  %pointerref3.sroa.1.0.copyload = load i32, i32* %9, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %10 = icmp sgt i32 %pointerref3.sroa.1.0.copyload, -1
  br i1 %10, label %L34, label %L134.thread

L34:                                              ; preds = %L24
  switch i32 %pointerref3.sroa.1.0.copyload, label %L188 [
    i32 49, label %L40
    i32 50, label %L65
    i32 51, label %L90
    i32 48, label %L115
    i32 27, label %L140
  ]

L40:                                              ; preds = %L34
  store i8 1, i8* %coercion46, align 1
  call void @llvm.lifetime.start.p0i8(i64 16, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(16) %.sub, i8* noundef nonnull align 1 dereferenceable(16) getelementptr inbounds ([16 x i8], [16 x i8]* @_j_const5, i64 0, i64 0), i64 16, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #0
  br label %L188

L65:                                              ; preds = %L34
  store i8 2, i8* %coercion46, align 1
  call void @llvm.lifetime.start.p0i8(i64 17, i8* nonnull %.sub56)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(17) %.sub56, i8* noundef nonnull align 1 dereferenceable(17) getelementptr inbounds ([17 x i8], [17 x i8]* @_j_const6, i64 0, i64 0), i64 17, i1 false)
  %status.i49 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub56) #0
  br label %L188

L90:                                              ; preds = %L34
  store i8 3, i8* %coercion46, align 1
  call void @llvm.lifetime.start.p0i8(i64 17, i8* nonnull %.sub57)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(17) %.sub57, i8* noundef nonnull align 1 dereferenceable(17) getelementptr inbounds ([17 x i8], [17 x i8]* @_j_const8, i64 0, i64 0), i64 17, i1 false)
  %status.i51 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub57) #0
  br label %L188

L115:                                             ; preds = %L34
  store i8 0, i8* %coercion46, align 1
  call void @llvm.lifetime.start.p0i8(i64 17, i8* nonnull %.sub58)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(17) %.sub58, i8* noundef nonnull align 1 dereferenceable(17) getelementptr inbounds ([17 x i8], [17 x i8]* @_j_const9, i64 0, i64 0), i64 17, i1 false)
  %status.i53 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub58) #0
  br label %L188

L134.thread:                                      ; preds = %L24
  call fastcc void @julia__throw_inexacterror_1889()
  call fastcc void @julia__throw_inexacterror_1889()
  call fastcc void @julia__throw_inexacterror_1889()
  call fastcc void @julia__throw_inexacterror_1889()
  call fastcc void @julia__throw_inexacterror_1889()
  br label %L188

L140:                                             ; preds = %L34
  store i8 1, i8* %coercion35, align 1
  br label %L188

L146:                                             ; preds = %L12
  %11 = add i32 %pointerref, -1026
  %12 = icmp ult i32 %11, -2
  br i1 %12, label %L188, label %L151

L151:                                             ; preds = %L146
  %13 = call fastcc i32 @julia_handle_input_1870u1879(i32* null, i32* null)
  %14 = and i32 %13, 1
  %.not66 = icmp eq i32 %14, 0
  br i1 %.not66, label %L188, label %pass43

L188:                                             ; preds = %pass43, %L151, %L146, %L140, %L134.thread, %L115, %L90, %L65, %L40, %L34, %L16
  call void @llvm.lifetime.end.p0i8(i64 16, i8* nonnull %.sub)
  call void @llvm.lifetime.end.p0i8(i64 17, i8* nonnull %.sub56)
  call void @llvm.lifetime.end.p0i8(i64 17, i8* nonnull %.sub57)
  call void @llvm.lifetime.end.p0i8(i64 17, i8* nonnull %.sub58)
  %15 = call fastcc i32 @julia_handle_input_1870u1873(i8* nonnull %5)
  %.not = icmp eq i32 %15, 0
  br i1 %.not, label %L189, label %L12

L189:                                             ; preds = %L188, %top
  call fastcc void @julia_handle_input_1870u1883(i8* %5)
  ret void

pass43:                                           ; preds = %L151
  %16 = call fastcc i8* @julia_handle_input_1870u1872(i32 4)
  %17 = call fastcc i8* @julia_handle_input_1870u1872(i32 4)
  %18 = bitcast i8* %16 to i32*
  %19 = bitcast i8* %17 to i32*
  call fastcc void @julia_handle_input_1870u1882(i32* %18, i32* %19)
  %pointerref38 = load i32, i32* %18, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %pointerref40 = load i32, i32* %19, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  call fastcc void @julia_handle_input_1870u1883(i8* %16)
  call fastcc void @julia_handle_input_1870u1883(i8* %17)
  %20 = sdiv i32 %pointerref38, 4
  %21 = sdiv i32 %pointerref40, 4
  %pointerref45 = load i64, i64* %coercion44, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %pointerref47 = load i8, i8* %coercion46, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  call fastcc void @julia_place_cells_1887(i64 zeroext %pointerref45, i32 signext %20, i32 signext %21, i32 signext 4, i8 zeroext %pointerref47)
  br label %L188
}

; Function Attrs: argmemonly nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0i8.p0i8.i64(i8* noalias nocapture writeonly, i8* noalias nocapture readonly, i64, i1 immarg) #1

define internal fastcc i8* @julia_handle_input_1870u1872(i32 %size) unnamed_addr {
entry:
  %ptr = call noalias i8* @malloc(i32 %size)
  ret i8* %ptr
}

define internal fastcc i32 @julia_handle_input_1870u1873(i8* %event) unnamed_addr {
entry:
  %result = call i32 @SDL_PollEvent(i8* %event)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @SDL_PollEvent(i8*) local_unnamed_addr #0

declare i32 @printf(i8* noalias nocapture, ...) local_unnamed_addr

define internal fastcc i32 @julia_handle_input_1870u1879(i32* %x, i32* %y) unnamed_addr {
entry:
  %result = call i32 @SDL_GetMouseState(i32* %x, i32* %y)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @SDL_GetMouseState(i32*, i32*) local_unnamed_addr #0

define internal fastcc void @julia_handle_input_1870u1882(i32* %x, i32* %y) unnamed_addr {
entry:
  %result = call i32 @SDL_GetMouseState(i32* %x, i32* %y)
  ret void
}

define internal fastcc void @julia_handle_input_1870u1883(i8* %ptr) unnamed_addr {
entry:
  call void @free(i8* %ptr)
  ret void
}

; Function Attrs: noinline
define internal fastcc void @julia__throw_inexacterror_1889() unnamed_addr #2 {
top:
  %0 = alloca [19 x i8], align 16
  %.sub = getelementptr inbounds [19 x i8], [19 x i8]* %0, i64 0, i64 0
  call void @llvm.lifetime.start.p0i8(i64 19, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(19) %.sub, i8* noundef nonnull align 1 dereferenceable(19) getelementptr inbounds ([19 x i8], [19 x i8]* @_j_const10, i64 0, i64 0), i64 19, i1 false)
  %status.i = call i32 @puts(i8* noundef nonnull %.sub)
  call void @llvm.lifetime.end.p0i8(i64 19, i8* nonnull %.sub)
  call void @exit(i32 1) #0
  ret void
}

; Function Attrs: nounwind
declare i32 @puts(i8* nocapture) local_unnamed_addr #0

declare void @exit(i32) local_unnamed_addr

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0i8(i64 immarg, i8* nocapture) #3

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0i8(i64 immarg, i8* nocapture) #3

attributes #0 = { nounwind }
attributes #1 = { argmemonly nocallback nofree nounwind willreturn }
attributes #2 = { noinline }
attributes #3 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = !{!3, !3, i64 0}
!3 = !{!"jtbaa_data", !4, i64 0}
!4 = !{!"jtbaa", !5, i64 0}
!5 = !{!"jtbaa"}
!6 = !{!7}
!7 = !{!"jnoalias_data", !8}
!8 = !{!"jnoalias"}
!9 = !{!10, !11, !12, !13}
!10 = !{!"jnoalias_gcframe", !8}
!11 = !{!"jnoalias_stack", !8}
!12 = !{!"jnoalias_typemd", !8}
!13 = !{!"jnoalias_const", !8}
!14 = !{!4, !4, i64 0}
!15 = !{!7, !11}
!16 = !{!10, !12, !13}
