; ModuleID = 'start'
source_filename = "start"
target datalayout = "e-m:o-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-apple-darwin"

@_j_const11 = private unnamed_addr constant [31 x i8] c"Animation state changed to %d\0A\00"
@_j_const13 = private unnamed_addr constant [24 x i8] c"Player is facing right\0A\00"
@_j_const14 = private unnamed_addr constant [23 x i8] c"Player is facing left\0A\00"
@_j_const1 = private unnamed_addr constant [27 x i8] c"Failed to create renderer\0A\00"
@_j_const68 = private unnamed_addr constant [25 x i8] c"Failed to create window\0A\00"
@_j_const57 = private unnamed_addr constant [20 x i8] c"Loading PNG sprite\0A\00"
@_j_const58 = private unnamed_addr constant [13 x i8] c"Surface: %p\0A\00"
@_j_const59 = private unnamed_addr constant [28 x i8] c"Failed to load PNG surface\0A\00"
@_j_const60 = private unnamed_addr constant [39 x i8] c"Failed to create texture from surface\0A\00"
@_j_const61 = private unnamed_addr constant [39 x i8] c"Surface width: %d, Surface height: %d\0A\00"
@_j_const62 = private unnamed_addr constant [32 x i8] c"PNG sprite loaded successfully\0A\00"
@_j_const63 = private unnamed_addr constant [28 x i8] c"Initializing sprite system\0A\00"
@_j_const64 = private unnamed_addr constant [52 x i8] c"IMG_Init returned: %d (expected 2 for PNG support)\0A\00"
@_j_const65 = private unnamed_addr constant [61 x i8] c"Failed to initialize SDL2_image - PNG support not available\0A\00"
@_j_const66 = private unnamed_addr constant [40 x i8] c"Sprite system initialized successfully\0A\00"
@_j_const19 = private unnamed_addr constant [25 x i8] c"Initializing game state\0A\00"
@_j_const20 = private unnamed_addr constant [7 x i8] c"macOS\0A\00"
@_j_const21 = private unnamed_addr constant [14 x i8] c"Platform: %s\0A\00"
@_j_const23 = private unnamed_addr constant [36 x i8] c"Failed to initialize sprite system\0A\00"
@_j_const24 = private unnamed_addr constant [27 x i8] c"Initializing audio system\0A\00"
@_j_const25 = private unnamed_addr constant [60 x i8] c"Failed to initialize SDL_mixer - OGG support not available\0A\00"
@_j_const26 = private unnamed_addr constant [15 x i8] c"SDL Error: %s\0A\00"
@_j_const27 = private unnamed_addr constant [45 x i8] c"Failed to open audio device, error code: %d\0A\00"
@_j_const8 = private unnamed_addr constant [40 x i8] c"Failed to play jump sound, channel: %d\0A\00"
@_j_const30 = private unnamed_addr constant [19 x i8] c"Jump sound loaded\0A\00"
@_j_const31 = private unnamed_addr constant [28 x i8] c"Creating player animations\0A\00"
@_j_const48 = private unnamed_addr constant [24 x i8] c"Game state initialized\0A\00"
@_j_const49 = private unnamed_addr constant [23 x i8] c"Loading player sprite\0A\00"
@_j_const51 = private unnamed_addr constant [11 x i8] c"Error: %s\0A\00"
@_j_const52 = private unnamed_addr constant [27 x i8] c"Loading background sprite\0A\00"
@_j_const54 = private unnamed_addr constant [49 x i8] c"Skipping sound loading - audio device not ready\0A\00"
@_j_const55 = private unnamed_addr constant [34 x i8] c"Audio device opened successfully\0A\00"
@_j_const56 = private unnamed_addr constant [53 x i8] c"SDL_mixer initialized successfully with OGG support\0A\00"
@_j_const18 = private unnamed_addr constant [19 x i8] c"Inexact conversion\00"

define internal fastcc void @render_sprite_animated_1997(i64 zeroext %0, i64 zeroext %1, i64 zeroext %2, float %3, float %4) unnamed_addr {
top:
  %5 = icmp ne i64 %1, 0
  %6 = icmp ne i64 %2, 0
  %or.cond = select i1 %5, i1 %6, i1 false
  br i1 %or.cond, label %L11, label %common.ret

L11:                                              ; preds = %top
  %7 = inttoptr i64 %1 to { i64, i32, i32, i32, i32, i32, i32, i8, i8 }*
  %.sroa.427.0..sroa_idx = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %7, i64 0, i32 7
  %.sroa.427.0.copyload = load i8, i8* %.sroa.427.0..sroa_idx, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %8 = and i8 %.sroa.427.0.copyload, 1
  %.not.not = icmp eq i8 %8, 0
  br i1 %.not.not, label %common.ret, label %L17

common.ret:                                       ; preds = %L17, %L11, %top
  %common.ret.op = phi i32 [ %36, %L17 ], [ -1, %L11 ], [ -1, %top ]
  ret void

L17:                                              ; preds = %L11
  %.sroa.5.0..sroa_idx = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %7, i64 0, i32 8
  %.sroa.5.0.copyload = load i8, i8* %.sroa.5.0..sroa_idx, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.324.0..sroa_idx25 = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %7, i64 0, i32 2
  %.sroa.324.0.copyload = load i32, i32* %.sroa.324.0..sroa_idx25, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.222.0..sroa_idx23 = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %7, i64 0, i32 1
  %.sroa.222.0.copyload = load i32, i32* %.sroa.222.0..sroa_idx23, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.021.0..sroa_idx = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %7, i64 0, i32 0
  %.sroa.021.0.copyload = load i64, i64* %.sroa.021.0..sroa_idx, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %9 = inttoptr i64 %2 to i64*
  %10 = load i64, i64* %9, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %11 = inttoptr i64 %2 to i8*
  %12 = getelementptr i8, i8* %11, i64 28
  %13 = bitcast i8* %12 to i32*
  %14 = load i32, i32* %13, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 4
  %17 = inttoptr i64 %10 to i8*
  %18 = getelementptr i8, i8* %17, i64 %16
  %.sroa.014.0..sroa_idx = bitcast i8* %18 to i32*
  %.sroa.014.0.copyload = load i32, i32* %.sroa.014.0..sroa_idx, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.215.0..sroa_idx16 = getelementptr inbounds i8, i8* %18, i64 4
  %19 = bitcast i8* %.sroa.215.0..sroa_idx16 to i32*
  %.sroa.215.0.copyload = load i32, i32* %19, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.317.0..sroa_idx18 = getelementptr inbounds i8, i8* %18, i64 8
  %20 = bitcast i8* %.sroa.317.0..sroa_idx18 to i32*
  %.sroa.317.0.copyload = load i32, i32* %20, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.419.0..sroa_idx20 = getelementptr inbounds i8, i8* %18, i64 12
  %21 = bitcast i8* %.sroa.419.0..sroa_idx20 to i32*
  %.sroa.419.0.copyload = load i32, i32* %21, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %22 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %.sroa.07.0..sroa_idx = bitcast i8* %22 to i32*
  store i32 %.sroa.014.0.copyload, i32* %.sroa.07.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.28.0..sroa_idx9 = getelementptr inbounds i8, i8* %22, i64 4
  %23 = bitcast i8* %.sroa.28.0..sroa_idx9 to i32*
  store i32 %.sroa.215.0.copyload, i32* %23, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.310.0..sroa_idx11 = getelementptr inbounds i8, i8* %22, i64 8
  %24 = bitcast i8* %.sroa.310.0..sroa_idx11 to i32*
  store i32 %.sroa.317.0.copyload, i32* %24, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.412.0..sroa_idx13 = getelementptr inbounds i8, i8* %22, i64 12
  %25 = bitcast i8* %.sroa.412.0..sroa_idx13 to i32*
  store i32 %.sroa.419.0.copyload, i32* %25, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %26 = sitofp i32 %.sroa.222.0.copyload to float
  %27 = sitofp i32 %.sroa.324.0.copyload to float
  %28 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %.sroa.0.0..sroa_idx = bitcast i8* %28 to float*
  store float %3, float* %.sroa.0.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.2.0..sroa_idx4 = getelementptr inbounds i8, i8* %28, i64 4
  %29 = bitcast i8* %.sroa.2.0..sroa_idx4 to float*
  store float %4, float* %29, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.3.0..sroa_idx5 = getelementptr inbounds i8, i8* %28, i64 8
  %30 = bitcast i8* %.sroa.3.0..sroa_idx5 to float*
  store float %26, float* %30, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.4.0..sroa_idx6 = getelementptr inbounds i8, i8* %28, i64 12
  %31 = bitcast i8* %.sroa.4.0..sroa_idx6 to float*
  store float %27, float* %31, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %32 = and i8 %.sroa.5.0.copyload, 1
  %33 = zext i8 %32 to i32
  %34 = inttoptr i64 %0 to i8*
  %35 = inttoptr i64 %.sroa.021.0.copyload to i8*
  %36 = call fastcc i32 @julia_render_sprite_animated_1997u2001(i8* %34, i8* %35, i8* %22, i8* %28, double 0.000000e+00, i8* null, i32 %33)
  call fastcc void @julia_cleanup_1939u1941(i8* %28)
  call fastcc void @julia_cleanup_1939u1941(i8* %22)
  br label %common.ret
}

; Function Attrs: argmemonly nofree nounwind willreturn
declare void @llvm.memcpy.p0i8.p0i8.i64(i8* noalias nocapture writeonly, i8* noalias nocapture readonly, i64, i1 immarg) #0

; Function Attrs: nounwind
declare noalias i8* @malloc(i32) local_unnamed_addr #1

define internal fastcc i32 @julia_render_sprite_animated_1997u2001(i8* %renderer, i8* %texture, i8* %srcrect, i8* %dstrect, double %angle, i8* %center, i32 %flip) unnamed_addr {
entry:
  %result = call i32 @SDL_RenderCopyExF(i8* %renderer, i8* %texture, i8* %srcrect, i8* %dstrect, double %angle, i8* %center, i32 %flip)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @SDL_RenderCopyExF(i8*, i8*, i8*, i8*, double, i8*, i32) local_unnamed_addr #1

; Function Attrs: nounwind
declare void @free(i8*) local_unnamed_addr #1

define internal fastcc void @julia_handle_input_2006(i64 zeroext %0, i64 zeroext %1, i64 zeroext %2, i64 zeroext %3, i64 zeroext %4) unnamed_addr {
top:
  %5 = alloca i32, align 8
  %6 = bitcast i32* %5 to i8*
  %7 = alloca i32, align 8
  %8 = bitcast i32* %7 to i8*
  %9 = inttoptr i64 %1 to i8*
  %10 = getelementptr i8, i8* %9, i64 1
  %11 = getelementptr i8, i8* %9, i64 2
  %12 = getelementptr i8, i8* %9, i64 3
  %13 = getelementptr i8, i8* %9, i64 4
  %14 = inttoptr i64 %2 to i8*
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(5) %9, i8 0, i64 5, i1 false)
  %15 = getelementptr i8, i8* %14, i64 1
  %16 = getelementptr i8, i8* %14, i64 2
  %17 = getelementptr i8, i8* %14, i64 3
  %18 = getelementptr i8, i8* %14, i64 4
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(5) %14, i8 0, i64 5, i1 false)
  %19 = call fastcc i8* @julia_game_loop_1955u1967(i32 56)
  %20 = call fastcc i32 @julia_handle_input_2006u2009(i8* %19)
  %.not103 = icmp eq i32 %20, 0
  br i1 %.not103, label %L478, label %L60.lr.ph

L60.lr.ph:                                        ; preds = %top
  %21 = bitcast i8* %19 to i32*
  %.sroa.128.0..sroa_idx29 = getelementptr inbounds i8, i8* %19, i64 20
  %22 = bitcast i8* %.sroa.128.0..sroa_idx29 to i32*
  %23 = inttoptr i64 %3 to i8*
  %24 = getelementptr i8, i8* %23, i64 128
  %25 = inttoptr i64 %4 to i8*
  %26 = getelementptr i8, i8* %23, i64 96
  %27 = inttoptr i64 %0 to i8*
  %28 = getelementptr i8, i8* %27, i64 4
  %29 = getelementptr i8, i8* %27, i64 3
  %30 = getelementptr i8, i8* %27, i64 2
  %31 = getelementptr i8, i8* %27, i64 1
  %32 = getelementptr i8, i8* %23, i64 152
  %33 = getelementptr i8, i8* %23, i64 153
  %34 = getelementptr i8, i8* %23, i64 154
  %.sroa.124.0..sroa_idx25 = getelementptr inbounds i8, i8* %19, i64 24
  %35 = bitcast i8* %.sroa.124.0..sroa_idx25 to float*
  %.sroa.1.0..sroa_idx22 = getelementptr inbounds i8, i8* %19, i64 28
  %36 = bitcast i8* %.sroa.1.0..sroa_idx22 to float*
  br label %L60

L60:                                              ; preds = %L477, %L60.lr.ph
  %37 = load i32, i32* %21, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  switch i32 %37, label %L340 [
    i32 256, label %L64
    i32 768, label %L72
    i32 769, label %L246
  ]

L64:                                              ; preds = %L60
  store i8 1, i8* %26, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L72:                                              ; preds = %L60
  %.sroa.145.0.copyload = load i32, i32* %22, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %38 = icmp sgt i32 %.sroa.145.0.copyload, -1
  br i1 %38, label %L82, label %L215.thread

L82:                                              ; preds = %L72
  switch i32 %.sroa.145.0.copyload, label %L477 [
    i32 97, label %L88
    i32 100, label %L111
    i32 119, label %L134
    i32 115, label %L157
    i32 32, label %L180
    i32 27, label %L203
    i32 13, label %L221
  ]

L88:                                              ; preds = %L82
  store i8 1, i8* %27, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 1, i8* %14, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L111:                                             ; preds = %L82
  store i8 1, i8* %31, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 1, i8* %15, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L134:                                             ; preds = %L82
  store i8 1, i8* %30, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 1, i8* %16, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L157:                                             ; preds = %L82
  store i8 1, i8* %29, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 1, i8* %17, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L180:                                             ; preds = %L82
  store i8 1, i8* %28, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 1, i8* %18, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L203:                                             ; preds = %L82
  store i8 1, i8* %26, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L215.thread:                                      ; preds = %L72
  call fastcc void @julia__throw_inexacterror_2015() #6
  call fastcc void @julia__throw_inexacterror_2015() #6
  call fastcc void @julia__throw_inexacterror_2015() #6
  call fastcc void @julia__throw_inexacterror_2015() #6
  call fastcc void @julia__throw_inexacterror_2015() #6
  call fastcc void @julia__throw_inexacterror_2015() #6
  call fastcc void @julia__throw_inexacterror_2015() #6
  br label %L477

L221:                                             ; preds = %L82
  %39 = load i8, i8* %24, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %40 = and i8 %39, 1
  %41 = xor i8 %40, 1
  store i8 %41, i8* %24, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not77 = icmp eq i8 %41, 0
  br i1 %.not77, label %L241, label %L238

L238:                                             ; preds = %L221
  call fastcc void @julia_handle_input_2006u2011(i8* %25, i32 1)
  br label %L477

L241:                                             ; preds = %L221
  call fastcc void @julia_handle_input_2006u2011(i8* %25, i32 0)
  br label %L477

L246:                                             ; preds = %L60
  %.sroa.128.0.copyload = load i32, i32* %22, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %42 = icmp sgt i32 %.sroa.128.0.copyload, -1
  br i1 %42, label %L256, label %L328.thread

L256:                                             ; preds = %L246
  switch i32 %.sroa.128.0.copyload, label %L477 [
    i32 97, label %L262
    i32 100, label %L280
    i32 119, label %L298
    i32 115, label %L316
    i32 32, label %L334
  ]

L262:                                             ; preds = %L256
  store i8 1, i8* %9, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L280:                                             ; preds = %L256
  store i8 1, i8* %10, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L298:                                             ; preds = %L256
  store i8 1, i8* %11, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L316:                                             ; preds = %L256
  store i8 1, i8* %12, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L328.thread:                                      ; preds = %L246
  call fastcc void @julia__throw_inexacterror_2015() #6
  call fastcc void @julia__throw_inexacterror_2015() #6
  call fastcc void @julia__throw_inexacterror_2015() #6
  call fastcc void @julia__throw_inexacterror_2015() #6
  call fastcc void @julia__throw_inexacterror_2015() #6
  br label %L477

L334:                                             ; preds = %L256
  store i8 1, i8* %13, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L340:                                             ; preds = %L60
  %43 = and i32 %37, -3
  %.not84 = icmp eq i32 %43, 1792
  br i1 %.not84, label %L379, label %L346

L346:                                             ; preds = %L340
  %.not85 = icmp eq i32 %37, 1793
  br i1 %.not85, label %L348, label %L477

L348:                                             ; preds = %L346
  store i8 0, i8* %27, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 0, i8* %31, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 0, i8* %28, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 0, i8* %32, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 0, i8* %33, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 0, i8* %34, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L379:                                             ; preds = %L340
  call void @llvm.lifetime.start.p0i8(i64 4, i8* nonnull %6)
  store i32 0, i32* %5, align 8, !tbaa !18, !alias.scope !15, !noalias !16
  call void @llvm.lifetime.start.p0i8(i64 4, i8* nonnull %8)
  store i32 0, i32* %7, align 8, !tbaa !18, !alias.scope !15, !noalias !16
  call fastcc void @julia_game_loop_1955u1964(i8* %25, i8* nonnull %6, i8* nonnull %8)
  %44 = load i32, i32* %5, align 8, !tbaa !18, !alias.scope !15, !noalias !16
  %45 = load i32, i32* %7, align 8, !tbaa !18, !alias.scope !15, !noalias !16
  %46 = sitofp i32 %45 to double
  %47 = fmul double %46, 2.500000e-01
  %48 = fsub double %46, %47
  %49 = sitofp i32 %44 to double
  %50 = fdiv double %49, 3.000000e+00
  %.sroa.124.0.copyload = load float, float* %35, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %51 = fpext float %.sroa.124.0.copyload to double
  %.sroa.1.0.copyload = load float, float* %36, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %52 = fpext float %.sroa.1.0.copyload to double
  %53 = fmul double %49, %51
  %54 = fmul double %46, %52
  store i8 0, i8* %32, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 0, i8* %33, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 0, i8* %34, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %55 = fcmp ult double %53, 0.000000e+00
  %56 = fcmp uge double %53, %50
  %or.cond = or i1 %55, %56
  %57 = fcmp ugt double %48, %54
  %or.cond9 = select i1 %or.cond, i1 true, i1 %57
  br i1 %or.cond9, label %L441, label %L431

L431:                                             ; preds = %L379
  store i8 1, i8* %27, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 1, i8* %32, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L441

L441:                                             ; preds = %L431, %L379
  %58 = fmul double %50, 2.000000e+00
  %59 = fcmp ugt double %58, %53
  br i1 %59, label %L459, label %L444

L444:                                             ; preds = %L441
  %60 = fmul double %50, 3.000000e+00
  %61 = fcmp uge double %53, %60
  %or.cond13 = select i1 %61, i1 true, i1 %57
  br i1 %or.cond13, label %L459, label %L449

L449:                                             ; preds = %L444
  store i8 1, i8* %31, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 1, i8* %33, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L459

L459:                                             ; preds = %L449, %L444, %L441
  %62 = fcmp ugt double %50, %53
  br i1 %62, label %L477, label %L461

L461:                                             ; preds = %L459
  %63 = fcmp uge double %53, %58
  %or.cond17 = select i1 %63, i1 true, i1 %57
  br i1 %or.cond17, label %L477, label %L466

L466:                                             ; preds = %L461
  store i8 1, i8* %28, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 1, i8* %34, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L477

L477:                                             ; preds = %L466, %L461, %L459, %L348, %L346, %L334, %L328.thread, %L316, %L298, %L280, %L262, %L256, %L241, %L238, %L215.thread, %L203, %L180, %L157, %L134, %L111, %L88, %L82, %L64
  call void @llvm.lifetime.end.p0i8(i64 4, i8* nonnull %6)
  call void @llvm.lifetime.end.p0i8(i64 4, i8* nonnull %8)
  %64 = call fastcc i32 @julia_handle_input_2006u2009(i8* nonnull %19)
  %.not = icmp eq i32 %64, 0
  br i1 %.not, label %L478, label %L60

L478:                                             ; preds = %L477, %top
  %65 = load i8, i8* %9, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %66 = and i8 %65, 1
  %.not86 = icmp eq i8 %66, 0
  br i1 %.not86, label %L489, label %L484

L484:                                             ; preds = %L478
  %67 = inttoptr i64 %0 to i8*
  store i8 0, i8* %67, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L489

L489:                                             ; preds = %L484, %L478
  %68 = load i8, i8* %10, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %69 = and i8 %68, 1
  %.not87 = icmp eq i8 %69, 0
  br i1 %.not87, label %L500, label %L495

L495:                                             ; preds = %L489
  %70 = inttoptr i64 %0 to i8*
  %71 = getelementptr i8, i8* %70, i64 1
  store i8 0, i8* %71, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L500

L500:                                             ; preds = %L495, %L489
  %72 = load i8, i8* %11, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %73 = and i8 %72, 1
  %.not88 = icmp eq i8 %73, 0
  br i1 %.not88, label %L511, label %L506

L506:                                             ; preds = %L500
  %74 = inttoptr i64 %0 to i8*
  %75 = getelementptr i8, i8* %74, i64 2
  store i8 0, i8* %75, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L511

L511:                                             ; preds = %L506, %L500
  %76 = load i8, i8* %12, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %77 = and i8 %76, 1
  %.not89 = icmp eq i8 %77, 0
  br i1 %.not89, label %L522, label %L517

L517:                                             ; preds = %L511
  %78 = inttoptr i64 %0 to i8*
  %79 = getelementptr i8, i8* %78, i64 3
  store i8 0, i8* %79, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L522

L522:                                             ; preds = %L517, %L511
  %80 = load i8, i8* %13, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %81 = and i8 %80, 1
  %.not90 = icmp eq i8 %81, 0
  br i1 %.not90, label %L533, label %L528

L528:                                             ; preds = %L522
  %82 = inttoptr i64 %0 to i8*
  %83 = getelementptr i8, i8* %82, i64 4
  store i8 0, i8* %83, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L533

L533:                                             ; preds = %L528, %L522
  call fastcc void @julia_cleanup_1939u1941(i8* %19)
  ret void
}

define internal fastcc i32 @julia_handle_input_2006u2009(i8* %event) unnamed_addr {
entry:
  %result = call i32 @SDL_PollEvent(i8* %event)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @SDL_PollEvent(i8*) local_unnamed_addr #1

define internal fastcc void @julia_handle_input_2006u2011(i8* %window, i32 %flags) unnamed_addr {
entry:
  %result = call i32 @SDL_SetWindowFullscreen(i8* %window, i32 %flags)
  ret void
}

; Function Attrs: nounwind
declare i32 @SDL_SetWindowFullscreen(i8*, i32) local_unnamed_addr #1

; Function Attrs: nounwind
declare void @SDL_GetWindowSize(i8*, i8*, i8*) local_unnamed_addr #1

define internal fastcc void @julia_game_loop_1955(i64 zeroext %0, i64 zeroext %1, i64 zeroext %2) unnamed_addr {
top:
  %3 = alloca [40 x i8], align 16
  %.sub = getelementptr inbounds [40 x i8], [40 x i8]* %3, i64 0, i64 0
  %4 = alloca [31 x i8], align 16
  %.sub77 = getelementptr inbounds [31 x i8], [31 x i8]* %4, i64 0, i64 0
  %5 = alloca i32, align 8
  %6 = bitcast i32* %5 to i8*
  %7 = alloca i32, align 8
  %8 = bitcast i32* %7 to i8*
  %9 = alloca [24 x i8], align 16
  %.sub78 = getelementptr inbounds [24 x i8], [24 x i8]* %9, i64 0, i64 0
  %10 = alloca [23 x i8], align 16
  %.sub79 = getelementptr inbounds [23 x i8], [23 x i8]* %10, i64 0, i64 0
  %11 = call fastcc i64 @julia_game_loop_1955u1957()
  %12 = inttoptr i64 %0 to i8*
  %13 = getelementptr i8, i8* %12, i64 88
  %14 = bitcast i8* %13 to i64*
  %15 = load i64, i64* %14, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %16 = sub i64 %11, %15
  %17 = uitofp i64 %16 to double
  %18 = call fastcc i64 @julia_game_loop_1955u1958()
  %19 = uitofp i64 %18 to double
  %20 = fdiv double %17, %19
  store i64 %11, i64* %14, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %21 = getelementptr i8, i8* %12, i64 72
  %22 = bitcast i8* %21 to i64*
  %23 = load i64, i64* %22, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %24 = getelementptr i8, i8* %12, i64 64
  %25 = bitcast i8* %24 to i64*
  %26 = load i64, i64* %25, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %27 = getelementptr i8, i8* %12, i64 80
  %28 = bitcast i8* %27 to i64*
  %29 = load i64, i64* %28, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  call fastcc void @julia_handle_input_2006(i64 zeroext %23, i64 zeroext %26, i64 zeroext %29, i64 zeroext %0, i64 zeroext %2) #6
  %30 = getelementptr i8, i8* %12, i64 32
  %31 = bitcast i8* %30 to i32*
  %32 = load i32, i32* %31, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not = icmp eq i32 %32, 1
  %33 = getelementptr i8, i8* %12, i64 40
  %34 = bitcast i8* %33 to double*
  br i1 %.not, label %L59, label %L48

L48:                                              ; preds = %top
  %35 = load double, double* %34, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %36 = fsub double %35, %20
  br label %L59

L59:                                              ; preds = %L48, %top
  %37 = phi double [ %36, %L48 ], [ 1.000000e-01, %top ]
  store double %37, double* %34, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %38 = inttoptr i64 %29 to i8*
  %39 = getelementptr i8, i8* %38, i64 4
  %40 = load i8, i8* %39, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %41 = and i8 %40, 1
  %.not80 = icmp eq i8 %41, 0
  %42 = getelementptr i8, i8* %12, i64 48
  %43 = bitcast i8* %42 to double*
  br i1 %.not80, label %L71, label %L82

L71:                                              ; preds = %L59
  %44 = load double, double* %43, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %45 = fsub double %44, %20
  br label %L82

L82:                                              ; preds = %L71, %L59
  %storemerge = phi double [ %45, %L71 ], [ 1.000000e-01, %L59 ]
  store double %storemerge, double* %43, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %46 = inttoptr i64 %23 to i8*
  %47 = load i8, i8* %46, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %48 = and i8 %47, 1
  %.not81 = icmp eq i8 %48, 0
  br i1 %.not81, label %L96, label %L88

L88:                                              ; preds = %L82
  %49 = inttoptr i64 %0 to double*
  %50 = load double, double* %49, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %51 = fcmp ule double %50, 3.640000e+02
  br i1 %51, label %L96, label %L110

L96:                                              ; preds = %L88, %L82
  %52 = getelementptr i8, i8* %46, i64 1
  %53 = load i8, i8* %52, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %54 = and i8 %53, 1
  %.not105 = icmp eq i8 %54, 0
  br i1 %.not105, label %L110, label %L102

L102:                                             ; preds = %L96
  %55 = inttoptr i64 %0 to double*
  %56 = load double, double* %55, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %57 = fcmp uge double %56, 8.120000e+02
  %. = select i1 %57, double 0.000000e+00, double 3.000000e+02
  br label %L110

L110:                                             ; preds = %L102, %L96, %L88
  %value_phi = phi double [ -3.000000e+02, %L88 ], [ 0.000000e+00, %L96 ], [ %., %L102 ]
  %58 = getelementptr i8, i8* %12, i64 16
  %59 = bitcast i8* %58 to double*
  %60 = load double, double* %59, align 1, !tbaa !13
  br i1 %.not, label %L118, label %L156

L118:                                             ; preds = %L110
  %61 = fmul double %20, 2.000000e+03
  %62 = fcmp uge double %60, %value_phi
  br i1 %62, label %L136, label %L126

L126:                                             ; preds = %L118
  %63 = fadd double %61, %60
  %64 = fsub double %63, %value_phi
  %65 = bitcast double %64 to i64
  %66 = icmp slt i64 %65, 0
  %67 = select i1 %66, double %63, double %value_phi
  %68 = fcmp ord double %63, 0.000000e+00
  %69 = select i1 %68, double %67, double %64
  br label %L193

L136:                                             ; preds = %L118
  %70 = fcmp uge double %value_phi, %60
  br i1 %70, label %L206.thread, label %L138

L138:                                             ; preds = %L136
  %71 = fsub double %60, %61
  %72 = fsub double %71, %value_phi
  %73 = bitcast double %72 to i64
  %74 = icmp slt i64 %73, 0
  %75 = select i1 %74, double %value_phi, double %71
  %76 = fcmp ord double %71, 0.000000e+00
  %77 = select i1 %76, double %75, double %72
  br label %L193

L156:                                             ; preds = %L110
  %78 = fmul double %20, 1.200000e+03
  %79 = fcmp uge double %60, %value_phi
  br i1 %79, label %L174, label %L164

L164:                                             ; preds = %L156
  %80 = fadd double %78, %60
  %81 = fsub double %80, %value_phi
  %82 = bitcast double %81 to i64
  %83 = icmp slt i64 %82, 0
  %84 = select i1 %83, double %80, double %value_phi
  %85 = fcmp ord double %80, 0.000000e+00
  %86 = select i1 %85, double %84, double %81
  br label %L193

L174:                                             ; preds = %L156
  %87 = fcmp uge double %value_phi, %60
  br i1 %87, label %L206.thread, label %L176

L176:                                             ; preds = %L174
  %88 = fsub double %60, %78
  %89 = fsub double %88, %value_phi
  %90 = bitcast double %89 to i64
  %91 = icmp slt i64 %90, 0
  %92 = select i1 %91, double %value_phi, double %88
  %93 = fcmp ord double %88, 0.000000e+00
  %94 = select i1 %93, double %92, double %89
  br label %L193

L206.thread:                                      ; preds = %L174, %L136
  store double %value_phi, double* %59, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L218

L193:                                             ; preds = %L176, %L164, %L138, %L126
  %95 = phi double [ %69, %L126 ], [ %77, %L138 ], [ %86, %L164 ], [ %94, %L176 ]
  store double %95, double* %59, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %96 = fcmp ule double %95, 3.000000e+02
  br i1 %96, label %L206, label %L200

L200:                                             ; preds = %L193
  store double 3.000000e+02, double* %59, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L218

L206:                                             ; preds = %L193
  %97 = fcmp uge double %95, -3.000000e+02
  br i1 %97, label %L218, label %L213

L213:                                             ; preds = %L206
  store double -3.000000e+02, double* %59, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L218

L218:                                             ; preds = %L213, %L206, %L200, %L206.thread
  %98 = fcmp ule double %37, 0.000000e+00
  %99 = fcmp ule double %storemerge, 0.000000e+00
  %or.cond = select i1 %98, i1 true, i1 %99
  br i1 %or.cond, label %L300, label %L232

L232:                                             ; preds = %L218
  %100 = getelementptr i8, i8* %12, i64 24
  %101 = bitcast i8* %100 to double*
  store double -5.000000e+02, double* %101, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i32 0, i32* %31, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %102 = getelementptr i8, i8* %12, i64 56
  %103 = bitcast i8* %102 to i32*
  store i32 1, i32* %103, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %104 = getelementptr i8, i8* %12, i64 200
  %105 = bitcast i8* %104 to i64*
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(16) %33, i8 0, i64 16, i1 false)
  %106 = load i64, i64* %105, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not83 = icmp eq i64 %106, 0
  br i1 %.not83, label %L300, label %L267

L267:                                             ; preds = %L232
  %107 = inttoptr i64 %106 to i8*
  %108 = call fastcc i32 @julia_game_loop_1955u1960(i32 -1, i8* nonnull %107, i32 0)
  %109 = icmp sgt i32 %108, -1
  br i1 %109, label %L300, label %L276

L276:                                             ; preds = %L267
  call void @llvm.lifetime.start.p0i8(i64 40, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(40) %.sub, i8* noundef nonnull align 16 dereferenceable(40) getelementptr inbounds ([40 x i8], [40 x i8]* @_j_const8, i64 0, i64 0), i64 40, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub, i32 %108) #1
  br label %L300

L300:                                             ; preds = %L276, %L267, %L232, %L218
  call void @llvm.lifetime.end.p0i8(i64 40, i8* nonnull %.sub)
  %110 = getelementptr i8, i8* %12, i64 56
  %111 = bitcast i8* %110 to i32*
  %112 = load i32, i32* %111, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not84 = icmp eq i32 %112, 1
  br i1 %.not84, label %L307, label %L336

L307:                                             ; preds = %L300
  %113 = getelementptr i8, i8* %12, i64 24
  %114 = bitcast i8* %113 to double*
  %115 = load double, double* %114, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %116 = fcmp uge double %115, 0.000000e+00
  br i1 %116, label %L336, label %L314

L314:                                             ; preds = %L307
  %117 = inttoptr i64 %26 to i8*
  %118 = getelementptr i8, i8* %117, i64 4
  %119 = load i8, i8* %118, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %120 = and i8 %119, 1
  %.not85 = icmp eq i8 %120, 0
  br i1 %.not85, label %L336, label %L320

L320:                                             ; preds = %L314
  %121 = fmul double %115, 5.000000e-01
  store double %121, double* %114, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i32 0, i32* %111, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L336

L336:                                             ; preds = %L320, %L314, %L307, %L300
  %122 = load i32, i32* %31, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not86 = icmp eq i32 %122, 0
  br i1 %.not86, label %L343, label %L356

L343:                                             ; preds = %L336
  %123 = getelementptr i8, i8* %12, i64 24
  %124 = bitcast i8* %123 to double*
  %125 = load double, double* %124, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %126 = fmul double %20, 1.500000e+03
  %127 = fadd double %126, %125
  store double %127, double* %124, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L361

L356:                                             ; preds = %L336
  store i32 0, i32* %111, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L361

L361:                                             ; preds = %L356, %L343
  %128 = inttoptr i64 %0 to double*
  %129 = load double, double* %128, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %130 = load double, double* %59, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %131 = fmul double %20, %130
  %132 = fadd double %129, %131
  store double %132, double* %128, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %133 = getelementptr i8, i8* %12, i64 8
  %134 = bitcast i8* %133 to double*
  %135 = load double, double* %134, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %136 = getelementptr i8, i8* %12, i64 24
  %137 = bitcast i8* %136 to double*
  %138 = load double, double* %137, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %139 = fmul double %20, %138
  %140 = fadd double %135, %139
  store double %140, double* %134, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %141 = load double, double* %128, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %142 = fcmp uge double %141, 3.640000e+02
  br i1 %142, label %L413, label %L430thread-pre-split

L413:                                             ; preds = %L361
  %143 = fcmp ule double %141, 8.120000e+02
  br i1 %143, label %L430, label %L430thread-pre-split

L430thread-pre-split:                             ; preds = %L413, %L361
  %storemerge110 = phi double [ 3.640000e+02, %L361 ], [ 8.120000e+02, %L413 ]
  store double %storemerge110, double* %128, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store double 0.000000e+00, double* %59, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.pr = load double, double* %134, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L430

L430:                                             ; preds = %L430thread-pre-split, %L413
  %144 = phi double [ %.pr, %L430thread-pre-split ], [ %140, %L413 ]
  %145 = fcmp ult double %144, 7.320000e+02
  br i1 %145, label %L458.thread, label %L466

L458.thread:                                      ; preds = %L430
  store i32 0, i32* %31, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L476

L466:                                             ; preds = %L430
  store double 7.320000e+02, double* %134, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store double 0.000000e+00, double* %137, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i32 1, i32* %31, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %146 = load double, double* %59, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %147 = call double @llvm.fabs.f64(double %146)
  %148 = fcmp ule double %147, 1.000000e+00
  %.19 = select i1 %148, i32 0, i32 2
  br label %L476

L476:                                             ; preds = %L466, %L458.thread
  %value_phi3 = phi i32 [ %.19, %L466 ], [ 3, %L458.thread ]
  %149 = getelementptr i8, i8* %12, i64 192
  %150 = bitcast i8* %149 to i32*
  %151 = load i32, i32* %150, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not88 = icmp eq i32 %value_phi3, %151
  br i1 %.not88, label %L582, label %L485

L485:                                             ; preds = %L476
  call void @llvm.lifetime.start.p0i8(i64 31, i8* nonnull %.sub77)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(31) %.sub77, i8* noundef nonnull align 16 dereferenceable(31) getelementptr inbounds ([31 x i8], [31 x i8]* @_j_const11, i64 0, i64 0), i64 31, i1 false)
  %status.i15 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub77, i32 %value_phi3) #1
  store i32 %value_phi3, i32* %150, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  switch i32 %value_phi3, label %L485.L555_crit_edge [
    i32 0, label %L517
    i32 2, label %L531
    i32 3, label %L545
  ]

L485.L555_crit_edge:                              ; preds = %L485
  %.phi.trans.insert = getelementptr i8, i8* %12, i64 184
  %.phi.trans.insert106 = bitcast i8* %.phi.trans.insert to i64*
  %.pre = load i64, i64* %.phi.trans.insert106, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L555

L517:                                             ; preds = %L485
  %152 = getelementptr i8, i8* %12, i64 160
  %153 = bitcast i8* %152 to i64*
  %154 = load i64, i64* %153, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %155 = getelementptr i8, i8* %12, i64 184
  %156 = bitcast i8* %155 to i64*
  store i64 %154, i64* %156, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L555

L531:                                             ; preds = %L485
  %157 = getelementptr i8, i8* %12, i64 168
  %158 = bitcast i8* %157 to i64*
  %159 = load i64, i64* %158, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %160 = getelementptr i8, i8* %12, i64 184
  %161 = bitcast i8* %160 to i64*
  store i64 %159, i64* %161, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L555

L545:                                             ; preds = %L485
  %162 = getelementptr i8, i8* %12, i64 176
  %163 = bitcast i8* %162 to i64*
  %164 = load i64, i64* %163, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %165 = getelementptr i8, i8* %12, i64 184
  %166 = bitcast i8* %165 to i64*
  store i64 %164, i64* %166, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L555

L555:                                             ; preds = %L545, %L531, %L517, %L485.L555_crit_edge
  %167 = phi i64 [ %.pre, %L485.L555_crit_edge ], [ %164, %L545 ], [ %159, %L531 ], [ %154, %L517 ]
  %.not90 = icmp eq i64 %167, 0
  br i1 %.not90, label %L582, label %L565

L565:                                             ; preds = %L555
  %168 = inttoptr i64 %167 to i8*
  %169 = getelementptr i8, i8* %168, i64 28
  %170 = bitcast i8* %169 to i32*
  store i32 0, i32* %170, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %171 = getelementptr i8, i8* %168, i64 32
  %172 = bitcast i8* %171 to double*
  store double 0.000000e+00, double* %172, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %173 = getelementptr i8, i8* %168, i64 40
  store i8 0, i8* %173, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %L582

L582:                                             ; preds = %L565, %L555, %L476
  call void @llvm.lifetime.end.p0i8(i64 31, i8* nonnull %.sub77)
  %174 = getelementptr i8, i8* %12, i64 184
  %175 = bitcast i8* %174 to i64*
  %176 = load i64, i64* %175, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  call fastcc void @julia_update_animation_2004(i64 zeroext %176, double %20) #6
  call void @llvm.lifetime.start.p0i8(i64 4, i8* nonnull %6)
  store i32 0, i32* %5, align 8, !tbaa !18, !alias.scope !15, !noalias !16
  call void @llvm.lifetime.start.p0i8(i64 4, i8* nonnull %8)
  store i32 0, i32* %7, align 8, !tbaa !18, !alias.scope !15, !noalias !16
  %177 = inttoptr i64 %2 to i8*
  call fastcc void @julia_game_loop_1955u1964(i8* %177, i8* nonnull %6, i8* nonnull %8)
  %178 = load i32, i32* %5, align 8, !tbaa !18, !alias.scope !15, !noalias !16
  %179 = load i32, i32* %7, align 8, !tbaa !18, !alias.scope !15, !noalias !16
  %180 = load double, double* %128, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %181 = sitofp i32 %178 to double
  %182 = fmul double %181, 5.000000e-01
  %183 = fsub double %180, %182
  %184 = fadd double %183, 3.200000e+01
  %185 = load double, double* %134, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %186 = sitofp i32 %179 to double
  %187 = fmul double %186, 5.000000e-01
  %188 = fsub double %185, %187
  %189 = fadd double %188, 3.200000e+01
  %190 = getelementptr i8, i8* %12, i64 136
  %191 = bitcast i8* %190 to double*
  %192 = load double, double* %191, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %193 = fsub double %184, %192
  %194 = fmul double %193, 1.500000e-01
  %195 = fadd double %192, %194
  store double %195, double* %191, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %196 = getelementptr i8, i8* %12, i64 144
  %197 = bitcast i8* %196 to double*
  %198 = load double, double* %197, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %199 = fsub double %189, %198
  %200 = fmul double %199, 1.500000e-01
  %201 = fadd double %198, %200
  store double %201, double* %197, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %202 = fmul double %186, 2.500000e-01
  %203 = fdiv double %181, 3.000000e+00
  %204 = getelementptr i8, i8* %12, i64 152
  store i8 0, i8* %204, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %205 = getelementptr i8, i8* %12, i64 153
  store i8 0, i8* %205, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %206 = getelementptr i8, i8* %12, i64 154
  store i8 0, i8* %206, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  call void @llvm.lifetime.end.p0i8(i64 4, i8* nonnull %6)
  call void @llvm.lifetime.end.p0i8(i64 4, i8* nonnull %8)
  %207 = inttoptr i64 %1 to i8*
  call fastcc void @julia_game_loop_1955u1965(i8* %207, i8 0, i8 0, i8 0, i8 -1)
  call fastcc void @julia_game_loop_1955u1966(i8* %207)
  %208 = load double, double* %191, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %209 = fsub double 0.000000e+00, %208
  %210 = fptrunc double %209 to float
  %211 = load double, double* %197, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %212 = fsub double 7.320000e+02, %211
  %213 = fptrunc double %212 to float
  %214 = sitofp i32 %178 to float
  %215 = fadd double %186, -7.320000e+02
  %216 = fptrunc double %215 to float
  %217 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %.sroa.049.0..sroa_idx = bitcast i8* %217 to float*
  store float %210, float* %.sroa.049.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.250.0..sroa_idx51 = getelementptr inbounds i8, i8* %217, i64 4
  %218 = bitcast i8* %.sroa.250.0..sroa_idx51 to float*
  store float %213, float* %218, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.352.0..sroa_idx53 = getelementptr inbounds i8, i8* %217, i64 8
  %219 = bitcast i8* %.sroa.352.0..sroa_idx53 to float*
  store float %214, float* %219, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.454.0..sroa_idx55 = getelementptr inbounds i8, i8* %217, i64 12
  %220 = bitcast i8* %.sroa.454.0..sroa_idx55 to float*
  store float %216, float* %220, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  call fastcc void @julia_game_loop_1955u1965(i8* %207, i8 100, i8 70, i8 50, i8 -1)
  call fastcc void @julia_game_loop_1955u1969(i8* %207, i8* %217)
  call fastcc void @julia_cleanup_1939u1941(i8* %217)
  %221 = getelementptr i8, i8* %12, i64 112
  %222 = bitcast i8* %221 to i64*
  %223 = load i64, i64* %222, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not91 = icmp eq i64 %223, 0
  br i1 %.not91, label %L799, label %L757

L757:                                             ; preds = %L582
  %224 = inttoptr i64 %223 to { i64, i32, i32, i32, i32, i32, i32, i8, i8 }*
  %.sroa.8.0..sroa_idx = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %224, i64 0, i32 7
  %.sroa.8.0.copyload = load i8, i8* %.sroa.8.0..sroa_idx, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %225 = and i8 %.sroa.8.0.copyload, 1
  %.not101.not = icmp eq i8 %225, 0
  br i1 %.not101.not, label %L799, label %L763

L763:                                             ; preds = %L757
  %226 = load double, double* %197, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %227 = fsub double 0.000000e+00, %226
  %228 = fptrunc double %227 to float
  %229 = load double, double* %191, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %230 = fsub double 0.000000e+00, %229
  %231 = fptrunc double %230 to float
  %.sroa.9.0..sroa_idx = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %224, i64 0, i32 8
  %.sroa.9.0.copyload = load i8, i8* %.sroa.9.0..sroa_idx, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.7.0..sroa_idx41 = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %224, i64 0, i32 6
  %.sroa.7.0.copyload = load i32, i32* %.sroa.7.0..sroa_idx41, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.6.0..sroa_idx40 = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %224, i64 0, i32 5
  %.sroa.6.0.copyload = load i32, i32* %.sroa.6.0..sroa_idx40, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.5.0..sroa_idx39 = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %224, i64 0, i32 4
  %.sroa.5.0.copyload = load i32, i32* %.sroa.5.0..sroa_idx39, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.437.0..sroa_idx38 = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %224, i64 0, i32 3
  %.sroa.437.0.copyload = load i32, i32* %.sroa.437.0..sroa_idx38, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.335.0..sroa_idx36 = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %224, i64 0, i32 2
  %.sroa.335.0.copyload = load i32, i32* %.sroa.335.0..sroa_idx36, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.233.0..sroa_idx34 = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %224, i64 0, i32 1
  %.sroa.233.0.copyload = load i32, i32* %.sroa.233.0..sroa_idx34, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.032.0..sroa_idx = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %224, i64 0, i32 0
  %.sroa.032.0.copyload = load i64, i64* %.sroa.032.0..sroa_idx, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %232 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %.sroa.025.0..sroa_idx = bitcast i8* %232 to i32*
  store i32 %.sroa.437.0.copyload, i32* %.sroa.025.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.226.0..sroa_idx27 = getelementptr inbounds i8, i8* %232, i64 4
  %233 = bitcast i8* %.sroa.226.0..sroa_idx27 to i32*
  store i32 %.sroa.5.0.copyload, i32* %233, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.328.0..sroa_idx29 = getelementptr inbounds i8, i8* %232, i64 8
  %234 = bitcast i8* %.sroa.328.0..sroa_idx29 to i32*
  store i32 %.sroa.6.0.copyload, i32* %234, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.430.0..sroa_idx31 = getelementptr inbounds i8, i8* %232, i64 12
  %235 = bitcast i8* %.sroa.430.0..sroa_idx31 to i32*
  store i32 %.sroa.7.0.copyload, i32* %235, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %236 = sitofp i32 %.sroa.233.0.copyload to float
  %237 = sitofp i32 %.sroa.335.0.copyload to float
  %238 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %.sroa.0.0..sroa_idx = bitcast i8* %238 to float*
  store float %231, float* %.sroa.0.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.2.0..sroa_idx22 = getelementptr inbounds i8, i8* %238, i64 4
  %239 = bitcast i8* %.sroa.2.0..sroa_idx22 to float*
  store float %228, float* %239, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.3.0..sroa_idx23 = getelementptr inbounds i8, i8* %238, i64 8
  %240 = bitcast i8* %.sroa.3.0..sroa_idx23 to float*
  store float %236, float* %240, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.4.0..sroa_idx24 = getelementptr inbounds i8, i8* %238, i64 12
  %241 = bitcast i8* %.sroa.4.0..sroa_idx24 to float*
  store float %237, float* %241, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %242 = and i8 %.sroa.9.0.copyload, 1
  %243 = zext i8 %242 to i32
  %244 = inttoptr i64 %.sroa.032.0.copyload to i8*
  call fastcc void @julia_game_loop_1955u1994(i8* %207, i8* %244, i8* %232, i8* %238, double 0.000000e+00, i8* null, i32 %243)
  call fastcc void @julia_cleanup_1939u1941(i8* %238)
  call fastcc void @julia_cleanup_1939u1941(i8* %232)
  br label %L799

L799:                                             ; preds = %L763, %L757, %L582
  %245 = getelementptr i8, i8* %12, i64 104
  %246 = bitcast i8* %245 to i64*
  %247 = load i64, i64* %246, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not93 = icmp eq i64 %247, 0
  br i1 %.not93, label %L915, label %L809

L809:                                             ; preds = %L799
  %248 = inttoptr i64 %247 to i8*
  %249 = getelementptr i8, i8* %248, i64 33
  %250 = load i8, i8* %249, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %251 = and i8 %250, 1
  %.not94 = icmp eq i8 %251, 0
  br i1 %.not94, label %L856, label %L820

L820:                                             ; preds = %L809
  %252 = getelementptr i8, i8* %46, i64 1
  %253 = load i8, i8* %252, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %254 = and i8 %253, 1
  %.not95 = icmp eq i8 %254, 0
  br i1 %.not95, label %L879, label %L826

L826:                                             ; preds = %L820
  store i8 0, i8* %249, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  call void @llvm.lifetime.start.p0i8(i64 24, i8* nonnull %.sub78)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(24) %.sub78, i8* noundef nonnull align 16 dereferenceable(24) getelementptr inbounds ([24 x i8], [24 x i8]* @_j_const13, i64 0, i64 0), i64 24, i1 false)
  %status.i16 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub78) #1
  br label %L879

L856:                                             ; preds = %L809
  %255 = load i8, i8* %46, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %256 = and i8 %255, 1
  %.not100 = icmp eq i8 %256, 0
  br i1 %.not100, label %L879, label %L862

L862:                                             ; preds = %L856
  store i8 1, i8* %249, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  call void @llvm.lifetime.start.p0i8(i64 23, i8* nonnull %.sub79)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(23) %.sub79, i8* noundef nonnull align 16 dereferenceable(23) getelementptr inbounds ([23 x i8], [23 x i8]* @_j_const14, i64 0, i64 0), i64 23, i1 false)
  %status.i18 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub79) #1
  br label %L879

L879:                                             ; preds = %L862, %L856, %L826, %L820
  call void @llvm.lifetime.end.p0i8(i64 24, i8* nonnull %.sub78)
  call void @llvm.lifetime.end.p0i8(i64 23, i8* nonnull %.sub79)
  %257 = load i64, i64* %246, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %258 = load i64, i64* %175, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %259 = load double, double* %128, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %260 = load double, double* %191, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %261 = fsub double %259, %260
  %262 = fptrunc double %261 to float
  %263 = load double, double* %134, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %264 = load double, double* %197, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %265 = fsub double %263, %264
  %266 = fptrunc double %265 to float
  call fastcc void @render_sprite_animated_1997(i64 zeroext %1, i64 zeroext %257, i64 zeroext %258, float %262, float %266) #6
  br label %L952

L915:                                             ; preds = %L799
  %267 = load double, double* %128, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %268 = load double, double* %191, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %269 = fsub double %267, %268
  %270 = fptrunc double %269 to float
  %271 = load double, double* %134, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %272 = load double, double* %197, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %273 = fsub double %271, %272
  %274 = fptrunc double %273 to float
  %275 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %.sroa.042.0..sroa_idx = bitcast i8* %275 to float*
  store float %270, float* %.sroa.042.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.243.0..sroa_idx44 = getelementptr inbounds i8, i8* %275, i64 4
  %276 = bitcast i8* %.sroa.243.0..sroa_idx44 to float*
  store float %274, float* %276, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.345.0..sroa_idx46 = getelementptr inbounds i8, i8* %275, i64 8
  %277 = bitcast i8* %.sroa.345.0..sroa_idx46 to float*
  store float 6.400000e+01, float* %277, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.447.0..sroa_idx48 = getelementptr inbounds i8, i8* %275, i64 12
  %278 = bitcast i8* %.sroa.447.0..sroa_idx48 to float*
  store float 6.400000e+01, float* %278, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  call fastcc void @julia_game_loop_1955u1965(i8* %207, i8 -1, i8 0, i8 0, i8 -1)
  call fastcc void @julia_game_loop_1955u1969(i8* %207, i8* %275)
  call fastcc void @julia_cleanup_1939u1941(i8* %275)
  br label %L952

L952:                                             ; preds = %L915, %L879
  %279 = fsub double %186, %202
  %280 = fptrunc double %202 to float
  %281 = fptrunc double %203 to float
  %282 = fptrunc double %279 to float
  %283 = fmul double %203, 2.000000e+00
  %284 = fptrunc double %283 to float
  %285 = load i8, i8* %204, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %286 = and i8 %285, 1
  %.not96 = icmp eq i8 %286, 0
  %.21 = select i1 %.not96, i8 -56, i8 100
  call fastcc void @julia_game_loop_1955u1965(i8* %207, i8 %.21, i8 -56, i8 -56, i8 -76)
  %287 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %.sroa.070.0..sroa_idx = bitcast i8* %287 to float*
  store float 0.000000e+00, float* %.sroa.070.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.271.0..sroa_idx72 = getelementptr inbounds i8, i8* %287, i64 4
  %288 = bitcast i8* %.sroa.271.0..sroa_idx72 to float*
  store float %282, float* %288, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.373.0..sroa_idx74 = getelementptr inbounds i8, i8* %287, i64 8
  %289 = bitcast i8* %.sroa.373.0..sroa_idx74 to float*
  store float %281, float* %289, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.475.0..sroa_idx76 = getelementptr inbounds i8, i8* %287, i64 12
  %290 = bitcast i8* %.sroa.475.0..sroa_idx76 to float*
  store float %280, float* %290, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  call fastcc void @julia_game_loop_1955u1969(i8* %207, i8* %287)
  call fastcc void @julia_cleanup_1939u1941(i8* %287)
  %291 = load i8, i8* %205, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %292 = and i8 %291, 1
  %.not97 = icmp eq i8 %292, 0
  %value_phi9 = select i1 %.not97, i8 -56, i8 100
  call fastcc void @julia_game_loop_1955u1965(i8* %207, i8 %value_phi9, i8 -56, i8 -56, i8 -76)
  %293 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %.sroa.063.0..sroa_idx = bitcast i8* %293 to float*
  store float %284, float* %.sroa.063.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.264.0..sroa_idx65 = getelementptr inbounds i8, i8* %293, i64 4
  %294 = bitcast i8* %.sroa.264.0..sroa_idx65 to float*
  store float %282, float* %294, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.366.0..sroa_idx67 = getelementptr inbounds i8, i8* %293, i64 8
  %295 = bitcast i8* %.sroa.366.0..sroa_idx67 to float*
  store float %281, float* %295, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.468.0..sroa_idx69 = getelementptr inbounds i8, i8* %293, i64 12
  %296 = bitcast i8* %.sroa.468.0..sroa_idx69 to float*
  store float %280, float* %296, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  call fastcc void @julia_game_loop_1955u1969(i8* %207, i8* %293)
  call fastcc void @julia_cleanup_1939u1941(i8* %293)
  %297 = load i8, i8* %206, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %298 = and i8 %297, 1
  %.not98 = icmp eq i8 %298, 0
  %value_phi10 = select i1 %.not98, i8 -56, i8 100
  call fastcc void @julia_game_loop_1955u1965(i8* %207, i8 -56, i8 %value_phi10, i8 -56, i8 -76)
  %299 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %.sroa.056.0..sroa_idx = bitcast i8* %299 to float*
  store float %281, float* %.sroa.056.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.257.0..sroa_idx58 = getelementptr inbounds i8, i8* %299, i64 4
  %300 = bitcast i8* %.sroa.257.0..sroa_idx58 to float*
  store float %282, float* %300, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.359.0..sroa_idx60 = getelementptr inbounds i8, i8* %299, i64 8
  %301 = bitcast i8* %.sroa.359.0..sroa_idx60 to float*
  store float %281, float* %301, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.461.0..sroa_idx62 = getelementptr inbounds i8, i8* %299, i64 12
  %302 = bitcast i8* %.sroa.461.0..sroa_idx62 to float*
  store float %280, float* %302, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  call fastcc void @julia_game_loop_1955u1969(i8* %207, i8* %299)
  call fastcc void @julia_cleanup_1939u1941(i8* %299)
  call fastcc void @julia_game_loop_1955u1985(i8* %207)
  call fastcc void @julia_game_loop_1955u1986(i32 16)
  ret void
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #2

define internal fastcc i64 @julia_game_loop_1955u1957() unnamed_addr {
entry:
  %result = call i64 @SDL_GetPerformanceCounter()
  ret i64 %result
}

; Function Attrs: nounwind
declare i64 @SDL_GetPerformanceCounter() local_unnamed_addr #1

define internal fastcc i64 @julia_game_loop_1955u1958() unnamed_addr {
entry:
  %result = call i64 @SDL_GetPerformanceFrequency()
  ret i64 %result
}

; Function Attrs: nounwind
declare i64 @SDL_GetPerformanceFrequency() local_unnamed_addr #1

define internal fastcc i32 @julia_game_loop_1955u1960(i32 %channel, i8* %chunk, i32 %loops) unnamed_addr {
entry:
  %result = call i32 @Mix_PlayChannel(i32 %channel, i8* %chunk, i32 %loops)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @Mix_PlayChannel(i32, i8*, i32) local_unnamed_addr #1

declare i32 @printf(i8* noalias nocapture, ...) local_unnamed_addr

define internal fastcc void @julia_game_loop_1955u1964(i8* %window, i8* %w, i8* %h) unnamed_addr {
entry:
  call void @SDL_GetWindowSize(i8* %window, i8* %w, i8* %h)
  ret void
}

define internal fastcc void @julia_game_loop_1955u1965(i8* %renderer, i8 %r, i8 %g, i8 %b, i8 %a) unnamed_addr {
entry:
  %result = call i32 @SDL_SetRenderDrawColor(i8* %renderer, i8 %r, i8 %g, i8 %b, i8 %a)
  ret void
}

; Function Attrs: nounwind
declare i32 @SDL_SetRenderDrawColor(i8*, i8, i8, i8, i8) local_unnamed_addr #1

define internal fastcc void @julia_game_loop_1955u1966(i8* %renderer) unnamed_addr {
entry:
  %result = call i32 @SDL_RenderClear(i8* %renderer)
  ret void
}

; Function Attrs: nounwind
declare i32 @SDL_RenderClear(i8*) local_unnamed_addr #1

define internal fastcc i8* @julia_game_loop_1955u1967(i32 %size) unnamed_addr {
entry:
  %ptr = call noalias i8* @malloc(i32 %size)
  ret i8* %ptr
}

define internal fastcc void @julia_game_loop_1955u1969(i8* %renderer, i8* %rect) unnamed_addr {
entry:
  %result = call i32 @SDL_RenderFillRectF(i8* %renderer, i8* %rect)
  ret void
}

; Function Attrs: nounwind
declare i32 @SDL_RenderFillRectF(i8*, i8*) local_unnamed_addr #1

define internal fastcc void @julia_game_loop_1955u1985(i8* %renderer) unnamed_addr {
entry:
  call void @SDL_RenderPresent(i8* %renderer)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_RenderPresent(i8*) local_unnamed_addr #1

define internal fastcc void @julia_game_loop_1955u1986(i32 %ms) unnamed_addr {
entry:
  call void @SDL_Delay(i32 %ms)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_Delay(i32) local_unnamed_addr #1

define internal fastcc void @julia_game_loop_1955u1994(i8* %renderer, i8* %texture, i8* %srcrect, i8* %dstrect, double %angle, i8* %center, i32 %flip) unnamed_addr {
entry:
  %result = call i32 @SDL_RenderCopyExF(i8* %renderer, i8* %texture, i8* %srcrect, i8* %dstrect, double %angle, i8* %center, i32 %flip)
  ret void
}

define internal fastcc void @julia_cleanup_1939(i64 zeroext %0, i64 zeroext %1, i64 zeroext %2) unnamed_addr {
top:
  %3 = inttoptr i64 %0 to i8*
  %4 = getelementptr i8, i8* %3, i64 160
  %5 = bitcast i8* %4 to i64*
  %6 = load i64, i64* %5, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not = icmp eq i64 %6, 0
  br i1 %.not, label %L33, label %L11

L11:                                              ; preds = %top
  %7 = inttoptr i64 %6 to i64*
  %8 = load i64, i64* %7, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not11 = icmp eq i64 %8, 0
  br i1 %.not11, label %L29, label %L21

L21:                                              ; preds = %L11
  %9 = inttoptr i64 %8 to i8*
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %9)
  br label %L29

L29:                                              ; preds = %L21, %L11
  %10 = inttoptr i64 %6 to i8*
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %10)
  br label %L33

L33:                                              ; preds = %L29, %top
  %11 = getelementptr i8, i8* %3, i64 168
  %12 = bitcast i8* %11 to i64*
  %13 = load i64, i64* %12, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not3 = icmp eq i64 %13, 0
  br i1 %.not3, label %L65, label %L43

L43:                                              ; preds = %L33
  %14 = inttoptr i64 %13 to i64*
  %15 = load i64, i64* %14, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not10 = icmp eq i64 %15, 0
  br i1 %.not10, label %L61, label %L53

L53:                                              ; preds = %L43
  %16 = inttoptr i64 %15 to i8*
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %16)
  br label %L61

L61:                                              ; preds = %L53, %L43
  %17 = inttoptr i64 %13 to i8*
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %17)
  br label %L65

L65:                                              ; preds = %L61, %L33
  %18 = getelementptr i8, i8* %3, i64 176
  %19 = bitcast i8* %18 to i64*
  %20 = load i64, i64* %19, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not4 = icmp eq i64 %20, 0
  br i1 %.not4, label %L97, label %L75

L75:                                              ; preds = %L65
  %21 = inttoptr i64 %20 to i64*
  %22 = load i64, i64* %21, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not9 = icmp eq i64 %22, 0
  br i1 %.not9, label %L93, label %L85

L85:                                              ; preds = %L75
  %23 = inttoptr i64 %22 to i8*
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %23)
  br label %L93

L93:                                              ; preds = %L85, %L75
  %24 = inttoptr i64 %20 to i8*
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %24)
  br label %L97

L97:                                              ; preds = %L93, %L65
  %25 = getelementptr i8, i8* %3, i64 104
  %26 = bitcast i8* %25 to i64*
  %27 = load i64, i64* %26, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not5 = icmp eq i64 %27, 0
  br i1 %.not5, label %L135, label %L117

L117:                                             ; preds = %L97
  %28 = inttoptr i64 %27 to { i64, i32, i32, i32, i32, i32, i32, i8, i8 }*
  %.sroa.0.0..sroa_idx = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %28, i64 0, i32 0
  %.sroa.0.0.copyload = load i64, i64* %.sroa.0.0..sroa_idx, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %.sroa.32.0..sroa_idx = getelementptr inbounds { i64, i32, i32, i32, i32, i32, i32, i8, i8 }, { i64, i32, i32, i32, i32, i32, i32, i8, i8 }* %28, i64 0, i32 7
  %.sroa.32.0.copyload = load i8, i8* %.sroa.32.0..sroa_idx, align 1, !tbaa !2, !alias.scope !5, !noalias !9
  %29 = and i8 %.sroa.32.0.copyload, 1
  %.not7 = icmp eq i8 %29, 0
  %.not8 = icmp eq i64 %.sroa.0.0.copyload, 0
  %or.cond = select i1 %.not7, i1 true, i1 %.not8
  br i1 %or.cond, label %L130, label %L127

L127:                                             ; preds = %L117
  %30 = inttoptr i64 %.sroa.0.0.copyload to i8*
  call fastcc void @julia_cleanup_1939u1947(i8* nonnull %30)
  br label %L130

L130:                                             ; preds = %L127, %L117
  %31 = inttoptr i64 %27 to i8*
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %31)
  br label %L135

L135:                                             ; preds = %L130, %L97
  %32 = getelementptr i8, i8* %3, i64 72
  %33 = bitcast i8* %32 to i64*
  %34 = load i64, i64* %33, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %35 = inttoptr i64 %34 to i8*
  call fastcc void @julia_cleanup_1939u1941(i8* %35)
  %36 = getelementptr i8, i8* %3, i64 64
  %37 = bitcast i8* %36 to i64*
  %38 = load i64, i64* %37, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %39 = inttoptr i64 %38 to i8*
  call fastcc void @julia_cleanup_1939u1941(i8* %39)
  %40 = getelementptr i8, i8* %3, i64 80
  %41 = bitcast i8* %40 to i64*
  %42 = load i64, i64* %41, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %43 = inttoptr i64 %42 to i8*
  call fastcc void @julia_cleanup_1939u1941(i8* %43)
  %44 = inttoptr i64 %1 to i8*
  call fastcc void @julia_cleanup_1939u1944(i8* %44)
  %45 = inttoptr i64 %2 to i8*
  call fastcc void @julia_cleanup_1939u1945(i8* %45)
  call fastcc void @julia_cleanup_1939u1946()
  ret void
}

define internal fastcc void @julia_cleanup_1939u1941(i8* %ptr) unnamed_addr {
entry:
  call void @free(i8* %ptr)
  ret void
}

define internal fastcc void @julia_cleanup_1939u1944(i8* %renderer) unnamed_addr {
entry:
  call void @SDL_DestroyRenderer(i8* %renderer)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_DestroyRenderer(i8*) local_unnamed_addr #1

define internal fastcc void @julia_cleanup_1939u1945(i8* %window) unnamed_addr {
entry:
  call void @SDL_DestroyWindow(i8* %window)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_DestroyWindow(i8*) local_unnamed_addr #1

define internal fastcc void @julia_cleanup_1939u1946() unnamed_addr {
entry:
  call void @SDL_Quit()
  ret void
}

; Function Attrs: nounwind
declare void @SDL_Quit() local_unnamed_addr #1

define internal fastcc void @julia_cleanup_1939u1947(i8* %texture) unnamed_addr {
entry:
  call void @SDL_DestroyTexture(i8* %texture)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_DestroyTexture(i8*) local_unnamed_addr #1

define i32 @pc_main() local_unnamed_addr {
top:
  %0 = alloca [27 x i8], align 16
  %.sub = getelementptr inbounds [27 x i8], [27 x i8]* %0, i64 0, i64 0
  call fastcc void @julia_pc_main_1930u1932(i32 32)
  %1 = call fastcc i64 @julia_j_init_window_2106() #6
  %2 = inttoptr i64 %1 to i8*
  %3 = call fastcc i8* @julia_pc_main_1930u1934(i8* %2, i32 -1, i32 2)
  %4 = ptrtoint i8* %3 to i64
  %.not = icmp eq i8* %3, null
  br i1 %.not, label %L10, label %L18

L10:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 27, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(27) %.sub, i8* noundef nonnull align 16 dereferenceable(27) getelementptr inbounds ([27 x i8], [27 x i8]* @_j_const1, i64 0, i64 0), i64 27, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #1
  br label %L18

L18:                                              ; preds = %L10, %top
  call void @llvm.lifetime.end.p0i8(i64 27, i8* nonnull %.sub)
  %5 = call fastcc i64 @julia_j_init_game_state_2019(i64 zeroext %4) #6
  %6 = inttoptr i64 %5 to i8*
  %7 = getelementptr i8, i8* %6, i64 96
  %8 = load i8, i8* %7, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %9 = and i8 %8, 1
  %.not2.not3 = icmp eq i8 %9, 0
  br i1 %.not2.not3, label %L26, label %L28

L26:                                              ; preds = %L26, %L18
  call fastcc void @julia_game_loop_1955(i64 zeroext %5, i64 zeroext %4, i64 zeroext %1) #6
  %10 = load i8, i8* %7, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %11 = and i8 %10, 1
  %.not2.not = icmp eq i8 %11, 0
  br i1 %.not2.not, label %L26, label %L28

L28:                                              ; preds = %L26, %L18
  call fastcc void @julia_cleanup_1939(i64 zeroext %5, i64 zeroext %4, i64 zeroext %1) #6
  ret i32 0
}

define internal fastcc void @julia_pc_main_1930u1932(i32 %flags) unnamed_addr {
entry:
  %result = call i32 @SDL_Init(i32 %flags)
  ret void
}

; Function Attrs: nounwind
declare i32 @SDL_Init(i32) local_unnamed_addr #1

define internal fastcc i8* @julia_pc_main_1930u1934(i8* %window, i32 %index, i32 %flags) unnamed_addr {
entry:
  %result = call i8* @SDL_CreateRenderer(i8* %window, i32 %index, i32 %flags)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_CreateRenderer(i8*, i32, i32) local_unnamed_addr #1

define internal fastcc i64 @julia_j_init_window_2106() unnamed_addr {
top:
  %0 = alloca [25 x i8], align 16
  %1 = alloca [11 x i8], align 16
  %2 = call fastcc i8* @julia_game_loop_1955u1967(i32 10)
  store i8 71, i8* %2, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %3 = getelementptr i8, i8* %2, i64 1
  store i8 97, i8* %3, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %4 = getelementptr i8, i8* %2, i64 2
  store i8 109, i8* %4, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %5 = getelementptr i8, i8* %2, i64 3
  store i8 101, i8* %5, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %6 = getelementptr i8, i8* %2, i64 4
  store i8 32, i8* %6, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %7 = getelementptr i8, i8* %2, i64 5
  store i8 116, i8* %7, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %8 = getelementptr i8, i8* %2, i64 6
  store i8 101, i8* %8, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %9 = getelementptr i8, i8* %2, i64 7
  store i8 115, i8* %9, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %10 = getelementptr i8, i8* %2, i64 8
  store i8 116, i8* %10, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %11 = getelementptr i8, i8* %2, i64 9
  store i8 0, i8* %11, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.sub = getelementptr inbounds [25 x i8], [25 x i8]* %0, i64 0, i64 0
  %.sub12 = getelementptr inbounds [11 x i8], [11 x i8]* %1, i64 0, i64 0
  %12 = call fastcc i8* @julia_game_loop_1955u1967(i32 10)
  %13 = load i8, i8* %2, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %13, i8* %12, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %14 = getelementptr i8, i8* %12, i64 1
  %15 = load i8, i8* %3, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %15, i8* %14, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %16 = getelementptr i8, i8* %12, i64 2
  %17 = load i8, i8* %4, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %17, i8* %16, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %18 = getelementptr i8, i8* %12, i64 3
  %19 = load i8, i8* %5, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %19, i8* %18, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %20 = getelementptr i8, i8* %12, i64 4
  %21 = load i8, i8* %6, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %21, i8* %20, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %22 = getelementptr i8, i8* %12, i64 5
  %23 = load i8, i8* %7, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %23, i8* %22, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %24 = getelementptr i8, i8* %12, i64 6
  %25 = load i8, i8* %8, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %25, i8* %24, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %26 = getelementptr i8, i8* %12, i64 7
  %27 = load i8, i8* %9, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %27, i8* %26, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %28 = getelementptr i8, i8* %12, i64 8
  %29 = load i8, i8* %10, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %29, i8* %28, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %30 = getelementptr i8, i8* %12, i64 9
  %31 = load i8, i8* %11, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %31, i8* %30, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %32 = getelementptr i8, i8* %12, i64 10
  store i8 0, i8* %32, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %33 = call fastcc i8* @julia_j_init_window_2106u2110(i8* nonnull %12, i32 0, i32 0, i32 640, i32 640, i32 0)
  %.not = icmp eq i8* %33, null
  br i1 %.not, label %L77, label %L115

L77:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 25, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(25) %.sub, i8* noundef nonnull align 16 dereferenceable(25) getelementptr inbounds ([25 x i8], [25 x i8]* @_j_const68, i64 0, i64 0), i64 25, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #1
  call void @llvm.lifetime.end.p0i8(i64 25, i8* nonnull %.sub)
  %34 = call fastcc i8* @julia_game_loop_1955u1967(i32 100)
  %35 = call fastcc i8* @julia_init_sprite_system_2095u2102(i8* %34, i32 100)
  call void @llvm.lifetime.start.p0i8(i64 11, i8* nonnull %.sub12)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(11) %.sub12, i8* noundef nonnull align 1 dereferenceable(11) getelementptr inbounds ([11 x i8], [11 x i8]* @_j_const51, i64 0, i64 0), i64 11, i1 false)
  %status.i14 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub12, i8* %35) #1
  call void @llvm.lifetime.end.p0i8(i64 11, i8* nonnull %.sub12)
  call fastcc void @julia_cleanup_1939u1941(i8* %34)
  br label %L115

L115:                                             ; preds = %L77, %top
  %36 = ptrtoint i8* %33 to i64
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %12)
  ret i64 %36
}

define internal fastcc i8* @julia_j_init_window_2106u2110(i8* %title, i32 %x, i32 %y, i32 %w, i32 %h, i32 %flags) unnamed_addr {
entry:
  %result = call i8* @SDL_CreateWindow(i8* %title, i32 %x, i32 %y, i32 %w, i32 %h, i32 %flags)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_CreateWindow(i8*, i32, i32, i32, i32, i32) local_unnamed_addr #1

; Function Attrs: nounwind
declare i8* @SDL_GetErrorMsg(i8*, i32) local_unnamed_addr #1

define internal fastcc i64 @julia_load_sprite_2079(i64 zeroext %0, i64 zeroext %1, i32 signext %2, i32 signext %3, i32 signext %4, i32 signext %5, i32 signext %6, i32 signext %7) unnamed_addr {
top:
  %8 = alloca [20 x i8], align 16
  %.sub = getelementptr inbounds [20 x i8], [20 x i8]* %8, i64 0, i64 0
  %9 = alloca [13 x i8], align 16
  %.sub23 = getelementptr inbounds [13 x i8], [13 x i8]* %9, i64 0, i64 0
  %10 = alloca [28 x i8], align 16
  %.sub24 = getelementptr inbounds [28 x i8], [28 x i8]* %10, i64 0, i64 0
  %11 = alloca [11 x i8], align 16
  %.sub25 = getelementptr inbounds [11 x i8], [11 x i8]* %11, i64 0, i64 0
  %12 = alloca [39 x i8], align 16
  %.sub26 = getelementptr inbounds [39 x i8], [39 x i8]* %12, i64 0, i64 0
  %13 = alloca [39 x i8], align 16
  %.sub27 = getelementptr inbounds [39 x i8], [39 x i8]* %13, i64 0, i64 0
  %14 = alloca [32 x i8], align 16
  %.sub28 = getelementptr inbounds [32 x i8], [32 x i8]* %14, i64 0, i64 0
  call void @llvm.lifetime.start.p0i8(i64 20, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(20) %.sub, i8* noundef nonnull align 16 dereferenceable(20) getelementptr inbounds ([20 x i8], [20 x i8]* @_j_const57, i64 0, i64 0), i64 20, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #1
  call void @llvm.lifetime.end.p0i8(i64 20, i8* nonnull %.sub)
  %15 = inttoptr i64 %1 to i8*
  %16 = call fastcc i8* @julia_load_sprite_2079u2082(i8* %15)
  %17 = ptrtoint i8* %16 to i64
  call void @llvm.lifetime.start.p0i8(i64 13, i8* nonnull %.sub23)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(13) %.sub23, i8* noundef nonnull align 1 dereferenceable(13) getelementptr inbounds ([13 x i8], [13 x i8]* @_j_const58, i64 0, i64 0), i64 13, i1 false)
  %status.i8 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub23, i64 %17) #1
  %.not = icmp eq i8* %16, null
  call void @llvm.lifetime.end.p0i8(i64 13, i8* nonnull %.sub23)
  br i1 %.not, label %L38, label %L46

common.ret:                                       ; preds = %L93, %L85, %L38
  %common.ret.op = phi i64 [ 0, %L38 ], [ 0, %L85 ], [ %30, %L93 ]
  call void @llvm.lifetime.end.p0i8(i64 28, i8* nonnull %.sub24)
  call void @llvm.lifetime.end.p0i8(i64 39, i8* nonnull %.sub26)
  call void @llvm.lifetime.end.p0i8(i64 32, i8* nonnull %.sub28)
  ret i64 %common.ret.op

L38:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 28, i8* nonnull %.sub24)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(28) %.sub24, i8* noundef nonnull align 16 dereferenceable(28) getelementptr inbounds ([28 x i8], [28 x i8]* @_j_const59, i64 0, i64 0), i64 28, i1 false)
  %status.i10 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub24) #1
  br label %common.ret

L46:                                              ; preds = %top
  %18 = call fastcc i8* @julia_game_loop_1955u1967(i32 1024)
  %19 = call fastcc i8* @julia_init_sprite_system_2095u2102(i8* %18, i32 1024)
  call void @llvm.lifetime.start.p0i8(i64 11, i8* nonnull %.sub25)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(11) %.sub25, i8* noundef nonnull align 1 dereferenceable(11) getelementptr inbounds ([11 x i8], [11 x i8]* @_j_const51, i64 0, i64 0), i64 11, i1 false)
  %status.i31 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub25, i8* %19) #1
  call void @llvm.lifetime.end.p0i8(i64 11, i8* nonnull %.sub25)
  call fastcc void @julia_cleanup_1939u1941(i8* %18)
  %20 = inttoptr i64 %0 to i8*
  %21 = call fastcc i8* @julia_load_sprite_2079u2089(i8* %20, i8* nonnull %16)
  call fastcc void @julia_load_sprite_2079u2090(i8* nonnull %16)
  %.not29 = icmp eq i8* %21, null
  br i1 %.not29, label %L85, label %L93

L85:                                              ; preds = %L46
  call void @llvm.lifetime.start.p0i8(i64 39, i8* nonnull %.sub26)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(39) %.sub26, i8* noundef nonnull align 16 dereferenceable(39) getelementptr inbounds ([39 x i8], [39 x i8]* @_j_const60, i64 0, i64 0), i64 39, i1 false)
  %status.i12 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub26) #1
  br label %common.ret

L93:                                              ; preds = %L46
  %22 = ptrtoint i8* %21 to i64
  %23 = getelementptr i8, i8* %16, i64 16
  %24 = bitcast i8* %23 to i32*
  %25 = load i32, i32* %24, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %26 = getelementptr i8, i8* %16, i64 20
  %27 = bitcast i8* %26 to i32*
  %28 = load i32, i32* %27, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  call void @llvm.lifetime.start.p0i8(i64 39, i8* nonnull %.sub27)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(39) %.sub27, i8* noundef nonnull align 16 dereferenceable(39) getelementptr inbounds ([39 x i8], [39 x i8]* @_j_const61, i64 0, i64 0), i64 39, i1 false)
  %status.i14 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub27, i32 %25, i32 %28) #1
  call void @llvm.lifetime.end.p0i8(i64 39, i8* nonnull %.sub27)
  %29 = call fastcc i8* @julia_game_loop_1955u1967(i32 40)
  %30 = ptrtoint i8* %29 to i64
  %.sroa.0.0..sroa_idx = bitcast i8* %29 to i64*
  store i64 %22, i64* %.sroa.0.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.2.0..sroa_idx17 = getelementptr inbounds i8, i8* %29, i64 8
  %31 = bitcast i8* %.sroa.2.0..sroa_idx17 to i32*
  store i32 %6, i32* %31, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.3.0..sroa_idx18 = getelementptr inbounds i8, i8* %29, i64 12
  %32 = bitcast i8* %.sroa.3.0..sroa_idx18 to i32*
  store i32 %7, i32* %32, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.4.0..sroa_idx19 = getelementptr inbounds i8, i8* %29, i64 16
  %33 = bitcast i8* %.sroa.4.0..sroa_idx19 to i32*
  store i32 %2, i32* %33, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.5.0..sroa_idx20 = getelementptr inbounds i8, i8* %29, i64 20
  %34 = bitcast i8* %.sroa.5.0..sroa_idx20 to i32*
  store i32 %3, i32* %34, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.6.0..sroa_idx21 = getelementptr inbounds i8, i8* %29, i64 24
  %35 = bitcast i8* %.sroa.6.0..sroa_idx21 to i32*
  store i32 %4, i32* %35, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.7.0..sroa_idx22 = getelementptr inbounds i8, i8* %29, i64 28
  %36 = bitcast i8* %.sroa.7.0..sroa_idx22 to i32*
  store i32 %5, i32* %36, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %37 = getelementptr inbounds i8, i8* %29, i64 32
  store i8 1, i8* %37, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %38 = getelementptr inbounds i8, i8* %29, i64 33
  store i8 0, i8* %38, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  call void @llvm.lifetime.start.p0i8(i64 32, i8* nonnull %.sub28)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(32) %.sub28, i8* noundef nonnull align 16 dereferenceable(32) getelementptr inbounds ([32 x i8], [32 x i8]* @_j_const62, i64 0, i64 0), i64 32, i1 false)
  %status.i16 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub28) #1
  br label %common.ret
}

define internal fastcc i8* @julia_load_sprite_2079u2082(i8* %file) unnamed_addr {
entry:
  %result = call i8* @IMG_Load(i8* %file)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @IMG_Load(i8*) local_unnamed_addr #1

define internal fastcc i8* @julia_load_sprite_2079u2089(i8* %renderer, i8* %surface) unnamed_addr {
entry:
  %result = call i8* @SDL_CreateTextureFromSurface(i8* %renderer, i8* %surface)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_CreateTextureFromSurface(i8*, i8*) local_unnamed_addr #1

define internal fastcc void @julia_load_sprite_2079u2090(i8* %surface) unnamed_addr {
entry:
  call void @SDL_FreeSurface(i8* %surface)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_FreeSurface(i8*) local_unnamed_addr #1

define internal fastcc i32 @julia_init_sprite_system_2095() unnamed_addr {
top:
  %0 = alloca [28 x i8], align 16
  %.sub = getelementptr inbounds [28 x i8], [28 x i8]* %0, i64 0, i64 0
  %1 = alloca [52 x i8], align 16
  %.sub11 = getelementptr inbounds [52 x i8], [52 x i8]* %1, i64 0, i64 0
  %2 = alloca [61 x i8], align 16
  %.sub12 = getelementptr inbounds [61 x i8], [61 x i8]* %2, i64 0, i64 0
  %3 = alloca [15 x i8], align 16
  %.sub13 = getelementptr inbounds [15 x i8], [15 x i8]* %3, i64 0, i64 0
  %4 = alloca [40 x i8], align 16
  %.sub14 = getelementptr inbounds [40 x i8], [40 x i8]* %4, i64 0, i64 0
  call void @llvm.lifetime.start.p0i8(i64 28, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(28) %.sub, i8* noundef nonnull align 16 dereferenceable(28) getelementptr inbounds ([28 x i8], [28 x i8]* @_j_const63, i64 0, i64 0), i64 28, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #1
  call void @llvm.lifetime.end.p0i8(i64 28, i8* nonnull %.sub)
  %5 = call fastcc i32 @julia_init_sprite_system_2095u2098(i32 2)
  call void @llvm.lifetime.start.p0i8(i64 52, i8* nonnull %.sub11)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(52) %.sub11, i8* noundef nonnull align 16 dereferenceable(52) getelementptr inbounds ([52 x i8], [52 x i8]* @_j_const64, i64 0, i64 0), i64 52, i1 false)
  %status.i6 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub11, i32 %5) #1
  %6 = and i32 %5, 2
  %.not = icmp eq i32 %6, 0
  call void @llvm.lifetime.end.p0i8(i64 52, i8* nonnull %.sub11)
  br i1 %.not, label %L37, label %L76

common.ret:                                       ; preds = %L76, %L37
  %common.ret.op = phi i32 [ -1, %L37 ], [ 0, %L76 ]
  call void @llvm.lifetime.end.p0i8(i64 40, i8* nonnull %.sub14)
  ret i32 %common.ret.op

L37:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 61, i8* nonnull %.sub12)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(61) %.sub12, i8* noundef nonnull align 16 dereferenceable(61) getelementptr inbounds ([61 x i8], [61 x i8]* @_j_const65, i64 0, i64 0), i64 61, i1 false)
  %status.i8 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub12) #1
  call void @llvm.lifetime.end.p0i8(i64 61, i8* nonnull %.sub12)
  %7 = call fastcc i8* @julia_game_loop_1955u1967(i32 1024)
  %8 = call fastcc i8* @julia_init_sprite_system_2095u2102(i8* %7, i32 1024)
  call void @llvm.lifetime.start.p0i8(i64 15, i8* nonnull %.sub13)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(15) %.sub13, i8* noundef nonnull align 1 dereferenceable(15) getelementptr inbounds ([15 x i8], [15 x i8]* @_j_const26, i64 0, i64 0), i64 15, i1 false)
  %status.i16 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub13, i8* %8) #1
  call void @llvm.lifetime.end.p0i8(i64 15, i8* nonnull %.sub13)
  call fastcc void @julia_cleanup_1939u1941(i8* %7)
  br label %common.ret

L76:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 40, i8* nonnull %.sub14)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(40) %.sub14, i8* noundef nonnull align 16 dereferenceable(40) getelementptr inbounds ([40 x i8], [40 x i8]* @_j_const66, i64 0, i64 0), i64 40, i1 false)
  %status.i10 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub14) #1
  br label %common.ret
}

define internal fastcc i32 @julia_init_sprite_system_2095u2098(i32 %flags) unnamed_addr {
entry:
  %result = call i32 @IMG_Init(i32 %flags)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @IMG_Init(i32) local_unnamed_addr #1

define internal fastcc i8* @julia_init_sprite_system_2095u2102(i8* %errstr, i32 %maxlen) unnamed_addr {
entry:
  %result = call i8* @SDL_GetErrorMsg(i8* %errstr, i32 %maxlen)
  ret i8* %result
}

define internal fastcc i64 @julia_j_init_game_state_2019(i64 zeroext %0) unnamed_addr {
top:
  %1 = alloca [25 x i8], align 16
  %.sub = getelementptr inbounds [25 x i8], [25 x i8]* %1, i64 0, i64 0
  %2 = alloca [7 x i8], align 8
  %.sub106 = getelementptr inbounds [7 x i8], [7 x i8]* %2, i64 0, i64 0
  %3 = alloca [14 x i8], align 16
  %.sub107 = getelementptr inbounds [14 x i8], [14 x i8]* %3, i64 0, i64 0
  %4 = alloca [36 x i8], align 16
  %.sub108 = getelementptr inbounds [36 x i8], [36 x i8]* %4, i64 0, i64 0
  %5 = alloca [27 x i8], align 16
  %.sub109 = getelementptr inbounds [27 x i8], [27 x i8]* %5, i64 0, i64 0
  %6 = alloca [60 x i8], align 16
  %.sub110 = getelementptr inbounds [60 x i8], [60 x i8]* %6, i64 0, i64 0
  %7 = alloca [15 x i8], align 16
  %.sub111 = getelementptr inbounds [15 x i8], [15 x i8]* %7, i64 0, i64 0
  %8 = alloca [53 x i8], align 16
  %.sub112 = getelementptr inbounds [53 x i8], [53 x i8]* %8, i64 0, i64 0
  %9 = alloca [45 x i8], align 16
  %.sub113 = getelementptr inbounds [45 x i8], [45 x i8]* %9, i64 0, i64 0
  %10 = alloca [15 x i8], align 16
  %.sub114 = getelementptr inbounds [15 x i8], [15 x i8]* %10, i64 0, i64 0
  %11 = alloca [34 x i8], align 16
  %.sub115 = getelementptr inbounds [34 x i8], [34 x i8]* %11, i64 0, i64 0
  %12 = alloca [40 x i8], align 16
  %.sub116 = getelementptr inbounds [40 x i8], [40 x i8]* %12, i64 0, i64 0
  %13 = alloca [19 x i8], align 16
  %.sub117 = getelementptr inbounds [19 x i8], [19 x i8]* %13, i64 0, i64 0
  %14 = alloca [49 x i8], align 16
  %.sub118 = getelementptr inbounds [49 x i8], [49 x i8]* %14, i64 0, i64 0
  %15 = alloca [28 x i8], align 16
  %.sub119 = getelementptr inbounds [28 x i8], [28 x i8]* %15, i64 0, i64 0
  %16 = alloca [24 x i8], align 16
  %.sub120 = getelementptr inbounds [24 x i8], [24 x i8]* %16, i64 0, i64 0
  %17 = alloca [23 x i8], align 16
  %.sub121 = getelementptr inbounds [23 x i8], [23 x i8]* %17, i64 0, i64 0
  %18 = alloca [11 x i8], align 16
  %.sub122 = getelementptr inbounds [11 x i8], [11 x i8]* %18, i64 0, i64 0
  %19 = alloca [27 x i8], align 16
  %.sub123 = getelementptr inbounds [27 x i8], [27 x i8]* %19, i64 0, i64 0
  %20 = alloca [11 x i8], align 16
  %.sub124 = getelementptr inbounds [11 x i8], [11 x i8]* %20, i64 0, i64 0
  %.sroa.14 = alloca [7 x i8], align 1
  %.sroa.18 = alloca [7 x i8], align 1
  %.sroa.23 = alloca [5 x i8], align 1
  call void @llvm.lifetime.start.p0i8(i64 25, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(25) %.sub, i8* noundef nonnull align 16 dereferenceable(25) getelementptr inbounds ([25 x i8], [25 x i8]* @_j_const19, i64 0, i64 0), i64 25, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #1
  call void @llvm.lifetime.end.p0i8(i64 25, i8* nonnull %.sub)
  call void @llvm.lifetime.start.p0i8(i64 7, i8* nonnull %.sub106)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 8 dereferenceable(7) %.sub106, i8* noundef nonnull align 1 dereferenceable(7) getelementptr inbounds ([7 x i8], [7 x i8]* @_j_const20, i64 0, i64 0), i64 7, i1 false)
  %status.i52 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub106) #1
  call void @llvm.lifetime.end.p0i8(i64 7, i8* nonnull %.sub106)
  %21 = call fastcc i8* @julia_j_init_game_state_2019u2023()
  call void @llvm.lifetime.start.p0i8(i64 14, i8* nonnull %.sub107)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(14) %.sub107, i8* noundef nonnull align 1 dereferenceable(14) getelementptr inbounds ([14 x i8], [14 x i8]* @_j_const21, i64 0, i64 0), i64 14, i1 false)
  %status.i138 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub107, i8* %21) #1
  call void @llvm.lifetime.end.p0i8(i64 14, i8* nonnull %.sub107)
  %22 = call fastcc i8* @julia_game_loop_1955u1967(i32 5)
  %23 = ptrtoint i8* %22 to i64
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(5) %22, i8 0, i64 5, i1 false)
  %24 = call fastcc i8* @julia_game_loop_1955u1967(i32 5)
  %25 = ptrtoint i8* %24 to i64
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(5) %24, i8 0, i64 5, i1 false)
  %26 = call fastcc i8* @julia_game_loop_1955u1967(i32 5)
  %27 = ptrtoint i8* %26 to i64
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(5) %26, i8 0, i64 5, i1 false)
  %28 = call fastcc i32 @julia_init_sprite_system_2095() #6
  %.not = icmp eq i32 %28, 0
  br i1 %.not, label %L69, label %L62

L62:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 36, i8* nonnull %.sub108)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(36) %.sub108, i8* noundef nonnull align 16 dereferenceable(36) getelementptr inbounds ([36 x i8], [36 x i8]* @_j_const23, i64 0, i64 0), i64 36, i1 false)
  %status.i54 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub108) #1
  br label %L69

L69:                                              ; preds = %L62, %top
  call void @llvm.lifetime.end.p0i8(i64 36, i8* nonnull %.sub108)
  call void @llvm.lifetime.start.p0i8(i64 27, i8* nonnull %.sub109)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(27) %.sub109, i8* noundef nonnull align 16 dereferenceable(27) getelementptr inbounds ([27 x i8], [27 x i8]* @_j_const24, i64 0, i64 0), i64 27, i1 false)
  %status.i56 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub109) #1
  call void @llvm.lifetime.end.p0i8(i64 27, i8* nonnull %.sub109)
  %29 = call fastcc i32 @julia_j_init_game_state_2019u2031(i32 16)
  %30 = and i32 %29, 16
  %.not125 = icmp eq i32 %30, 0
  br i1 %.not125, label %L81, label %L120

L81:                                              ; preds = %L69
  call void @llvm.lifetime.start.p0i8(i64 60, i8* nonnull %.sub110)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(60) %.sub110, i8* noundef nonnull align 16 dereferenceable(60) getelementptr inbounds ([60 x i8], [60 x i8]* @_j_const25, i64 0, i64 0), i64 60, i1 false)
  %status.i58 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub110) #1
  call void @llvm.lifetime.end.p0i8(i64 60, i8* nonnull %.sub110)
  %31 = call fastcc i8* @julia_game_loop_1955u1967(i32 256)
  %32 = call fastcc i8* @julia_init_sprite_system_2095u2102(i8* %31, i32 256)
  call void @llvm.lifetime.start.p0i8(i64 15, i8* nonnull %.sub111)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(15) %.sub111, i8* noundef nonnull align 1 dereferenceable(15) getelementptr inbounds ([15 x i8], [15 x i8]* @_j_const26, i64 0, i64 0), i64 15, i1 false)
  %status.i140 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub111, i8* %32) #1
  call void @llvm.lifetime.end.p0i8(i64 15, i8* nonnull %.sub111)
  call fastcc void @julia_cleanup_1939u1941(i8* %31)
  br label %L127

L120:                                             ; preds = %L69
  call void @llvm.lifetime.start.p0i8(i64 53, i8* nonnull %.sub112)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(53) %.sub112, i8* noundef nonnull align 16 dereferenceable(53) getelementptr inbounds ([53 x i8], [53 x i8]* @_j_const56, i64 0, i64 0), i64 53, i1 false)
  %status.i60 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub112) #1
  br label %L127

L127:                                             ; preds = %L120, %L81
  call void @llvm.lifetime.end.p0i8(i64 53, i8* nonnull %.sub112)
  %33 = call fastcc i32 @julia_j_init_game_state_2019u2037(i32 44100, i16 -32752, i32 2, i32 2048)
  %.not126 = icmp eq i32 %33, 0
  br i1 %.not126, label %L197, label %L308

L197:                                             ; preds = %L127
  call void @llvm.lifetime.start.p0i8(i64 34, i8* nonnull %.sub115)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(34) %.sub115, i8* noundef nonnull align 16 dereferenceable(34) getelementptr inbounds ([34 x i8], [34 x i8]* @_j_const55, i64 0, i64 0), i64 34, i1 false)
  %status.i63 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub115) #1
  call void @llvm.lifetime.end.p0i8(i64 34, i8* nonnull %.sub115)
  %34 = call fastcc i8* @julia_game_loop_1955u1967(i32 17)
  store i8 47, i8* %34, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %35 = getelementptr i8, i8* %34, i64 1
  store i8 97, i8* %35, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %36 = getelementptr i8, i8* %34, i64 2
  store i8 115, i8* %36, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %37 = getelementptr i8, i8* %34, i64 3
  store i8 115, i8* %37, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %38 = getelementptr i8, i8* %34, i64 4
  store i8 101, i8* %38, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %39 = getelementptr i8, i8* %34, i64 5
  store i8 116, i8* %39, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %40 = getelementptr i8, i8* %34, i64 6
  store i8 115, i8* %40, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %41 = getelementptr i8, i8* %34, i64 7
  store i8 47, i8* %41, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %42 = getelementptr i8, i8* %34, i64 8
  store i8 74, i8* %42, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %43 = getelementptr i8, i8* %34, i64 9
  store i8 117, i8* %43, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %44 = getelementptr i8, i8* %34, i64 10
  store i8 109, i8* %44, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %45 = getelementptr i8, i8* %34, i64 11
  store i8 112, i8* %45, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %46 = getelementptr i8, i8* %34, i64 12
  store i8 46, i8* %46, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %47 = getelementptr i8, i8* %34, i64 13
  store i8 119, i8* %47, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %48 = getelementptr i8, i8* %34, i64 14
  store i8 97, i8* %48, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %49 = getelementptr i8, i8* %34, i64 15
  store i8 118, i8* %49, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %50 = getelementptr i8, i8* %34, i64 16
  store i8 0, i8* %50, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %51 = call fastcc i8* @julia_game_loop_1955u1967(i32 17)
  %52 = load i8, i8* %34, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %52, i8* %51, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %53 = getelementptr i8, i8* %51, i64 1
  %54 = load i8, i8* %35, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %54, i8* %53, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %55 = getelementptr i8, i8* %51, i64 2
  %56 = load i8, i8* %36, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %56, i8* %55, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %57 = getelementptr i8, i8* %51, i64 3
  %58 = load i8, i8* %37, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %58, i8* %57, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %59 = getelementptr i8, i8* %51, i64 4
  %60 = load i8, i8* %38, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %60, i8* %59, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %61 = getelementptr i8, i8* %51, i64 5
  %62 = load i8, i8* %39, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %62, i8* %61, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %63 = getelementptr i8, i8* %51, i64 6
  %64 = load i8, i8* %40, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %64, i8* %63, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %65 = getelementptr i8, i8* %51, i64 7
  %66 = load i8, i8* %41, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %66, i8* %65, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %67 = getelementptr i8, i8* %51, i64 8
  %68 = load i8, i8* %42, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %68, i8* %67, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %69 = getelementptr i8, i8* %51, i64 9
  %70 = load i8, i8* %43, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %70, i8* %69, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %71 = getelementptr i8, i8* %51, i64 10
  %72 = load i8, i8* %44, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %72, i8* %71, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %73 = getelementptr i8, i8* %51, i64 11
  %74 = load i8, i8* %45, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %74, i8* %73, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %75 = getelementptr i8, i8* %51, i64 12
  %76 = load i8, i8* %46, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %76, i8* %75, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %77 = getelementptr i8, i8* %51, i64 13
  %78 = load i8, i8* %47, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %78, i8* %77, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %79 = getelementptr i8, i8* %51, i64 14
  %80 = load i8, i8* %48, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %80, i8* %79, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %81 = getelementptr i8, i8* %51, i64 15
  %82 = load i8, i8* %49, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %82, i8* %81, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %83 = getelementptr i8, i8* %51, i64 16
  %84 = load i8, i8* %50, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %84, i8* %83, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %85 = getelementptr i8, i8* %51, i64 17
  store i8 0, i8* %85, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %86 = call fastcc i8* @julia_j_init_game_state_2019u2045(i8* nonnull %51)
  %87 = call fastcc i32 @julia_game_loop_1955u1960(i32 -1, i8* %86, i32 0)
  %88 = icmp sgt i32 %87, -1
  br i1 %88, label %L297, label %L273

L273:                                             ; preds = %L197
  call void @llvm.lifetime.start.p0i8(i64 40, i8* nonnull %.sub116)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(40) %.sub116, i8* noundef nonnull align 16 dereferenceable(40) getelementptr inbounds ([40 x i8], [40 x i8]* @_j_const8, i64 0, i64 0), i64 40, i1 false)
  %status.i65 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub116, i32 %87) #1
  br label %L297

L297:                                             ; preds = %L273, %L197
  call void @llvm.lifetime.end.p0i8(i64 40, i8* nonnull %.sub116)
  call void @llvm.lifetime.start.p0i8(i64 19, i8* nonnull %.sub117)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(19) %.sub117, i8* noundef nonnull align 16 dereferenceable(19) getelementptr inbounds ([19 x i8], [19 x i8]* @_j_const30, i64 0, i64 0), i64 19, i1 false)
  %status.i67 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub117) #1
  call void @llvm.lifetime.end.p0i8(i64 19, i8* nonnull %.sub117)
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %51)
  br label %L315

L308:                                             ; preds = %L127
  call void @llvm.lifetime.start.p0i8(i64 45, i8* nonnull %.sub113)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(45) %.sub113, i8* noundef nonnull align 16 dereferenceable(45) getelementptr inbounds ([45 x i8], [45 x i8]* @_j_const27, i64 0, i64 0), i64 45, i1 false)
  %status.i61 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub113, i32 %33) #1
  call void @llvm.lifetime.end.p0i8(i64 45, i8* nonnull %.sub113)
  %89 = call fastcc i8* @julia_game_loop_1955u1967(i32 256)
  %90 = call fastcc i8* @julia_init_sprite_system_2095u2102(i8* %89, i32 256)
  call void @llvm.lifetime.start.p0i8(i64 15, i8* nonnull %.sub114)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(15) %.sub114, i8* noundef nonnull align 1 dereferenceable(15) getelementptr inbounds ([15 x i8], [15 x i8]* @_j_const26, i64 0, i64 0), i64 15, i1 false)
  %status.i142 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub114, i8* %90) #1
  call void @llvm.lifetime.end.p0i8(i64 15, i8* nonnull %.sub114)
  call fastcc void @julia_cleanup_1939u1941(i8* %89)
  call void @llvm.lifetime.end.p0i8(i64 34, i8* nonnull %.sub115)
  call void @llvm.lifetime.start.p0i8(i64 49, i8* nonnull %.sub118)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(49) %.sub118, i8* noundef nonnull align 16 dereferenceable(49) getelementptr inbounds ([49 x i8], [49 x i8]* @_j_const54, i64 0, i64 0), i64 49, i1 false)
  %status.i69 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub118) #1
  br label %L315

L315:                                             ; preds = %L308, %L297
  call void @llvm.lifetime.end.p0i8(i64 49, i8* nonnull %.sub118)
  call void @llvm.lifetime.start.p0i8(i64 28, i8* nonnull %.sub119)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(28) %.sub119, i8* noundef nonnull align 16 dereferenceable(28) getelementptr inbounds ([28 x i8], [28 x i8]* @_j_const31, i64 0, i64 0), i64 28, i1 false)
  %status.i71 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub119) #1
  call void @llvm.lifetime.end.p0i8(i64 28, i8* nonnull %.sub119)
  %91 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %92 = ptrtoint i8* %91 to i64
  %93 = bitcast i8* %91 to i32*
  store i32 120, i32* %93, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %94 = getelementptr i8, i8* %91, i64 4
  %95 = bitcast i8* %94 to i32*
  store i32 360, i32* %95, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %96 = getelementptr i8, i8* %91, i64 8
  %97 = bitcast i8* %96 to i32*
  store i32 8, i32* %97, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %98 = getelementptr i8, i8* %91, i64 12
  %99 = bitcast i8* %98 to i32*
  store i32 8, i32* %99, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %100 = call fastcc i8* @julia_game_loop_1955u1967(i32 48)
  %101 = ptrtoint i8* %100 to i64
  %102 = bitcast i8* %100 to i64*
  store i64 %92, i64* %102, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %103 = getelementptr i8, i8* %100, i64 8
  %104 = bitcast i8* %103 to i32*
  store i32 1, i32* %104, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %105 = getelementptr i8, i8* %100, i64 16
  %106 = bitcast i8* %105 to double*
  store double 2.000000e+00, double* %106, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %107 = getelementptr i8, i8* %100, i64 24
  store i8 1, i8* %107, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %108 = getelementptr i8, i8* %100, i64 28
  %109 = bitcast i8* %108 to i32*
  store i32 0, i32* %109, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %110 = getelementptr i8, i8* %100, i64 32
  %111 = bitcast i8* %110 to double*
  store double 0.000000e+00, double* %111, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %112 = getelementptr i8, i8* %100, i64 40
  store i8 0, i8* %112, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %113 = call fastcc i8* @julia_game_loop_1955u1967(i32 64)
  %114 = ptrtoint i8* %113 to i64
  %115 = bitcast i8* %113 to i32*
  store i32 16, i32* %115, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %116 = getelementptr i8, i8* %113, i64 4
  %117 = bitcast i8* %116 to i32*
  store i32 368, i32* %117, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %118 = getelementptr i8, i8* %113, i64 8
  %119 = bitcast i8* %118 to i32*
  store i32 8, i32* %119, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %120 = getelementptr i8, i8* %113, i64 12
  %121 = bitcast i8* %120 to i32*
  store i32 8, i32* %121, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %122 = getelementptr i8, i8* %113, i64 16
  %123 = bitcast i8* %122 to i32*
  store i32 24, i32* %123, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %124 = getelementptr i8, i8* %113, i64 20
  %125 = bitcast i8* %124 to i32*
  store i32 368, i32* %125, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %126 = getelementptr i8, i8* %113, i64 24
  %127 = bitcast i8* %126 to i32*
  store i32 8, i32* %127, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %128 = getelementptr i8, i8* %113, i64 28
  %129 = bitcast i8* %128 to i32*
  store i32 8, i32* %129, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %130 = getelementptr i8, i8* %113, i64 32
  %131 = bitcast i8* %130 to i32*
  store i32 32, i32* %131, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %132 = getelementptr i8, i8* %113, i64 36
  %133 = bitcast i8* %132 to i32*
  store i32 368, i32* %133, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %134 = getelementptr i8, i8* %113, i64 40
  %135 = bitcast i8* %134 to i32*
  store i32 8, i32* %135, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %136 = getelementptr i8, i8* %113, i64 44
  %137 = bitcast i8* %136 to i32*
  store i32 8, i32* %137, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %138 = getelementptr i8, i8* %113, i64 48
  %139 = bitcast i8* %138 to i32*
  store i32 40, i32* %139, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %140 = getelementptr i8, i8* %113, i64 52
  %141 = bitcast i8* %140 to i32*
  store i32 368, i32* %141, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %142 = getelementptr i8, i8* %113, i64 56
  %143 = bitcast i8* %142 to i32*
  store i32 8, i32* %143, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %144 = getelementptr i8, i8* %113, i64 60
  %145 = bitcast i8* %144 to i32*
  store i32 8, i32* %145, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %146 = call fastcc i8* @julia_game_loop_1955u1967(i32 48)
  %147 = ptrtoint i8* %146 to i64
  %148 = bitcast i8* %146 to i64*
  store i64 %114, i64* %148, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %149 = getelementptr i8, i8* %146, i64 8
  %150 = bitcast i8* %149 to i32*
  store i32 4, i32* %150, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %151 = getelementptr i8, i8* %146, i64 16
  %152 = bitcast i8* %151 to double*
  store double 8.000000e+00, double* %152, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %153 = getelementptr i8, i8* %146, i64 24
  store i8 1, i8* %153, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %154 = getelementptr i8, i8* %146, i64 28
  %155 = bitcast i8* %154 to i32*
  store i32 0, i32* %155, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %156 = getelementptr i8, i8* %146, i64 32
  %157 = bitcast i8* %156 to double*
  store double 0.000000e+00, double* %157, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %158 = getelementptr i8, i8* %146, i64 40
  store i8 0, i8* %158, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %159 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %160 = ptrtoint i8* %159 to i64
  %161 = bitcast i8* %159 to i32*
  store i32 8, i32* %161, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %162 = getelementptr i8, i8* %159, i64 4
  %163 = bitcast i8* %162 to i32*
  store i32 368, i32* %163, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %164 = getelementptr i8, i8* %159, i64 8
  %165 = bitcast i8* %164 to i32*
  store i32 8, i32* %165, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %166 = getelementptr i8, i8* %159, i64 12
  %167 = bitcast i8* %166 to i32*
  store i32 8, i32* %167, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %168 = call fastcc i8* @julia_game_loop_1955u1967(i32 48)
  %169 = ptrtoint i8* %168 to i64
  %170 = bitcast i8* %168 to i64*
  store i64 %160, i64* %170, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %171 = getelementptr i8, i8* %168, i64 8
  %172 = bitcast i8* %171 to i32*
  store i32 1, i32* %172, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %173 = getelementptr i8, i8* %168, i64 16
  %174 = bitcast i8* %173 to double*
  store double 1.000000e+00, double* %174, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %175 = getelementptr i8, i8* %168, i64 24
  store i8 0, i8* %175, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %176 = getelementptr i8, i8* %168, i64 28
  %177 = bitcast i8* %176 to i32*
  store i32 0, i32* %177, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %178 = getelementptr i8, i8* %168, i64 32
  %179 = bitcast i8* %178 to double*
  store double 0.000000e+00, double* %179, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %180 = getelementptr i8, i8* %168, i64 40
  store i8 0, i8* %180, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %181 = call fastcc i8* @julia_game_loop_1955u1967(i32 208)
  %.sroa.0.0..sroa_idx = bitcast i8* %181 to double*
  store double 5.000000e+02, double* %.sroa.0.0..sroa_idx, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.2.0..sroa_idx78 = getelementptr inbounds i8, i8* %181, i64 8
  %182 = bitcast i8* %.sroa.2.0..sroa_idx78 to double*
  store double 6.680000e+02, double* %182, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.3.0..sroa_idx79 = getelementptr inbounds i8, i8* %181, i64 16
  %.sroa.5.0..sroa_idx81 = getelementptr inbounds i8, i8* %181, i64 32
  %183 = bitcast i8* %.sroa.5.0..sroa_idx81 to i32*
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(16) %.sroa.3.0..sroa_idx79, i8 0, i64 16, i1 false)
  store i32 1, i32* %183, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.682.0..sroa_idx83 = getelementptr inbounds i8, i8* %181, i64 40
  %.sroa.986.0..sroa_idx87 = getelementptr inbounds i8, i8* %181, i64 64
  %184 = bitcast i8* %.sroa.986.0..sroa_idx87 to i64*
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(20) %.sroa.682.0..sroa_idx83, i8 0, i64 20, i1 false)
  store i64 %25, i64* %184, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.10.0..sroa_idx88 = getelementptr inbounds i8, i8* %181, i64 72
  %185 = bitcast i8* %.sroa.10.0..sroa_idx88 to i64*
  store i64 %23, i64* %185, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.11.0..sroa_idx89 = getelementptr inbounds i8, i8* %181, i64 80
  %186 = bitcast i8* %.sroa.11.0..sroa_idx89 to i64*
  store i64 %27, i64* %186, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.12.0..sroa_idx90 = getelementptr inbounds i8, i8* %181, i64 88
  %187 = bitcast i8* %.sroa.12.0..sroa_idx90 to i64*
  store i64 0, i64* %187, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %188 = getelementptr inbounds i8, i8* %181, i64 96
  store i8 0, i8* %188, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.14.0..sroa_raw_idx = getelementptr inbounds i8, i8* %181, i64 97
  %.sroa.14.0.sroa_idx = getelementptr inbounds [7 x i8], [7 x i8]* %.sroa.14, i64 0, i64 0
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(7) %.sroa.14.0..sroa_raw_idx, i8* noundef nonnull align 1 dereferenceable(7) %.sroa.14.0.sroa_idx, i64 7, i1 false), !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.1491.0..sroa_idx92 = getelementptr inbounds i8, i8* %181, i64 104
  %189 = bitcast i8* %.sroa.1491.0..sroa_idx92 to i64*
  %.sroa.15.0..sroa_idx93 = getelementptr inbounds i8, i8* %181, i64 112
  %190 = bitcast i8* %.sroa.15.0..sroa_idx93 to i64*
  %191 = getelementptr inbounds i8, i8* %181, i64 128
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(24) %.sroa.1491.0..sroa_idx92, i8 0, i64 24, i1 false)
  store i8 1, i8* %191, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.18.0..sroa_raw_idx = getelementptr inbounds i8, i8* %181, i64 129
  %.sroa.18.0.sroa_idx = getelementptr inbounds [7 x i8], [7 x i8]* %.sroa.18, i64 0, i64 0
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(7) %.sroa.18.0..sroa_raw_idx, i8* noundef nonnull align 1 dereferenceable(7) %.sroa.18.0.sroa_idx, i64 7, i1 false), !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.1895.0..sroa_idx96 = getelementptr inbounds i8, i8* %181, i64 136
  %192 = bitcast i8* %.sroa.1895.0..sroa_idx96 to double*
  store double 3.000000e+02, double* %192, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.19.0..sroa_idx97 = getelementptr inbounds i8, i8* %181, i64 144
  %193 = bitcast i8* %.sroa.19.0..sroa_idx97 to double*
  store double 2.200000e+02, double* %193, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %194 = getelementptr inbounds i8, i8* %181, i64 152
  store i8 0, i8* %194, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %195 = getelementptr inbounds i8, i8* %181, i64 153
  store i8 0, i8* %195, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %196 = getelementptr inbounds i8, i8* %181, i64 154
  store i8 0, i8* %196, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.23.0..sroa_raw_idx = getelementptr inbounds i8, i8* %181, i64 155
  %.sroa.23.0.sroa_idx = getelementptr inbounds [5 x i8], [5 x i8]* %.sroa.23, i64 0, i64 0
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(5) %.sroa.23.0..sroa_raw_idx, i8* noundef nonnull align 1 dereferenceable(5) %.sroa.23.0.sroa_idx, i64 5, i1 false), !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.2398.0..sroa_idx99 = getelementptr inbounds i8, i8* %181, i64 160
  %197 = bitcast i8* %.sroa.2398.0..sroa_idx99 to i64*
  store i64 %101, i64* %197, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.24.0..sroa_idx100 = getelementptr inbounds i8, i8* %181, i64 168
  %198 = bitcast i8* %.sroa.24.0..sroa_idx100 to i64*
  store i64 %147, i64* %198, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.25.0..sroa_idx101 = getelementptr inbounds i8, i8* %181, i64 176
  %199 = bitcast i8* %.sroa.25.0..sroa_idx101 to i64*
  store i64 %169, i64* %199, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.26.0..sroa_idx102 = getelementptr inbounds i8, i8* %181, i64 184
  %200 = bitcast i8* %.sroa.26.0..sroa_idx102 to i64*
  store i64 %101, i64* %200, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.27.0..sroa_idx103 = getelementptr inbounds i8, i8* %181, i64 192
  %201 = bitcast i8* %.sroa.27.0..sroa_idx103 to i32*
  store i32 0, i32* %201, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  %.sroa.28104.0..sroa_idx105 = getelementptr inbounds i8, i8* %181, i64 200
  %202 = bitcast i8* %.sroa.28104.0..sroa_idx105 to i64*
  store i64 0, i64* %202, align 1, !tbaa !2, !alias.scope !17, !noalias !9
  call void @llvm.lifetime.start.p0i8(i64 24, i8* nonnull %.sub120)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(24) %.sub120, i8* noundef nonnull align 16 dereferenceable(24) getelementptr inbounds ([24 x i8], [24 x i8]* @_j_const48, i64 0, i64 0), i64 24, i1 false)
  %status.i73 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub120) #1
  store i64 0, i64* %187, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 0, i8* %188, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %203 = load i64, i64* %189, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not129 = icmp eq i64 %203, 0
  br i1 %.not129, label %L621, label %L747

L621:                                             ; preds = %L315
  call void @llvm.lifetime.end.p0i8(i64 24, i8* nonnull %.sub120)
  call void @llvm.lifetime.start.p0i8(i64 23, i8* nonnull %.sub121)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(23) %.sub121, i8* noundef nonnull align 16 dereferenceable(23) getelementptr inbounds ([23 x i8], [23 x i8]* @_j_const49, i64 0, i64 0), i64 23, i1 false)
  %status.i75 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub121) #1
  call void @llvm.lifetime.end.p0i8(i64 23, i8* nonnull %.sub121)
  %204 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  store i8 97, i8* %204, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %205 = getelementptr i8, i8* %204, i64 1
  store i8 115, i8* %205, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %206 = getelementptr i8, i8* %204, i64 2
  store i8 115, i8* %206, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %207 = getelementptr i8, i8* %204, i64 3
  store i8 101, i8* %207, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %208 = getelementptr i8, i8* %204, i64 4
  store i8 116, i8* %208, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %209 = getelementptr i8, i8* %204, i64 5
  store i8 115, i8* %209, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %210 = getelementptr i8, i8* %204, i64 6
  store i8 47, i8* %210, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %211 = getelementptr i8, i8* %204, i64 7
  store i8 103, i8* %211, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %212 = getelementptr i8, i8* %204, i64 8
  store i8 97, i8* %212, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %213 = getelementptr i8, i8* %204, i64 9
  store i8 109, i8* %213, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %214 = getelementptr i8, i8* %204, i64 10
  store i8 101, i8* %214, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %215 = getelementptr i8, i8* %204, i64 11
  store i8 46, i8* %215, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %216 = getelementptr i8, i8* %204, i64 12
  store i8 112, i8* %216, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %217 = getelementptr i8, i8* %204, i64 13
  store i8 110, i8* %217, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %218 = getelementptr i8, i8* %204, i64 14
  store i8 103, i8* %218, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %219 = getelementptr i8, i8* %204, i64 15
  store i8 0, i8* %219, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %220 = call fastcc i8* @julia_game_loop_1955u1967(i32 16)
  %221 = load i8, i8* %204, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %221, i8* %220, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %222 = getelementptr i8, i8* %220, i64 1
  %223 = load i8, i8* %205, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %223, i8* %222, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %224 = getelementptr i8, i8* %220, i64 2
  %225 = load i8, i8* %206, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %225, i8* %224, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %226 = getelementptr i8, i8* %220, i64 3
  %227 = load i8, i8* %207, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %227, i8* %226, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %228 = getelementptr i8, i8* %220, i64 4
  %229 = load i8, i8* %208, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %229, i8* %228, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %230 = getelementptr i8, i8* %220, i64 5
  %231 = load i8, i8* %209, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %231, i8* %230, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %232 = getelementptr i8, i8* %220, i64 6
  %233 = load i8, i8* %210, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %233, i8* %232, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %234 = getelementptr i8, i8* %220, i64 7
  %235 = load i8, i8* %211, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %235, i8* %234, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %236 = getelementptr i8, i8* %220, i64 8
  %237 = load i8, i8* %212, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %237, i8* %236, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %238 = getelementptr i8, i8* %220, i64 9
  %239 = load i8, i8* %213, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %239, i8* %238, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %240 = getelementptr i8, i8* %220, i64 10
  %241 = load i8, i8* %214, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %241, i8* %240, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %242 = getelementptr i8, i8* %220, i64 11
  %243 = load i8, i8* %215, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %243, i8* %242, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %244 = getelementptr i8, i8* %220, i64 12
  %245 = load i8, i8* %216, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %245, i8* %244, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %246 = getelementptr i8, i8* %220, i64 13
  %247 = load i8, i8* %217, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %247, i8* %246, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %248 = getelementptr i8, i8* %220, i64 14
  %249 = load i8, i8* %218, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %249, i8* %248, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %250 = getelementptr i8, i8* %220, i64 15
  %251 = load i8, i8* %219, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %251, i8* %250, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %252 = ptrtoint i8* %220 to i64
  %253 = getelementptr i8, i8* %220, i64 16
  store i8 0, i8* %253, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %254 = call fastcc i64 @julia_load_sprite_2079(i64 zeroext %0, i64 zeroext %252, i32 signext 120, i32 signext 360, i32 signext 8, i32 signext 8, i32 signext 64, i32 signext 64) #6
  store i64 %254, i64* %189, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %220)
  %255 = load i64, i64* %189, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not132 = icmp eq i64 %255, 0
  br i1 %.not132, label %L716, label %L747

L716:                                             ; preds = %L621
  %256 = call fastcc i8* @julia_game_loop_1955u1967(i32 100)
  %257 = call fastcc i8* @julia_init_sprite_system_2095u2102(i8* %256, i32 100)
  call void @llvm.lifetime.start.p0i8(i64 11, i8* nonnull %.sub122)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(11) %.sub122, i8* noundef nonnull align 1 dereferenceable(11) getelementptr inbounds ([11 x i8], [11 x i8]* @_j_const51, i64 0, i64 0), i64 11, i1 false)
  %status.i144 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub122, i8* %257) #1
  call void @llvm.lifetime.end.p0i8(i64 11, i8* nonnull %.sub122)
  call fastcc void @julia_cleanup_1939u1941(i8* %256)
  br label %L747

L747:                                             ; preds = %L716, %L621, %L315
  %258 = load i64, i64* %190, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not133 = icmp eq i64 %258, 0
  br i1 %.not133, label %L756, label %L882

L756:                                             ; preds = %L747
  call void @llvm.lifetime.end.p0i8(i64 24, i8* nonnull %.sub120)
  call void @llvm.lifetime.start.p0i8(i64 27, i8* nonnull %.sub123)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(27) %.sub123, i8* noundef nonnull align 16 dereferenceable(27) getelementptr inbounds ([27 x i8], [27 x i8]* @_j_const52, i64 0, i64 0), i64 27, i1 false)
  %status.i77 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub123) #1
  call void @llvm.lifetime.end.p0i8(i64 27, i8* nonnull %.sub123)
  %259 = call fastcc i8* @julia_game_loop_1955u1967(i32 15)
  store i8 97, i8* %259, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %260 = getelementptr i8, i8* %259, i64 1
  store i8 115, i8* %260, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %261 = getelementptr i8, i8* %259, i64 2
  store i8 115, i8* %261, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %262 = getelementptr i8, i8* %259, i64 3
  store i8 101, i8* %262, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %263 = getelementptr i8, i8* %259, i64 4
  store i8 116, i8* %263, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %264 = getelementptr i8, i8* %259, i64 5
  store i8 115, i8* %264, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %265 = getelementptr i8, i8* %259, i64 6
  store i8 47, i8* %265, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %266 = getelementptr i8, i8* %259, i64 7
  store i8 109, i8* %266, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %267 = getelementptr i8, i8* %259, i64 8
  store i8 97, i8* %267, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %268 = getelementptr i8, i8* %259, i64 9
  store i8 112, i8* %268, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %269 = getelementptr i8, i8* %259, i64 10
  store i8 46, i8* %269, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %270 = getelementptr i8, i8* %259, i64 11
  store i8 112, i8* %270, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %271 = getelementptr i8, i8* %259, i64 12
  store i8 110, i8* %271, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %272 = getelementptr i8, i8* %259, i64 13
  store i8 103, i8* %272, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %273 = getelementptr i8, i8* %259, i64 14
  store i8 0, i8* %273, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %274 = call fastcc i8* @julia_game_loop_1955u1967(i32 15)
  %275 = load i8, i8* %259, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %275, i8* %274, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %276 = getelementptr i8, i8* %274, i64 1
  %277 = load i8, i8* %260, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %277, i8* %276, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %278 = getelementptr i8, i8* %274, i64 2
  %279 = load i8, i8* %261, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %279, i8* %278, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %280 = getelementptr i8, i8* %274, i64 3
  %281 = load i8, i8* %262, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %281, i8* %280, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %282 = getelementptr i8, i8* %274, i64 4
  %283 = load i8, i8* %263, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %283, i8* %282, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %284 = getelementptr i8, i8* %274, i64 5
  %285 = load i8, i8* %264, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %285, i8* %284, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %286 = getelementptr i8, i8* %274, i64 6
  %287 = load i8, i8* %265, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %287, i8* %286, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %288 = getelementptr i8, i8* %274, i64 7
  %289 = load i8, i8* %266, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %289, i8* %288, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %290 = getelementptr i8, i8* %274, i64 8
  %291 = load i8, i8* %267, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %291, i8* %290, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %292 = getelementptr i8, i8* %274, i64 9
  %293 = load i8, i8* %268, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %293, i8* %292, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %294 = getelementptr i8, i8* %274, i64 10
  %295 = load i8, i8* %269, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %295, i8* %294, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %296 = getelementptr i8, i8* %274, i64 11
  %297 = load i8, i8* %270, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %297, i8* %296, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %298 = getelementptr i8, i8* %274, i64 12
  %299 = load i8, i8* %271, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %299, i8* %298, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %300 = getelementptr i8, i8* %274, i64 13
  %301 = load i8, i8* %272, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %301, i8* %300, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %302 = getelementptr i8, i8* %274, i64 14
  %303 = load i8, i8* %273, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 %303, i8* %302, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %304 = ptrtoint i8* %274 to i64
  %305 = getelementptr i8, i8* %274, i64 15
  store i8 0, i8* %305, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %306 = call fastcc i64 @julia_load_sprite_2079(i64 zeroext %0, i64 zeroext %304, i32 signext 0, i32 signext 0, i32 signext 640, i32 signext 640, i32 signext 640, i32 signext 640) #6
  store i64 %306, i64* %190, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  call fastcc void @julia_cleanup_1939u1941(i8* nonnull %274)
  %307 = load i64, i64* %190, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not136 = icmp eq i64 %307, 0
  br i1 %.not136, label %L851, label %L882

L851:                                             ; preds = %L756
  %308 = call fastcc i8* @julia_game_loop_1955u1967(i32 100)
  %309 = call fastcc i8* @julia_init_sprite_system_2095u2102(i8* %308, i32 100)
  call void @llvm.lifetime.start.p0i8(i64 11, i8* nonnull %.sub124)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(11) %.sub124, i8* noundef nonnull align 1 dereferenceable(11) getelementptr inbounds ([11 x i8], [11 x i8]* @_j_const51, i64 0, i64 0), i64 11, i1 false)
  %status.i146 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub124, i8* %309) #1
  call void @llvm.lifetime.end.p0i8(i64 11, i8* nonnull %.sub124)
  call fastcc void @julia_cleanup_1939u1941(i8* %308)
  br label %L882

L882:                                             ; preds = %L851, %L756, %L747
  %310 = ptrtoint i8* %181 to i64
  ret i64 %310
}

define internal fastcc i8* @julia_j_init_game_state_2019u2023() unnamed_addr {
entry:
  %result = call i8* @SDL_GetPlatform()
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_GetPlatform() local_unnamed_addr #1

define internal fastcc i32 @julia_j_init_game_state_2019u2031(i32 %flags) unnamed_addr {
entry:
  %result = call i32 @Mix_Init(i32 %flags)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @Mix_Init(i32) local_unnamed_addr #1

define internal fastcc i32 @julia_j_init_game_state_2019u2037(i32 %frequency, i16 %format, i32 %channels, i32 %chunksize) unnamed_addr {
entry:
  %result = call i32 @Mix_OpenAudio(i32 %frequency, i16 %format, i32 %channels, i32 %chunksize)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @Mix_OpenAudio(i32, i16, i32, i32) local_unnamed_addr #1

define internal fastcc i8* @julia_j_init_game_state_2019u2045(i8* %file) unnamed_addr {
entry:
  %result = call i8* @Mix_LoadWAV(i8* %file)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @Mix_LoadWAV(i8*) local_unnamed_addr #1

define internal fastcc void @julia_update_animation_2004(i64 zeroext %0, double %1) unnamed_addr {
top:
  %.not = icmp eq i64 %0, 0
  br i1 %.not, label %common.ret, label %L6

common.ret:                                       ; preds = %L97, %L80, %L74, %L20, %L12, %top
  ret void

L6:                                               ; preds = %top
  %2 = inttoptr i64 %0 to i8*
  %3 = getelementptr i8, i8* %2, i64 40
  %4 = load i8, i8* %3, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %5 = and i8 %4, 1
  %.not1 = icmp eq i8 %5, 0
  br i1 %.not1, label %L20, label %L12

L12:                                              ; preds = %L6
  %6 = getelementptr i8, i8* %2, i64 24
  %7 = load i8, i8* %6, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %8 = and i8 %7, 1
  %.not2.not = icmp eq i8 %8, 0
  br i1 %.not2.not, label %common.ret, label %L20

L20:                                              ; preds = %L12, %L6
  %9 = getelementptr i8, i8* %2, i64 32
  %10 = bitcast i8* %9 to double*
  %11 = load double, double* %10, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %12 = fadd double %11, %1
  store double %12, double* %10, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %13 = getelementptr i8, i8* %2, i64 16
  %14 = bitcast i8* %13 to double*
  %15 = load double, double* %14, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %16 = fdiv double 1.000000e+00, %15
  %17 = fcmp ugt double %16, %12
  br i1 %17, label %common.ret, label %L44

L44:                                              ; preds = %L20
  %18 = fsub double %12, %16
  store double %18, double* %10, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %19 = getelementptr i8, i8* %2, i64 28
  %20 = bitcast i8* %19 to i32*
  %21 = load i32, i32* %20, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %22 = add i32 %21, 1
  %23 = getelementptr i8, i8* %2, i64 8
  %24 = bitcast i8* %23 to i32*
  %25 = load i32, i32* %24, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %.not3 = icmp sgt i32 %25, %22
  br i1 %.not3, label %L97, label %L68

L68:                                              ; preds = %L44
  %26 = getelementptr i8, i8* %2, i64 24
  %27 = load i8, i8* %26, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  %28 = and i8 %27, 1
  %.not4 = icmp eq i8 %28, 0
  br i1 %.not4, label %L80, label %L74

L74:                                              ; preds = %L68
  store i32 0, i32* %20, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %common.ret

L80:                                              ; preds = %L68
  %29 = add i32 %25, -1
  store i32 %29, i32* %20, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  store i8 1, i8* %3, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %common.ret

L97:                                              ; preds = %L44
  store i32 %22, i32* %20, align 1, !tbaa !13, !alias.scope !15, !noalias !16
  br label %common.ret
}

; Function Attrs: noinline
define internal fastcc void @julia__throw_inexacterror_2015() unnamed_addr #3 {
top:
  %0 = alloca [19 x i8], align 16
  %.sub = getelementptr inbounds [19 x i8], [19 x i8]* %0, i64 0, i64 0
  call void @llvm.lifetime.start.p0i8(i64 19, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(19) %.sub, i8* noundef nonnull align 16 dereferenceable(19) getelementptr inbounds ([19 x i8], [19 x i8]* @_j_const18, i64 0, i64 0), i64 19, i1 false)
  %status.i = call i32 @puts(i8* noundef nonnull %.sub) #1
  call void @llvm.lifetime.end.p0i8(i64 19, i8* nonnull %.sub)
  call void @exit(i32 1) #1
  ret void
}

; Function Attrs: nounwind
declare i32 @puts(i8* nocapture) local_unnamed_addr #1

declare void @exit(i32) local_unnamed_addr

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0i8(i64 immarg, i8* nocapture) #4

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0i8(i64 immarg, i8* nocapture) #4

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #5

attributes #0 = { argmemonly nofree nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { noinline }
attributes #4 = { argmemonly nofree nosync nounwind willreturn }
attributes #5 = { argmemonly nofree nounwind willreturn writeonly }
attributes #6 = { "probe-stack"="inline-asm" }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = !{!3, !3, i64 0}
!3 = !{!"jtbaa", !4, i64 0}
!4 = !{!"jtbaa"}
!5 = !{!6, !8}
!6 = !{!"jnoalias_data", !7}
!7 = !{!"jnoalias"}
!8 = !{!"jnoalias_stack", !7}
!9 = !{!10, !11, !12}
!10 = !{!"jnoalias_gcframe", !7}
!11 = !{!"jnoalias_typemd", !7}
!12 = !{!"jnoalias_const", !7}
!13 = !{!14, !14, i64 0}
!14 = !{!"jtbaa_data", !3, i64 0}
!15 = !{!6}
!16 = !{!10, !8, !11, !12}
!17 = !{!8, !6}
!18 = !{!19, !19, i64 0}
!19 = !{!"jtbaa_mutab", !20, i64 0}
!20 = !{!"jtbaa_value", !14, i64 0}
