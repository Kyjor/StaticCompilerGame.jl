; ModuleID = 'start'
source_filename = "start"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-linux-gnu"

@_j_const3 = private unnamed_addr constant [25 x i8] c"Failed to create window\0A\00", align 1
@_j_const4 = private unnamed_addr constant [11 x i8] c"Error: %s\0A\00", align 1

define i64 @j_init_window() local_unnamed_addr {
top:
  %0 = alloca [25 x i8], align 16
  %1 = alloca [11 x i8], align 16
  %2 = call fastcc i8* @julia_j_init_window_1730u1732(i32 16)
  store i8 83, i8* %2, align 1
  %coercion.1 = getelementptr i8, i8* %2, i64 1
  store i8 97, i8* %coercion.1, align 1
  %coercion.2 = getelementptr i8, i8* %2, i64 2
  store i8 110, i8* %coercion.2, align 1
  %coercion.3 = getelementptr i8, i8* %2, i64 3
  store i8 100, i8* %coercion.3, align 1
  %coercion.4 = getelementptr i8, i8* %2, i64 4
  store i8 32, i8* %coercion.4, align 1
  %coercion.5 = getelementptr i8, i8* %2, i64 5
  store i8 115, i8* %coercion.5, align 1
  %coercion.6 = getelementptr i8, i8* %2, i64 6
  store i8 105, i8* %coercion.6, align 1
  %coercion.7 = getelementptr i8, i8* %2, i64 7
  store i8 109, i8* %coercion.7, align 1
  %coercion.8 = getelementptr i8, i8* %2, i64 8
  store i8 117, i8* %coercion.8, align 1
  %coercion.9 = getelementptr i8, i8* %2, i64 9
  store i8 108, i8* %coercion.9, align 1
  %coercion.10 = getelementptr i8, i8* %2, i64 10
  store i8 97, i8* %coercion.10, align 1
  %coercion.11 = getelementptr i8, i8* %2, i64 11
  store i8 116, i8* %coercion.11, align 1
  %coercion.12 = getelementptr i8, i8* %2, i64 12
  store i8 105, i8* %coercion.12, align 1
  %coercion.13 = getelementptr i8, i8* %2, i64 13
  store i8 111, i8* %coercion.13, align 1
  %coercion.14 = getelementptr i8, i8* %2, i64 14
  store i8 110, i8* %coercion.14, align 1
  %coercion.15 = getelementptr i8, i8* %2, i64 15
  store i8 0, i8* %coercion.15, align 1
  %3 = call fastcc i8* @julia_j_init_window_1730u1732(i32 16)
  %pointerref = load i8, i8* %2, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref, i8* %3, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.1 = getelementptr i8, i8* %3, i64 1
  %pointerref.1 = load i8, i8* %coercion.1, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.1, i8* %coercion8.1, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.2 = getelementptr i8, i8* %3, i64 2
  %pointerref.2 = load i8, i8* %coercion.2, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.2, i8* %coercion8.2, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.3 = getelementptr i8, i8* %3, i64 3
  %pointerref.3 = load i8, i8* %coercion.3, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.3, i8* %coercion8.3, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.4 = getelementptr i8, i8* %3, i64 4
  %pointerref.4 = load i8, i8* %coercion.4, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.4, i8* %coercion8.4, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.5 = getelementptr i8, i8* %3, i64 5
  %pointerref.5 = load i8, i8* %coercion.5, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.5, i8* %coercion8.5, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.6 = getelementptr i8, i8* %3, i64 6
  %pointerref.6 = load i8, i8* %coercion.6, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.6, i8* %coercion8.6, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.7 = getelementptr i8, i8* %3, i64 7
  %pointerref.7 = load i8, i8* %coercion.7, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.7, i8* %coercion8.7, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.8 = getelementptr i8, i8* %3, i64 8
  %pointerref.8 = load i8, i8* %coercion.8, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.8, i8* %coercion8.8, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.9 = getelementptr i8, i8* %3, i64 9
  %pointerref.9 = load i8, i8* %coercion.9, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.9, i8* %coercion8.9, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.10 = getelementptr i8, i8* %3, i64 10
  %pointerref.10 = load i8, i8* %coercion.10, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.10, i8* %coercion8.10, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.11 = getelementptr i8, i8* %3, i64 11
  %pointerref.11 = load i8, i8* %coercion.11, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.11, i8* %coercion8.11, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.12 = getelementptr i8, i8* %3, i64 12
  %pointerref.12 = load i8, i8* %coercion.12, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.12, i8* %coercion8.12, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.13 = getelementptr i8, i8* %3, i64 13
  %pointerref.13 = load i8, i8* %coercion.13, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.13, i8* %coercion8.13, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %coercion8.14 = getelementptr i8, i8* %3, i64 14
  %pointerref.14 = load i8, i8* %coercion.14, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.14, i8* %coercion8.14, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %4 = getelementptr i8, i8* %3, i64 16
  %coercion8.15 = getelementptr i8, i8* %3, i64 15
  %pointerref.15 = load i8, i8* %coercion.15, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %pointerref.15, i8* %coercion8.15, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 0, i8* %4, align 1
  %5 = call fastcc i8* @julia_j_init_window_1730u1734(i8* nonnull %3, i32 0, i32 0, i32 640, i32 640, i32 0)
  %.not = icmp eq i8* %5, null
  br i1 %.not, label %L72, label %L109

L72:                                              ; preds = %top
  %.sub18 = getelementptr inbounds [11 x i8], [11 x i8]* %1, i64 0, i64 0
  %.sub = getelementptr inbounds [25 x i8], [25 x i8]* %0, i64 0, i64 0
  call void @llvm.lifetime.start.p0i8(i64 25, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(25) %.sub, i8* noundef nonnull align 1 dereferenceable(25) getelementptr inbounds ([25 x i8], [25 x i8]* @_j_const3, i64 0, i64 0), i64 25, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #0
  call void @llvm.lifetime.end.p0i8(i64 25, i8* nonnull %.sub)
  %6 = call fastcc i8* @julia_j_init_window_1730u1732(i32 100)
  %7 = call fastcc i8* @julia_j_init_window_1730u1737(i8* %6, i32 100)
  call void @llvm.lifetime.start.p0i8(i64 11, i8* nonnull %.sub18)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(11) %.sub18, i8* noundef nonnull align 1 dereferenceable(11) getelementptr inbounds ([11 x i8], [11 x i8]* @_j_const4, i64 0, i64 0), i64 11, i1 false)
  %bitcast_coercion17 = ptrtoint [11 x i8]* %1 to i64
  %fmt.i = inttoptr i64 %bitcast_coercion17 to i8*
  %status.i1 = call i32 (i8*, ...) @printf(i8* noundef nonnull dereferenceable(1) %fmt.i, i8* %7) #0
  call void @llvm.lifetime.end.p0i8(i64 11, i8* nonnull %.sub18)
  call fastcc void @julia_j_init_window_1730u1739(i8* %6)
  br label %L109

L109:                                             ; preds = %L72, %top
  %8 = ptrtoint i8* %5 to i64
  call fastcc void @julia_j_init_window_1730u1739(i8* nonnull %3)
  ret i64 %8
}

define internal fastcc i8* @julia_j_init_window_1730u1732(i32 %size) unnamed_addr {
entry:
  %ptr = call noalias i8* @malloc(i32 %size)
  ret i8* %ptr
}

; Function Attrs: nounwind
declare noalias i8* @malloc(i32) local_unnamed_addr #0

define internal fastcc i8* @julia_j_init_window_1730u1734(i8* %title, i32 %x, i32 %y, i32 %w, i32 %h, i32 %flags) unnamed_addr {
entry:
  %result = call i8* @SDL_CreateWindow(i8* %title, i32 %x, i32 %y, i32 %w, i32 %h, i32 %flags)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_CreateWindow(i8*, i32, i32, i32, i32, i32) local_unnamed_addr #0

declare i32 @printf(i8* noalias nocapture, ...) local_unnamed_addr

define internal fastcc i8* @julia_j_init_window_1730u1737(i8* %errstr, i32 %maxlen) unnamed_addr {
entry:
  %result = call i8* @SDL_GetErrorMsg(i8* %errstr, i32 %maxlen)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_GetErrorMsg(i8*, i32) local_unnamed_addr #0

define internal fastcc void @julia_j_init_window_1730u1739(i8* %ptr) unnamed_addr {
entry:
  call void @free(i8* %ptr)
  ret void
}

; Function Attrs: nounwind
declare void @free(i8*) local_unnamed_addr #0

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0i8(i64 immarg, i8* nocapture) #1

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0i8(i64 immarg, i8* nocapture) #1

; Function Attrs: argmemonly nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0i8.p0i8.i64(i8* noalias nocapture writeonly, i8* noalias nocapture readonly, i64, i1 immarg) #2

attributes #0 = { nounwind }
attributes #1 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #2 = { argmemonly nocallback nofree nounwind willreturn }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = !{!3, !3, i64 0}
!3 = !{!"jtbaa_data", !4, i64 0}
!4 = !{!"jtbaa", !5, i64 0}
!5 = !{!"jtbaa"}
!6 = !{!7}
!7 = !{!"jnoalias_data", !8}
!8 = !{!"jnoalias"}
!9 = !{!10, !11, !12, !13}
!10 = !{!"jnoalias_gcframe", !8}
!11 = !{!"jnoalias_stack", !8}
!12 = !{!"jnoalias_typemd", !8}
!13 = !{!"jnoalias_const", !8}
