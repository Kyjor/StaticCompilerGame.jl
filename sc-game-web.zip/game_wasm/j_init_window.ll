; ModuleID = 'start'
source_filename = "start"
target datalayout = "e-m:o-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-apple-darwin"

@_j_const3 = private unnamed_addr constant [25 x i8] c"Failed to create window\0A\00"
@_j_const4 = private unnamed_addr constant [11 x i8] c"Error: %s\0A\00"

define i64 @j_init_window() local_unnamed_addr {
top:
  %0 = alloca [25 x i8], align 16
  %1 = alloca [11 x i8], align 16
  %2 = call fastcc i8* @julia_j_init_window_1585u1587(i32 10)
  store i8 71, i8* %2, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %3 = getelementptr i8, i8* %2, i64 1
  store i8 97, i8* %3, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %4 = getelementptr i8, i8* %2, i64 2
  store i8 109, i8* %4, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %5 = getelementptr i8, i8* %2, i64 3
  store i8 101, i8* %5, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %6 = getelementptr i8, i8* %2, i64 4
  store i8 32, i8* %6, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %7 = getelementptr i8, i8* %2, i64 5
  store i8 116, i8* %7, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %8 = getelementptr i8, i8* %2, i64 6
  store i8 101, i8* %8, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %9 = getelementptr i8, i8* %2, i64 7
  store i8 115, i8* %9, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %10 = getelementptr i8, i8* %2, i64 8
  store i8 116, i8* %10, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %11 = getelementptr i8, i8* %2, i64 9
  store i8 0, i8* %11, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.sub = getelementptr inbounds [25 x i8], [25 x i8]* %0, i64 0, i64 0
  %.sub12 = getelementptr inbounds [11 x i8], [11 x i8]* %1, i64 0, i64 0
  %12 = call fastcc i8* @julia_j_init_window_1585u1587(i32 10)
  %13 = load i8, i8* %2, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %13, i8* %12, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %14 = getelementptr i8, i8* %12, i64 1
  %15 = load i8, i8* %3, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %15, i8* %14, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %16 = getelementptr i8, i8* %12, i64 2
  %17 = load i8, i8* %4, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %17, i8* %16, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %18 = getelementptr i8, i8* %12, i64 3
  %19 = load i8, i8* %5, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %19, i8* %18, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %20 = getelementptr i8, i8* %12, i64 4
  %21 = load i8, i8* %6, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %21, i8* %20, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %22 = getelementptr i8, i8* %12, i64 5
  %23 = load i8, i8* %7, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %23, i8* %22, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %24 = getelementptr i8, i8* %12, i64 6
  %25 = load i8, i8* %8, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %25, i8* %24, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %26 = getelementptr i8, i8* %12, i64 7
  %27 = load i8, i8* %9, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %27, i8* %26, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %28 = getelementptr i8, i8* %12, i64 8
  %29 = load i8, i8* %10, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %29, i8* %28, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %30 = getelementptr i8, i8* %12, i64 9
  %31 = load i8, i8* %11, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %31, i8* %30, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %32 = getelementptr i8, i8* %12, i64 10
  store i8 0, i8* %32, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %33 = call fastcc i8* @julia_j_init_window_1585u1589(i8* nonnull %12, i32 0, i32 0, i32 640, i32 640, i32 0)
  %.not = icmp eq i8* %33, null
  br i1 %.not, label %L77, label %L115

L77:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 25, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(25) %.sub, i8* noundef nonnull align 16 dereferenceable(25) getelementptr inbounds ([25 x i8], [25 x i8]* @_j_const3, i64 0, i64 0), i64 25, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #0
  call void @llvm.lifetime.end.p0i8(i64 25, i8* nonnull %.sub)
  %34 = call fastcc i8* @julia_j_init_window_1585u1587(i32 100)
  %35 = call fastcc i8* @julia_j_init_window_1585u1592(i8* %34, i32 100)
  call void @llvm.lifetime.start.p0i8(i64 11, i8* nonnull %.sub12)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(11) %.sub12, i8* noundef nonnull align 1 dereferenceable(11) getelementptr inbounds ([11 x i8], [11 x i8]* @_j_const4, i64 0, i64 0), i64 11, i1 false)
  %status.i14 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub12, i8* %35) #0
  call void @llvm.lifetime.end.p0i8(i64 11, i8* nonnull %.sub12)
  call fastcc void @julia_j_init_window_1585u1594(i8* %34)
  br label %L115

L115:                                             ; preds = %L77, %top
  %36 = ptrtoint i8* %33 to i64
  call fastcc void @julia_j_init_window_1585u1594(i8* nonnull %12)
  ret i64 %36
}

define internal fastcc i8* @julia_j_init_window_1585u1587(i32 %size) unnamed_addr {
entry:
  %ptr = call noalias i8* @malloc(i32 %size)
  ret i8* %ptr
}

; Function Attrs: nounwind
declare noalias i8* @malloc(i32) local_unnamed_addr #0

define internal fastcc i8* @julia_j_init_window_1585u1589(i8* %title, i32 %x, i32 %y, i32 %w, i32 %h, i32 %flags) unnamed_addr {
entry:
  %result = call i8* @SDL_CreateWindow(i8* %title, i32 %x, i32 %y, i32 %w, i32 %h, i32 %flags)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_CreateWindow(i8*, i32, i32, i32, i32, i32) local_unnamed_addr #0

declare i32 @printf(i8* noalias nocapture, ...) local_unnamed_addr

define internal fastcc i8* @julia_j_init_window_1585u1592(i8* %errstr, i32 %maxlen) unnamed_addr {
entry:
  %result = call i8* @SDL_GetErrorMsg(i8* %errstr, i32 %maxlen)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_GetErrorMsg(i8*, i32) local_unnamed_addr #0

define internal fastcc void @julia_j_init_window_1585u1594(i8* %ptr) unnamed_addr {
entry:
  call void @free(i8* %ptr)
  ret void
}

; Function Attrs: nounwind
declare void @free(i8*) local_unnamed_addr #0

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0i8(i64 immarg, i8* nocapture) #1

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0i8(i64 immarg, i8* nocapture) #1

; Function Attrs: argmemonly nofree nounwind willreturn
declare void @llvm.memcpy.p0i8.p0i8.i64(i8* noalias nocapture writeonly, i8* noalias nocapture readonly, i64, i1 immarg) #2

attributes #0 = { nounwind }
attributes #1 = { argmemonly nofree nosync nounwind willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = !{!3, !3, i64 0}
!3 = !{!"jtbaa_data", !4, i64 0}
!4 = !{!"jtbaa", !5, i64 0}
!5 = !{!"jtbaa"}
!6 = !{!7}
!7 = !{!"jnoalias_data", !8}
!8 = !{!"jnoalias"}
!9 = !{!10, !11, !12, !13}
!10 = !{!"jnoalias_gcframe", !8}
!11 = !{!"jnoalias_stack", !8}
!12 = !{!"jnoalias_typemd", !8}
!13 = !{!"jnoalias_const", !8}
