; ModuleID = 'start'
source_filename = "start"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-linux-gnu"

@_j_const1 = private unnamed_addr constant [27 x i8] c"Failed to create renderer\0A\00", align 1

define i64 @j_init_renderer(i64 zeroext %0) local_unnamed_addr {
top:
  %1 = alloca [27 x i8], align 16
  %.sub = getelementptr inbounds [27 x i8], [27 x i8]* %1, i64 0, i64 0
  %2 = inttoptr i64 %0 to i8*
  %3 = call fastcc i8* @julia_j_init_renderer_1800u1802(i8* %2, i32 -1, i32 2)
  %.not = icmp eq i8* %3, null
  br i1 %.not, label %L7, label %L14

L7:                                               ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 27, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(27) %.sub, i8* noundef nonnull align 1 dereferenceable(27) getelementptr inbounds ([27 x i8], [27 x i8]* @_j_const1, i64 0, i64 0), i64 27, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #0
  br label %L14

L14:                                              ; preds = %L7, %top
  %4 = ptrtoint i8* %3 to i64
  call void @llvm.lifetime.end.p0i8(i64 27, i8* nonnull %.sub)
  ret i64 %4
}

define internal fastcc i8* @julia_j_init_renderer_1800u1802(i8* %window, i32 %index, i32 %flags) unnamed_addr {
entry:
  %result = call i8* @SDL_CreateRenderer(i8* %window, i32 %index, i32 %flags)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_CreateRenderer(i8*, i32, i32) local_unnamed_addr #0

declare i32 @printf(i8* noalias nocapture, ...) local_unnamed_addr

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0i8(i64 immarg, i8* nocapture) #1

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0i8(i64 immarg, i8* nocapture) #1

; Function Attrs: argmemonly nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0i8.p0i8.i64(i8* noalias nocapture writeonly, i8* noalias nocapture readonly, i64, i1 immarg) #2

attributes #0 = { nounwind }
attributes #1 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #2 = { argmemonly nocallback nofree nounwind willreturn }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
