; ModuleID = 'start'
source_filename = "start"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-linux-gnu"

@_j_const1 = private unnamed_addr constant [30 x i8] c"Initializing sand simulation\0A\00", align 1
@_j_const3 = private unnamed_addr constant [28 x i8] c"Grid initialized: %d cells\0A\00", align 1
@_j_const8 = private unnamed_addr constant [23 x i8] c"Sand simulation ready\0A\00", align 1
@_j_const9 = private unnamed_addr constant [45 x i8] c"Controls: 1=Sand, 2=Water, 3=Stone, 0=Erase\0A\00", align 1
@_j_const10 = private unnamed_addr constant [28 x i8] c"Click/touch to place cells\0A\00", align 1

define i64 @j_init_game_state(i64 zeroext %0, i64 zeroext %1) local_unnamed_addr {
top:
  %2 = alloca [30 x i8], align 16
  %.sub = getelementptr inbounds [30 x i8], [30 x i8]* %2, i64 0, i64 0
  %3 = alloca [28 x i8], align 16
  %4 = alloca [23 x i8], align 16
  %5 = alloca [45 x i8], align 16
  %6 = alloca [28 x i8], align 16
  call void @llvm.lifetime.start.p0i8(i64 30, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(30) %.sub, i8* noundef nonnull align 1 dereferenceable(30) getelementptr inbounds ([30 x i8], [30 x i8]* @_j_const1, i64 0, i64 0), i64 30, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #0
  call void @llvm.lifetime.end.p0i8(i64 30, i8* nonnull %.sub)
  %7 = call fastcc i8* @julia_j_init_game_state_1260u1263(i32 25600)
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(25600) %7, i8 0, i64 25600, i1 false)
  %8 = ptrtoint i8* %7 to i64
  %.sub37 = getelementptr inbounds [28 x i8], [28 x i8]* %6, i64 0, i64 0
  %.sub36 = getelementptr inbounds [45 x i8], [45 x i8]* %5, i64 0, i64 0
  %.sub35 = getelementptr inbounds [23 x i8], [23 x i8]* %4, i64 0, i64 0
  %.sub34 = getelementptr inbounds [28 x i8], [28 x i8]* %3, i64 0, i64 0
  call void @llvm.lifetime.start.p0i8(i64 28, i8* nonnull %.sub34)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(28) %.sub34, i8* noundef nonnull align 1 dereferenceable(28) getelementptr inbounds ([28 x i8], [28 x i8]* @_j_const3, i64 0, i64 0), i64 28, i1 false)
  %status.i27 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub34, i32 25600) #0
  call void @llvm.lifetime.end.p0i8(i64 28, i8* nonnull %.sub34)
  %9 = call fastcc i8* @julia_j_init_game_state_1260u1263(i32 32)
  %10 = ptrtoint i8* %9 to i64
  %coercion10 = getelementptr i8, i8* %9, i64 16
  %memcpy_refined_dst12 = bitcast i8* %coercion10 to i32*
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(16) %9, i8 0, i64 16, i1 false)
  store i32 12345, i32* %memcpy_refined_dst12, align 1
  %coercion13 = getelementptr i8, i8* %9, i64 20
  store i8 1, i8* %coercion13, align 1
  %coercion15 = getelementptr i8, i8* %9, i64 21
  store i8 0, i8* %coercion15, align 1
  %11 = getelementptr i8, i8* %9, i64 24
  %coercion17 = bitcast i8* %11 to i64*
  store i64 %8, i64* %coercion17, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  call void @llvm.lifetime.start.p0i8(i64 23, i8* nonnull %.sub35)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(23) %.sub35, i8* noundef nonnull align 1 dereferenceable(23) getelementptr inbounds ([23 x i8], [23 x i8]* @_j_const8, i64 0, i64 0), i64 23, i1 false)
  %status.i29 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub35) #0
  call void @llvm.lifetime.end.p0i8(i64 23, i8* nonnull %.sub35)
  call void @llvm.lifetime.start.p0i8(i64 45, i8* nonnull %.sub36)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(45) %.sub36, i8* noundef nonnull align 1 dereferenceable(45) getelementptr inbounds ([45 x i8], [45 x i8]* @_j_const9, i64 0, i64 0), i64 45, i1 false)
  %status.i31 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub36) #0
  call void @llvm.lifetime.end.p0i8(i64 45, i8* nonnull %.sub36)
  call void @llvm.lifetime.start.p0i8(i64 28, i8* nonnull %.sub37)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(28) %.sub37, i8* noundef nonnull align 1 dereferenceable(28) getelementptr inbounds ([28 x i8], [28 x i8]* @_j_const10, i64 0, i64 0), i64 28, i1 false)
  %status.i33 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub37) #0
  ret i64 %10
}

declare i32 @printf(i8* noalias nocapture, ...) local_unnamed_addr

define internal fastcc i8* @julia_j_init_game_state_1260u1263(i32 %size) unnamed_addr {
entry:
  %ptr = call noalias i8* @malloc(i32 %size)
  ret i8* %ptr
}

; Function Attrs: nounwind
declare noalias i8* @malloc(i32) local_unnamed_addr #0

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0i8(i64 immarg, i8* nocapture) #1

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0i8(i64 immarg, i8* nocapture) #1

; Function Attrs: argmemonly nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0i8.p0i8.i64(i8* noalias nocapture writeonly, i8* noalias nocapture readonly, i64, i1 immarg) #2

; Function Attrs: argmemonly nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #3

attributes #0 = { nounwind }
attributes #1 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #2 = { argmemonly nocallback nofree nounwind willreturn }
attributes #3 = { argmemonly nocallback nofree nounwind willreturn writeonly }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = !{!3, !3, i64 0}
!3 = !{!"jtbaa_data", !4, i64 0}
!4 = !{!"jtbaa", !5, i64 0}
!5 = !{!"jtbaa"}
!6 = !{!7}
!7 = !{!"jnoalias_data", !8}
!8 = !{!"jnoalias"}
!9 = !{!10, !11, !12, !13}
!10 = !{!"jnoalias_gcframe", !8}
!11 = !{!"jnoalias_stack", !8}
!12 = !{!"jnoalias_typemd", !8}
!13 = !{!"jnoalias_const", !8}
