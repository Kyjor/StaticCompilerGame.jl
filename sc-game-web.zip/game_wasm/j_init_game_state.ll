; ModuleID = 'start'
source_filename = "start"
target datalayout = "e-m:o-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-apple-darwin"

@_j_const44 = private unnamed_addr constant [20 x i8] c"Loading PNG sprite\0A\00"
@_j_const45 = private unnamed_addr constant [13 x i8] c"Surface: %p\0A\00"
@_j_const46 = private unnamed_addr constant [28 x i8] c"Failed to load PNG surface\0A\00"
@_j_const47 = private unnamed_addr constant [39 x i8] c"Failed to create texture from surface\0A\00"
@_j_const48 = private unnamed_addr constant [39 x i8] c"Surface width: %d, Surface height: %d\0A\00"
@_j_const49 = private unnamed_addr constant [32 x i8] c"PNG sprite loaded successfully\0A\00"
@_j_const1 = private unnamed_addr constant [25 x i8] c"Initializing game state\0A\00"
@_j_const2 = private unnamed_addr constant [7 x i8] c"macOS\0A\00"
@_j_const3 = private unnamed_addr constant [14 x i8] c"Platform: %s\0A\00"
@_j_const5 = private unnamed_addr constant [36 x i8] c"Failed to initialize sprite system\0A\00"
@_j_const6 = private unnamed_addr constant [27 x i8] c"Initializing audio system\0A\00"
@_j_const7 = private unnamed_addr constant [60 x i8] c"Failed to initialize SDL_mixer - OGG support not available\0A\00"
@_j_const9 = private unnamed_addr constant [45 x i8] c"Failed to open audio device, error code: %d\0A\00"
@_j_const12 = private unnamed_addr constant [40 x i8] c"Failed to play jump sound, channel: %d\0A\00"
@_j_const13 = private unnamed_addr constant [19 x i8] c"Jump sound loaded\0A\00"
@_j_const14 = private unnamed_addr constant [28 x i8] c"Creating player animations\0A\00"
@_j_const35 = private unnamed_addr constant [24 x i8] c"Game state initialized\0A\00"
@_j_const36 = private unnamed_addr constant [23 x i8] c"Loading player sprite\0A\00"
@_j_const38 = private unnamed_addr constant [11 x i8] c"Error: %s\0A\00"
@_j_const39 = private unnamed_addr constant [27 x i8] c"Loading background sprite\0A\00"
@_j_const41 = private unnamed_addr constant [49 x i8] c"Skipping sound loading - audio device not ready\0A\00"
@_j_const42 = private unnamed_addr constant [34 x i8] c"Audio device opened successfully\0A\00"
@_j_const43 = private unnamed_addr constant [53 x i8] c"SDL_mixer initialized successfully with OGG support\0A\00"
@_j_const50 = private unnamed_addr constant [28 x i8] c"Initializing sprite system\0A\00"
@_j_const51 = private unnamed_addr constant [52 x i8] c"IMG_Init returned: %d (expected 2 for PNG support)\0A\00"
@_j_const52 = private unnamed_addr constant [61 x i8] c"Failed to initialize SDL2_image - PNG support not available\0A\00"
@_j_const8 = private unnamed_addr constant [15 x i8] c"SDL Error: %s\0A\00"
@_j_const53 = private unnamed_addr constant [40 x i8] c"Sprite system initialized successfully\0A\00"

define internal fastcc i64 @load_sprite_1312(i64 zeroext %0, i64 zeroext %1, i32 signext %2, i32 signext %3, i32 signext %4, i32 signext %5, i32 signext %6, i32 signext %7) unnamed_addr {
top:
  %8 = alloca [20 x i8], align 16
  %.sub = getelementptr inbounds [20 x i8], [20 x i8]* %8, i64 0, i64 0
  %9 = alloca [13 x i8], align 16
  %.sub23 = getelementptr inbounds [13 x i8], [13 x i8]* %9, i64 0, i64 0
  %10 = alloca [28 x i8], align 16
  %.sub24 = getelementptr inbounds [28 x i8], [28 x i8]* %10, i64 0, i64 0
  %11 = alloca [11 x i8], align 16
  %.sub25 = getelementptr inbounds [11 x i8], [11 x i8]* %11, i64 0, i64 0
  %12 = alloca [39 x i8], align 16
  %.sub26 = getelementptr inbounds [39 x i8], [39 x i8]* %12, i64 0, i64 0
  %13 = alloca [39 x i8], align 16
  %.sub27 = getelementptr inbounds [39 x i8], [39 x i8]* %13, i64 0, i64 0
  %14 = alloca [32 x i8], align 16
  %.sub28 = getelementptr inbounds [32 x i8], [32 x i8]* %14, i64 0, i64 0
  call void @llvm.lifetime.start.p0i8(i64 20, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(20) %.sub, i8* noundef nonnull align 16 dereferenceable(20) getelementptr inbounds ([20 x i8], [20 x i8]* @_j_const44, i64 0, i64 0), i64 20, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #1
  call void @llvm.lifetime.end.p0i8(i64 20, i8* nonnull %.sub)
  %15 = inttoptr i64 %1 to i8*
  %16 = call fastcc i8* @julia_load_sprite_1312u1315(i8* %15)
  %17 = ptrtoint i8* %16 to i64
  call void @llvm.lifetime.start.p0i8(i64 13, i8* nonnull %.sub23)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(13) %.sub23, i8* noundef nonnull align 1 dereferenceable(13) getelementptr inbounds ([13 x i8], [13 x i8]* @_j_const45, i64 0, i64 0), i64 13, i1 false)
  %status.i8 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub23, i64 %17) #1
  %.not = icmp eq i8* %16, null
  call void @llvm.lifetime.end.p0i8(i64 13, i8* nonnull %.sub23)
  br i1 %.not, label %L38, label %L46

common.ret:                                       ; preds = %L93, %L85, %L38
  %common.ret.op = phi i64 [ 0, %L38 ], [ 0, %L85 ], [ %30, %L93 ]
  call void @llvm.lifetime.end.p0i8(i64 28, i8* nonnull %.sub24)
  call void @llvm.lifetime.end.p0i8(i64 39, i8* nonnull %.sub26)
  call void @llvm.lifetime.end.p0i8(i64 32, i8* nonnull %.sub28)
  ret i64 %common.ret.op

L38:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 28, i8* nonnull %.sub24)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(28) %.sub24, i8* noundef nonnull align 16 dereferenceable(28) getelementptr inbounds ([28 x i8], [28 x i8]* @_j_const46, i64 0, i64 0), i64 28, i1 false)
  %status.i10 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub24) #1
  br label %common.ret

L46:                                              ; preds = %top
  %18 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 1024)
  %19 = call fastcc i8* @julia_init_sprite_system_1328u1335(i8* %18, i32 1024)
  call void @llvm.lifetime.start.p0i8(i64 11, i8* nonnull %.sub25)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(11) %.sub25, i8* noundef nonnull align 1 dereferenceable(11) getelementptr inbounds ([11 x i8], [11 x i8]* @_j_const38, i64 0, i64 0), i64 11, i1 false)
  %status.i31 = call i32 (i8*, ...) @printf(i8* noundef nonnull dereferenceable(1) %.sub25, i8* %19) #1
  call void @llvm.lifetime.end.p0i8(i64 11, i8* nonnull %.sub25)
  call fastcc void @julia_init_sprite_system_1328u1337(i8* %18)
  %20 = inttoptr i64 %0 to i8*
  %21 = call fastcc i8* @julia_load_sprite_1312u1322(i8* %20, i8* nonnull %16)
  call fastcc void @julia_load_sprite_1312u1323(i8* nonnull %16)
  %.not29 = icmp eq i8* %21, null
  br i1 %.not29, label %L85, label %L93

L85:                                              ; preds = %L46
  call void @llvm.lifetime.start.p0i8(i64 39, i8* nonnull %.sub26)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(39) %.sub26, i8* noundef nonnull align 16 dereferenceable(39) getelementptr inbounds ([39 x i8], [39 x i8]* @_j_const47, i64 0, i64 0), i64 39, i1 false)
  %status.i12 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub26) #1
  br label %common.ret

L93:                                              ; preds = %L46
  %22 = ptrtoint i8* %21 to i64
  %23 = getelementptr i8, i8* %16, i64 16
  %24 = bitcast i8* %23 to i32*
  %25 = load i32, i32* %24, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %26 = getelementptr i8, i8* %16, i64 20
  %27 = bitcast i8* %26 to i32*
  %28 = load i32, i32* %27, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  call void @llvm.lifetime.start.p0i8(i64 39, i8* nonnull %.sub27)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(39) %.sub27, i8* noundef nonnull align 16 dereferenceable(39) getelementptr inbounds ([39 x i8], [39 x i8]* @_j_const48, i64 0, i64 0), i64 39, i1 false)
  %status.i14 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub27, i32 %25, i32 %28) #1
  call void @llvm.lifetime.end.p0i8(i64 39, i8* nonnull %.sub27)
  %29 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 40)
  %30 = ptrtoint i8* %29 to i64
  %.sroa.0.0..sroa_idx = bitcast i8* %29 to i64*
  store i64 %22, i64* %.sroa.0.0..sroa_idx, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.2.0..sroa_idx17 = getelementptr inbounds i8, i8* %29, i64 8
  %31 = bitcast i8* %.sroa.2.0..sroa_idx17 to i32*
  store i32 %6, i32* %31, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.3.0..sroa_idx18 = getelementptr inbounds i8, i8* %29, i64 12
  %32 = bitcast i8* %.sroa.3.0..sroa_idx18 to i32*
  store i32 %7, i32* %32, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.4.0..sroa_idx19 = getelementptr inbounds i8, i8* %29, i64 16
  %33 = bitcast i8* %.sroa.4.0..sroa_idx19 to i32*
  store i32 %2, i32* %33, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.5.0..sroa_idx20 = getelementptr inbounds i8, i8* %29, i64 20
  %34 = bitcast i8* %.sroa.5.0..sroa_idx20 to i32*
  store i32 %3, i32* %34, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.6.0..sroa_idx21 = getelementptr inbounds i8, i8* %29, i64 24
  %35 = bitcast i8* %.sroa.6.0..sroa_idx21 to i32*
  store i32 %4, i32* %35, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.7.0..sroa_idx22 = getelementptr inbounds i8, i8* %29, i64 28
  %36 = bitcast i8* %.sroa.7.0..sroa_idx22 to i32*
  store i32 %5, i32* %36, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %37 = getelementptr inbounds i8, i8* %29, i64 32
  store i8 1, i8* %37, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %38 = getelementptr inbounds i8, i8* %29, i64 33
  store i8 0, i8* %38, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  call void @llvm.lifetime.start.p0i8(i64 32, i8* nonnull %.sub28)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(32) %.sub28, i8* noundef nonnull align 16 dereferenceable(32) getelementptr inbounds ([32 x i8], [32 x i8]* @_j_const49, i64 0, i64 0), i64 32, i1 false)
  %status.i16 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub28) #1
  br label %common.ret
}

; Function Attrs: argmemonly nofree nounwind willreturn
declare void @llvm.memcpy.p0i8.p0i8.i64(i8* noalias nocapture writeonly, i8* noalias nocapture readonly, i64, i1 immarg) #0

declare i32 @printf(i8* noalias nocapture, ...) local_unnamed_addr

define internal fastcc i8* @julia_load_sprite_1312u1315(i8* %file) unnamed_addr {
entry:
  %result = call i8* @IMG_Load(i8* %file)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @IMG_Load(i8*) local_unnamed_addr #1

; Function Attrs: nounwind
declare noalias i8* @malloc(i32) local_unnamed_addr #1

; Function Attrs: nounwind
declare i8* @SDL_GetErrorMsg(i8*, i32) local_unnamed_addr #1

; Function Attrs: nounwind
declare void @free(i8*) local_unnamed_addr #1

define internal fastcc i8* @julia_load_sprite_1312u1322(i8* %renderer, i8* %surface) unnamed_addr {
entry:
  %result = call i8* @SDL_CreateTextureFromSurface(i8* %renderer, i8* %surface)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_CreateTextureFromSurface(i8*, i8*) local_unnamed_addr #1

define internal fastcc void @julia_load_sprite_1312u1323(i8* %surface) unnamed_addr {
entry:
  call void @SDL_FreeSurface(i8* %surface)
  ret void
}

; Function Attrs: nounwind
declare void @SDL_FreeSurface(i8*) local_unnamed_addr #1

define i64 @j_init_game_state(i64 zeroext %0, i64 zeroext %1) local_unnamed_addr {
top:
  %2 = alloca [25 x i8], align 16
  %.sub = getelementptr inbounds [25 x i8], [25 x i8]* %2, i64 0, i64 0
  %3 = alloca [7 x i8], align 8
  %.sub106 = getelementptr inbounds [7 x i8], [7 x i8]* %3, i64 0, i64 0
  %4 = alloca [14 x i8], align 16
  %.sub107 = getelementptr inbounds [14 x i8], [14 x i8]* %4, i64 0, i64 0
  %5 = alloca [36 x i8], align 16
  %.sub108 = getelementptr inbounds [36 x i8], [36 x i8]* %5, i64 0, i64 0
  %6 = alloca [27 x i8], align 16
  %.sub109 = getelementptr inbounds [27 x i8], [27 x i8]* %6, i64 0, i64 0
  %7 = alloca [60 x i8], align 16
  %.sub110 = getelementptr inbounds [60 x i8], [60 x i8]* %7, i64 0, i64 0
  %8 = alloca [15 x i8], align 16
  %.sub111 = getelementptr inbounds [15 x i8], [15 x i8]* %8, i64 0, i64 0
  %9 = alloca [53 x i8], align 16
  %.sub112 = getelementptr inbounds [53 x i8], [53 x i8]* %9, i64 0, i64 0
  %10 = alloca [45 x i8], align 16
  %.sub113 = getelementptr inbounds [45 x i8], [45 x i8]* %10, i64 0, i64 0
  %11 = alloca [15 x i8], align 16
  %.sub114 = getelementptr inbounds [15 x i8], [15 x i8]* %11, i64 0, i64 0
  %12 = alloca [34 x i8], align 16
  %.sub115 = getelementptr inbounds [34 x i8], [34 x i8]* %12, i64 0, i64 0
  %13 = alloca [40 x i8], align 16
  %.sub116 = getelementptr inbounds [40 x i8], [40 x i8]* %13, i64 0, i64 0
  %14 = alloca [19 x i8], align 16
  %.sub117 = getelementptr inbounds [19 x i8], [19 x i8]* %14, i64 0, i64 0
  %15 = alloca [49 x i8], align 16
  %.sub118 = getelementptr inbounds [49 x i8], [49 x i8]* %15, i64 0, i64 0
  %16 = alloca [28 x i8], align 16
  %.sub119 = getelementptr inbounds [28 x i8], [28 x i8]* %16, i64 0, i64 0
  %17 = alloca [24 x i8], align 16
  %.sub120 = getelementptr inbounds [24 x i8], [24 x i8]* %17, i64 0, i64 0
  %18 = alloca [23 x i8], align 16
  %.sub121 = getelementptr inbounds [23 x i8], [23 x i8]* %18, i64 0, i64 0
  %19 = alloca [11 x i8], align 16
  %.sub122 = getelementptr inbounds [11 x i8], [11 x i8]* %19, i64 0, i64 0
  %20 = alloca [27 x i8], align 16
  %.sub123 = getelementptr inbounds [27 x i8], [27 x i8]* %20, i64 0, i64 0
  %21 = alloca [11 x i8], align 16
  %.sub124 = getelementptr inbounds [11 x i8], [11 x i8]* %21, i64 0, i64 0
  %.sroa.14 = alloca [7 x i8], align 1
  %.sroa.18 = alloca [7 x i8], align 1
  %.sroa.23 = alloca [5 x i8], align 1
  call void @llvm.lifetime.start.p0i8(i64 25, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(25) %.sub, i8* noundef nonnull align 16 dereferenceable(25) getelementptr inbounds ([25 x i8], [25 x i8]* @_j_const1, i64 0, i64 0), i64 25, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #1
  call void @llvm.lifetime.end.p0i8(i64 25, i8* nonnull %.sub)
  call void @llvm.lifetime.start.p0i8(i64 7, i8* nonnull %.sub106)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 8 dereferenceable(7) %.sub106, i8* noundef nonnull align 1 dereferenceable(7) getelementptr inbounds ([7 x i8], [7 x i8]* @_j_const2, i64 0, i64 0), i64 7, i1 false)
  %status.i52 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub106) #1
  call void @llvm.lifetime.end.p0i8(i64 7, i8* nonnull %.sub106)
  %22 = call fastcc i8* @julia_j_init_game_state_1252u1256()
  call void @llvm.lifetime.start.p0i8(i64 14, i8* nonnull %.sub107)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(14) %.sub107, i8* noundef nonnull align 1 dereferenceable(14) getelementptr inbounds ([14 x i8], [14 x i8]* @_j_const3, i64 0, i64 0), i64 14, i1 false)
  %status.i138 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub107, i8* %22) #1
  call void @llvm.lifetime.end.p0i8(i64 14, i8* nonnull %.sub107)
  %23 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 5)
  %24 = ptrtoint i8* %23 to i64
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(5) %23, i8 0, i64 5, i1 false)
  %25 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 5)
  %26 = ptrtoint i8* %25 to i64
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(5) %25, i8 0, i64 5, i1 false)
  %27 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 5)
  %28 = ptrtoint i8* %27 to i64
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(5) %27, i8 0, i64 5, i1 false)
  %29 = call fastcc i32 @julia_init_sprite_system_1328() #4
  %.not = icmp eq i32 %29, 0
  br i1 %.not, label %L69, label %L62

L62:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 36, i8* nonnull %.sub108)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(36) %.sub108, i8* noundef nonnull align 16 dereferenceable(36) getelementptr inbounds ([36 x i8], [36 x i8]* @_j_const5, i64 0, i64 0), i64 36, i1 false)
  %status.i54 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub108) #1
  br label %L69

L69:                                              ; preds = %L62, %top
  call void @llvm.lifetime.end.p0i8(i64 36, i8* nonnull %.sub108)
  call void @llvm.lifetime.start.p0i8(i64 27, i8* nonnull %.sub109)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(27) %.sub109, i8* noundef nonnull align 16 dereferenceable(27) getelementptr inbounds ([27 x i8], [27 x i8]* @_j_const6, i64 0, i64 0), i64 27, i1 false)
  %status.i56 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub109) #1
  call void @llvm.lifetime.end.p0i8(i64 27, i8* nonnull %.sub109)
  %30 = call fastcc i32 @julia_j_init_game_state_1252u1264(i32 16)
  %31 = and i32 %30, 16
  %.not125 = icmp eq i32 %31, 0
  br i1 %.not125, label %L81, label %L120

L81:                                              ; preds = %L69
  call void @llvm.lifetime.start.p0i8(i64 60, i8* nonnull %.sub110)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(60) %.sub110, i8* noundef nonnull align 16 dereferenceable(60) getelementptr inbounds ([60 x i8], [60 x i8]* @_j_const7, i64 0, i64 0), i64 60, i1 false)
  %status.i58 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub110) #1
  call void @llvm.lifetime.end.p0i8(i64 60, i8* nonnull %.sub110)
  %32 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 256)
  %33 = call fastcc i8* @julia_init_sprite_system_1328u1335(i8* %32, i32 256)
  call void @llvm.lifetime.start.p0i8(i64 15, i8* nonnull %.sub111)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(15) %.sub111, i8* noundef nonnull align 1 dereferenceable(15) getelementptr inbounds ([15 x i8], [15 x i8]* @_j_const8, i64 0, i64 0), i64 15, i1 false)
  %status.i140 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub111, i8* %33) #1
  call void @llvm.lifetime.end.p0i8(i64 15, i8* nonnull %.sub111)
  call fastcc void @julia_init_sprite_system_1328u1337(i8* %32)
  br label %L127

L120:                                             ; preds = %L69
  call void @llvm.lifetime.start.p0i8(i64 53, i8* nonnull %.sub112)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(53) %.sub112, i8* noundef nonnull align 16 dereferenceable(53) getelementptr inbounds ([53 x i8], [53 x i8]* @_j_const43, i64 0, i64 0), i64 53, i1 false)
  %status.i60 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub112) #1
  br label %L127

L127:                                             ; preds = %L120, %L81
  call void @llvm.lifetime.end.p0i8(i64 53, i8* nonnull %.sub112)
  %34 = call fastcc i32 @julia_j_init_game_state_1252u1270(i32 44100, i16 -32752, i32 2, i32 2048)
  %.not126 = icmp eq i32 %34, 0
  br i1 %.not126, label %L197, label %L308

L197:                                             ; preds = %L127
  call void @llvm.lifetime.start.p0i8(i64 34, i8* nonnull %.sub115)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(34) %.sub115, i8* noundef nonnull align 16 dereferenceable(34) getelementptr inbounds ([34 x i8], [34 x i8]* @_j_const42, i64 0, i64 0), i64 34, i1 false)
  %status.i63 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub115) #1
  call void @llvm.lifetime.end.p0i8(i64 34, i8* nonnull %.sub115)
  %35 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 17)
  store i8 47, i8* %35, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %36 = getelementptr i8, i8* %35, i64 1
  store i8 97, i8* %36, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %37 = getelementptr i8, i8* %35, i64 2
  store i8 115, i8* %37, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %38 = getelementptr i8, i8* %35, i64 3
  store i8 115, i8* %38, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %39 = getelementptr i8, i8* %35, i64 4
  store i8 101, i8* %39, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %40 = getelementptr i8, i8* %35, i64 5
  store i8 116, i8* %40, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %41 = getelementptr i8, i8* %35, i64 6
  store i8 115, i8* %41, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %42 = getelementptr i8, i8* %35, i64 7
  store i8 47, i8* %42, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %43 = getelementptr i8, i8* %35, i64 8
  store i8 74, i8* %43, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %44 = getelementptr i8, i8* %35, i64 9
  store i8 117, i8* %44, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %45 = getelementptr i8, i8* %35, i64 10
  store i8 109, i8* %45, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %46 = getelementptr i8, i8* %35, i64 11
  store i8 112, i8* %46, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %47 = getelementptr i8, i8* %35, i64 12
  store i8 46, i8* %47, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %48 = getelementptr i8, i8* %35, i64 13
  store i8 119, i8* %48, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %49 = getelementptr i8, i8* %35, i64 14
  store i8 97, i8* %49, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %50 = getelementptr i8, i8* %35, i64 15
  store i8 118, i8* %50, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %51 = getelementptr i8, i8* %35, i64 16
  store i8 0, i8* %51, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %52 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 17)
  %53 = load i8, i8* %35, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %53, i8* %52, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %54 = getelementptr i8, i8* %52, i64 1
  %55 = load i8, i8* %36, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %55, i8* %54, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %56 = getelementptr i8, i8* %52, i64 2
  %57 = load i8, i8* %37, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %57, i8* %56, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %58 = getelementptr i8, i8* %52, i64 3
  %59 = load i8, i8* %38, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %59, i8* %58, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %60 = getelementptr i8, i8* %52, i64 4
  %61 = load i8, i8* %39, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %61, i8* %60, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %62 = getelementptr i8, i8* %52, i64 5
  %63 = load i8, i8* %40, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %63, i8* %62, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %64 = getelementptr i8, i8* %52, i64 6
  %65 = load i8, i8* %41, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %65, i8* %64, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %66 = getelementptr i8, i8* %52, i64 7
  %67 = load i8, i8* %42, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %67, i8* %66, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %68 = getelementptr i8, i8* %52, i64 8
  %69 = load i8, i8* %43, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %69, i8* %68, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %70 = getelementptr i8, i8* %52, i64 9
  %71 = load i8, i8* %44, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %71, i8* %70, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %72 = getelementptr i8, i8* %52, i64 10
  %73 = load i8, i8* %45, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %73, i8* %72, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %74 = getelementptr i8, i8* %52, i64 11
  %75 = load i8, i8* %46, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %75, i8* %74, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %76 = getelementptr i8, i8* %52, i64 12
  %77 = load i8, i8* %47, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %77, i8* %76, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %78 = getelementptr i8, i8* %52, i64 13
  %79 = load i8, i8* %48, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %79, i8* %78, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %80 = getelementptr i8, i8* %52, i64 14
  %81 = load i8, i8* %49, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %81, i8* %80, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %82 = getelementptr i8, i8* %52, i64 15
  %83 = load i8, i8* %50, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %83, i8* %82, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %84 = getelementptr i8, i8* %52, i64 16
  %85 = load i8, i8* %51, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %85, i8* %84, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %86 = getelementptr i8, i8* %52, i64 17
  store i8 0, i8* %86, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %87 = call fastcc i8* @julia_j_init_game_state_1252u1278(i8* nonnull %52)
  %88 = call fastcc i32 @julia_j_init_game_state_1252u1279(i32 -1, i8* %87, i32 0)
  %89 = icmp sgt i32 %88, -1
  br i1 %89, label %L297, label %L273

L273:                                             ; preds = %L197
  call void @llvm.lifetime.start.p0i8(i64 40, i8* nonnull %.sub116)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(40) %.sub116, i8* noundef nonnull align 16 dereferenceable(40) getelementptr inbounds ([40 x i8], [40 x i8]* @_j_const12, i64 0, i64 0), i64 40, i1 false)
  %status.i65 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub116, i32 %88) #1
  br label %L297

L297:                                             ; preds = %L273, %L197
  call void @llvm.lifetime.end.p0i8(i64 40, i8* nonnull %.sub116)
  call void @llvm.lifetime.start.p0i8(i64 19, i8* nonnull %.sub117)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(19) %.sub117, i8* noundef nonnull align 16 dereferenceable(19) getelementptr inbounds ([19 x i8], [19 x i8]* @_j_const13, i64 0, i64 0), i64 19, i1 false)
  %status.i67 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub117) #1
  call void @llvm.lifetime.end.p0i8(i64 19, i8* nonnull %.sub117)
  call fastcc void @julia_init_sprite_system_1328u1337(i8* nonnull %52)
  br label %L315

L308:                                             ; preds = %L127
  call void @llvm.lifetime.start.p0i8(i64 45, i8* nonnull %.sub113)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(45) %.sub113, i8* noundef nonnull align 16 dereferenceable(45) getelementptr inbounds ([45 x i8], [45 x i8]* @_j_const9, i64 0, i64 0), i64 45, i1 false)
  %status.i61 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub113, i32 %34) #1
  call void @llvm.lifetime.end.p0i8(i64 45, i8* nonnull %.sub113)
  %90 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 256)
  %91 = call fastcc i8* @julia_init_sprite_system_1328u1335(i8* %90, i32 256)
  call void @llvm.lifetime.start.p0i8(i64 15, i8* nonnull %.sub114)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(15) %.sub114, i8* noundef nonnull align 1 dereferenceable(15) getelementptr inbounds ([15 x i8], [15 x i8]* @_j_const8, i64 0, i64 0), i64 15, i1 false)
  %status.i142 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub114, i8* %91) #1
  call void @llvm.lifetime.end.p0i8(i64 15, i8* nonnull %.sub114)
  call fastcc void @julia_init_sprite_system_1328u1337(i8* %90)
  call void @llvm.lifetime.end.p0i8(i64 34, i8* nonnull %.sub115)
  call void @llvm.lifetime.start.p0i8(i64 49, i8* nonnull %.sub118)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(49) %.sub118, i8* noundef nonnull align 16 dereferenceable(49) getelementptr inbounds ([49 x i8], [49 x i8]* @_j_const41, i64 0, i64 0), i64 49, i1 false)
  %status.i69 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub118) #1
  br label %L315

L315:                                             ; preds = %L308, %L297
  call void @llvm.lifetime.end.p0i8(i64 49, i8* nonnull %.sub118)
  call void @llvm.lifetime.start.p0i8(i64 28, i8* nonnull %.sub119)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(28) %.sub119, i8* noundef nonnull align 16 dereferenceable(28) getelementptr inbounds ([28 x i8], [28 x i8]* @_j_const14, i64 0, i64 0), i64 28, i1 false)
  %status.i71 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub119) #1
  call void @llvm.lifetime.end.p0i8(i64 28, i8* nonnull %.sub119)
  %92 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 16)
  %93 = ptrtoint i8* %92 to i64
  %94 = bitcast i8* %92 to i32*
  store i32 120, i32* %94, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %95 = getelementptr i8, i8* %92, i64 4
  %96 = bitcast i8* %95 to i32*
  store i32 360, i32* %96, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %97 = getelementptr i8, i8* %92, i64 8
  %98 = bitcast i8* %97 to i32*
  store i32 8, i32* %98, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %99 = getelementptr i8, i8* %92, i64 12
  %100 = bitcast i8* %99 to i32*
  store i32 8, i32* %100, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %101 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 48)
  %102 = ptrtoint i8* %101 to i64
  %103 = bitcast i8* %101 to i64*
  store i64 %93, i64* %103, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %104 = getelementptr i8, i8* %101, i64 8
  %105 = bitcast i8* %104 to i32*
  store i32 1, i32* %105, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %106 = getelementptr i8, i8* %101, i64 16
  %107 = bitcast i8* %106 to double*
  store double 2.000000e+00, double* %107, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %108 = getelementptr i8, i8* %101, i64 24
  store i8 1, i8* %108, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %109 = getelementptr i8, i8* %101, i64 28
  %110 = bitcast i8* %109 to i32*
  store i32 0, i32* %110, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %111 = getelementptr i8, i8* %101, i64 32
  %112 = bitcast i8* %111 to double*
  store double 0.000000e+00, double* %112, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %113 = getelementptr i8, i8* %101, i64 40
  store i8 0, i8* %113, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %114 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 64)
  %115 = ptrtoint i8* %114 to i64
  %116 = bitcast i8* %114 to i32*
  store i32 16, i32* %116, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %117 = getelementptr i8, i8* %114, i64 4
  %118 = bitcast i8* %117 to i32*
  store i32 368, i32* %118, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %119 = getelementptr i8, i8* %114, i64 8
  %120 = bitcast i8* %119 to i32*
  store i32 8, i32* %120, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %121 = getelementptr i8, i8* %114, i64 12
  %122 = bitcast i8* %121 to i32*
  store i32 8, i32* %122, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %123 = getelementptr i8, i8* %114, i64 16
  %124 = bitcast i8* %123 to i32*
  store i32 24, i32* %124, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %125 = getelementptr i8, i8* %114, i64 20
  %126 = bitcast i8* %125 to i32*
  store i32 368, i32* %126, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %127 = getelementptr i8, i8* %114, i64 24
  %128 = bitcast i8* %127 to i32*
  store i32 8, i32* %128, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %129 = getelementptr i8, i8* %114, i64 28
  %130 = bitcast i8* %129 to i32*
  store i32 8, i32* %130, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %131 = getelementptr i8, i8* %114, i64 32
  %132 = bitcast i8* %131 to i32*
  store i32 32, i32* %132, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %133 = getelementptr i8, i8* %114, i64 36
  %134 = bitcast i8* %133 to i32*
  store i32 368, i32* %134, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %135 = getelementptr i8, i8* %114, i64 40
  %136 = bitcast i8* %135 to i32*
  store i32 8, i32* %136, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %137 = getelementptr i8, i8* %114, i64 44
  %138 = bitcast i8* %137 to i32*
  store i32 8, i32* %138, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %139 = getelementptr i8, i8* %114, i64 48
  %140 = bitcast i8* %139 to i32*
  store i32 40, i32* %140, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %141 = getelementptr i8, i8* %114, i64 52
  %142 = bitcast i8* %141 to i32*
  store i32 368, i32* %142, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %143 = getelementptr i8, i8* %114, i64 56
  %144 = bitcast i8* %143 to i32*
  store i32 8, i32* %144, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %145 = getelementptr i8, i8* %114, i64 60
  %146 = bitcast i8* %145 to i32*
  store i32 8, i32* %146, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %147 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 48)
  %148 = ptrtoint i8* %147 to i64
  %149 = bitcast i8* %147 to i64*
  store i64 %115, i64* %149, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %150 = getelementptr i8, i8* %147, i64 8
  %151 = bitcast i8* %150 to i32*
  store i32 4, i32* %151, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %152 = getelementptr i8, i8* %147, i64 16
  %153 = bitcast i8* %152 to double*
  store double 8.000000e+00, double* %153, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %154 = getelementptr i8, i8* %147, i64 24
  store i8 1, i8* %154, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %155 = getelementptr i8, i8* %147, i64 28
  %156 = bitcast i8* %155 to i32*
  store i32 0, i32* %156, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %157 = getelementptr i8, i8* %147, i64 32
  %158 = bitcast i8* %157 to double*
  store double 0.000000e+00, double* %158, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %159 = getelementptr i8, i8* %147, i64 40
  store i8 0, i8* %159, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %160 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 16)
  %161 = ptrtoint i8* %160 to i64
  %162 = bitcast i8* %160 to i32*
  store i32 8, i32* %162, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %163 = getelementptr i8, i8* %160, i64 4
  %164 = bitcast i8* %163 to i32*
  store i32 368, i32* %164, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %165 = getelementptr i8, i8* %160, i64 8
  %166 = bitcast i8* %165 to i32*
  store i32 8, i32* %166, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %167 = getelementptr i8, i8* %160, i64 12
  %168 = bitcast i8* %167 to i32*
  store i32 8, i32* %168, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %169 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 48)
  %170 = ptrtoint i8* %169 to i64
  %171 = bitcast i8* %169 to i64*
  store i64 %161, i64* %171, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %172 = getelementptr i8, i8* %169, i64 8
  %173 = bitcast i8* %172 to i32*
  store i32 1, i32* %173, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %174 = getelementptr i8, i8* %169, i64 16
  %175 = bitcast i8* %174 to double*
  store double 1.000000e+00, double* %175, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %176 = getelementptr i8, i8* %169, i64 24
  store i8 0, i8* %176, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %177 = getelementptr i8, i8* %169, i64 28
  %178 = bitcast i8* %177 to i32*
  store i32 0, i32* %178, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %179 = getelementptr i8, i8* %169, i64 32
  %180 = bitcast i8* %179 to double*
  store double 0.000000e+00, double* %180, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %181 = getelementptr i8, i8* %169, i64 40
  store i8 0, i8* %181, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %182 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 208)
  %.sroa.0.0..sroa_idx = bitcast i8* %182 to double*
  store double 5.000000e+02, double* %.sroa.0.0..sroa_idx, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.2.0..sroa_idx78 = getelementptr inbounds i8, i8* %182, i64 8
  %183 = bitcast i8* %.sroa.2.0..sroa_idx78 to double*
  store double 6.680000e+02, double* %183, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.3.0..sroa_idx79 = getelementptr inbounds i8, i8* %182, i64 16
  %.sroa.5.0..sroa_idx81 = getelementptr inbounds i8, i8* %182, i64 32
  %184 = bitcast i8* %.sroa.5.0..sroa_idx81 to i32*
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(16) %.sroa.3.0..sroa_idx79, i8 0, i64 16, i1 false)
  store i32 1, i32* %184, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.682.0..sroa_idx83 = getelementptr inbounds i8, i8* %182, i64 40
  %.sroa.986.0..sroa_idx87 = getelementptr inbounds i8, i8* %182, i64 64
  %185 = bitcast i8* %.sroa.986.0..sroa_idx87 to i64*
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(20) %.sroa.682.0..sroa_idx83, i8 0, i64 20, i1 false)
  store i64 %26, i64* %185, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.10.0..sroa_idx88 = getelementptr inbounds i8, i8* %182, i64 72
  %186 = bitcast i8* %.sroa.10.0..sroa_idx88 to i64*
  store i64 %24, i64* %186, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.11.0..sroa_idx89 = getelementptr inbounds i8, i8* %182, i64 80
  %187 = bitcast i8* %.sroa.11.0..sroa_idx89 to i64*
  store i64 %28, i64* %187, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.12.0..sroa_idx90 = getelementptr inbounds i8, i8* %182, i64 88
  %188 = bitcast i8* %.sroa.12.0..sroa_idx90 to i64*
  store i64 0, i64* %188, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %189 = getelementptr inbounds i8, i8* %182, i64 96
  store i8 0, i8* %189, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.14.0..sroa_raw_idx = getelementptr inbounds i8, i8* %182, i64 97
  %.sroa.14.0.sroa_idx = getelementptr inbounds [7 x i8], [7 x i8]* %.sroa.14, i64 0, i64 0
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(7) %.sroa.14.0..sroa_raw_idx, i8* noundef nonnull align 1 dereferenceable(7) %.sroa.14.0.sroa_idx, i64 7, i1 false), !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.1491.0..sroa_idx92 = getelementptr inbounds i8, i8* %182, i64 104
  %190 = bitcast i8* %.sroa.1491.0..sroa_idx92 to i64*
  %.sroa.15.0..sroa_idx93 = getelementptr inbounds i8, i8* %182, i64 112
  %191 = bitcast i8* %.sroa.15.0..sroa_idx93 to i64*
  %192 = getelementptr inbounds i8, i8* %182, i64 128
  call void @llvm.memset.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(24) %.sroa.1491.0..sroa_idx92, i8 0, i64 24, i1 false)
  store i8 1, i8* %192, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.18.0..sroa_raw_idx = getelementptr inbounds i8, i8* %182, i64 129
  %.sroa.18.0.sroa_idx = getelementptr inbounds [7 x i8], [7 x i8]* %.sroa.18, i64 0, i64 0
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(7) %.sroa.18.0..sroa_raw_idx, i8* noundef nonnull align 1 dereferenceable(7) %.sroa.18.0.sroa_idx, i64 7, i1 false), !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.1895.0..sroa_idx96 = getelementptr inbounds i8, i8* %182, i64 136
  %193 = bitcast i8* %.sroa.1895.0..sroa_idx96 to double*
  store double 3.000000e+02, double* %193, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.19.0..sroa_idx97 = getelementptr inbounds i8, i8* %182, i64 144
  %194 = bitcast i8* %.sroa.19.0..sroa_idx97 to double*
  store double 2.200000e+02, double* %194, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %195 = getelementptr inbounds i8, i8* %182, i64 152
  store i8 0, i8* %195, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %196 = getelementptr inbounds i8, i8* %182, i64 153
  store i8 0, i8* %196, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %197 = getelementptr inbounds i8, i8* %182, i64 154
  store i8 0, i8* %197, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.23.0..sroa_raw_idx = getelementptr inbounds i8, i8* %182, i64 155
  %.sroa.23.0.sroa_idx = getelementptr inbounds [5 x i8], [5 x i8]* %.sroa.23, i64 0, i64 0
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 1 dereferenceable(5) %.sroa.23.0..sroa_raw_idx, i8* noundef nonnull align 1 dereferenceable(5) %.sroa.23.0.sroa_idx, i64 5, i1 false), !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.2398.0..sroa_idx99 = getelementptr inbounds i8, i8* %182, i64 160
  %198 = bitcast i8* %.sroa.2398.0..sroa_idx99 to i64*
  store i64 %102, i64* %198, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.24.0..sroa_idx100 = getelementptr inbounds i8, i8* %182, i64 168
  %199 = bitcast i8* %.sroa.24.0..sroa_idx100 to i64*
  store i64 %148, i64* %199, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.25.0..sroa_idx101 = getelementptr inbounds i8, i8* %182, i64 176
  %200 = bitcast i8* %.sroa.25.0..sroa_idx101 to i64*
  store i64 %170, i64* %200, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.26.0..sroa_idx102 = getelementptr inbounds i8, i8* %182, i64 184
  %201 = bitcast i8* %.sroa.26.0..sroa_idx102 to i64*
  store i64 %102, i64* %201, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.27.0..sroa_idx103 = getelementptr inbounds i8, i8* %182, i64 192
  %202 = bitcast i8* %.sroa.27.0..sroa_idx103 to i32*
  store i32 0, i32* %202, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  %.sroa.28104.0..sroa_idx105 = getelementptr inbounds i8, i8* %182, i64 200
  %203 = bitcast i8* %.sroa.28104.0..sroa_idx105 to i64*
  store i64 0, i64* %203, align 1, !tbaa !14, !alias.scope !15, !noalias !16
  call void @llvm.lifetime.start.p0i8(i64 24, i8* nonnull %.sub120)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(24) %.sub120, i8* noundef nonnull align 16 dereferenceable(24) getelementptr inbounds ([24 x i8], [24 x i8]* @_j_const35, i64 0, i64 0), i64 24, i1 false)
  %status.i73 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub120) #1
  store i64 0, i64* %188, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 0, i8* %189, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %204 = load i64, i64* %190, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not129 = icmp eq i64 %204, 0
  br i1 %.not129, label %L621, label %L747

L621:                                             ; preds = %L315
  call void @llvm.lifetime.end.p0i8(i64 24, i8* nonnull %.sub120)
  call void @llvm.lifetime.start.p0i8(i64 23, i8* nonnull %.sub121)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(23) %.sub121, i8* noundef nonnull align 16 dereferenceable(23) getelementptr inbounds ([23 x i8], [23 x i8]* @_j_const36, i64 0, i64 0), i64 23, i1 false)
  %status.i75 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub121) #1
  call void @llvm.lifetime.end.p0i8(i64 23, i8* nonnull %.sub121)
  %205 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 16)
  store i8 97, i8* %205, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %206 = getelementptr i8, i8* %205, i64 1
  store i8 115, i8* %206, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %207 = getelementptr i8, i8* %205, i64 2
  store i8 115, i8* %207, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %208 = getelementptr i8, i8* %205, i64 3
  store i8 101, i8* %208, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %209 = getelementptr i8, i8* %205, i64 4
  store i8 116, i8* %209, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %210 = getelementptr i8, i8* %205, i64 5
  store i8 115, i8* %210, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %211 = getelementptr i8, i8* %205, i64 6
  store i8 47, i8* %211, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %212 = getelementptr i8, i8* %205, i64 7
  store i8 103, i8* %212, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %213 = getelementptr i8, i8* %205, i64 8
  store i8 97, i8* %213, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %214 = getelementptr i8, i8* %205, i64 9
  store i8 109, i8* %214, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %215 = getelementptr i8, i8* %205, i64 10
  store i8 101, i8* %215, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %216 = getelementptr i8, i8* %205, i64 11
  store i8 46, i8* %216, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %217 = getelementptr i8, i8* %205, i64 12
  store i8 112, i8* %217, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %218 = getelementptr i8, i8* %205, i64 13
  store i8 110, i8* %218, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %219 = getelementptr i8, i8* %205, i64 14
  store i8 103, i8* %219, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %220 = getelementptr i8, i8* %205, i64 15
  store i8 0, i8* %220, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %221 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 16)
  %222 = load i8, i8* %205, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %222, i8* %221, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %223 = getelementptr i8, i8* %221, i64 1
  %224 = load i8, i8* %206, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %224, i8* %223, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %225 = getelementptr i8, i8* %221, i64 2
  %226 = load i8, i8* %207, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %226, i8* %225, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %227 = getelementptr i8, i8* %221, i64 3
  %228 = load i8, i8* %208, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %228, i8* %227, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %229 = getelementptr i8, i8* %221, i64 4
  %230 = load i8, i8* %209, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %230, i8* %229, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %231 = getelementptr i8, i8* %221, i64 5
  %232 = load i8, i8* %210, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %232, i8* %231, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %233 = getelementptr i8, i8* %221, i64 6
  %234 = load i8, i8* %211, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %234, i8* %233, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %235 = getelementptr i8, i8* %221, i64 7
  %236 = load i8, i8* %212, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %236, i8* %235, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %237 = getelementptr i8, i8* %221, i64 8
  %238 = load i8, i8* %213, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %238, i8* %237, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %239 = getelementptr i8, i8* %221, i64 9
  %240 = load i8, i8* %214, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %240, i8* %239, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %241 = getelementptr i8, i8* %221, i64 10
  %242 = load i8, i8* %215, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %242, i8* %241, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %243 = getelementptr i8, i8* %221, i64 11
  %244 = load i8, i8* %216, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %244, i8* %243, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %245 = getelementptr i8, i8* %221, i64 12
  %246 = load i8, i8* %217, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %246, i8* %245, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %247 = getelementptr i8, i8* %221, i64 13
  %248 = load i8, i8* %218, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %248, i8* %247, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %249 = getelementptr i8, i8* %221, i64 14
  %250 = load i8, i8* %219, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %250, i8* %249, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %251 = getelementptr i8, i8* %221, i64 15
  %252 = load i8, i8* %220, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %252, i8* %251, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %253 = ptrtoint i8* %221 to i64
  %254 = getelementptr i8, i8* %221, i64 16
  store i8 0, i8* %254, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %255 = call fastcc i64 @load_sprite_1312(i64 zeroext %0, i64 zeroext %253, i32 signext 120, i32 signext 360, i32 signext 8, i32 signext 8, i32 signext 64, i32 signext 64) #4
  store i64 %255, i64* %190, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  call fastcc void @julia_init_sprite_system_1328u1337(i8* nonnull %221)
  %256 = load i64, i64* %190, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not132 = icmp eq i64 %256, 0
  br i1 %.not132, label %L716, label %L747

L716:                                             ; preds = %L621
  %257 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 100)
  %258 = call fastcc i8* @julia_init_sprite_system_1328u1335(i8* %257, i32 100)
  call void @llvm.lifetime.start.p0i8(i64 11, i8* nonnull %.sub122)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(11) %.sub122, i8* noundef nonnull align 1 dereferenceable(11) getelementptr inbounds ([11 x i8], [11 x i8]* @_j_const38, i64 0, i64 0), i64 11, i1 false)
  %status.i144 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub122, i8* %258) #1
  call void @llvm.lifetime.end.p0i8(i64 11, i8* nonnull %.sub122)
  call fastcc void @julia_init_sprite_system_1328u1337(i8* %257)
  br label %L747

L747:                                             ; preds = %L716, %L621, %L315
  %259 = load i64, i64* %191, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not133 = icmp eq i64 %259, 0
  br i1 %.not133, label %L756, label %L882

L756:                                             ; preds = %L747
  call void @llvm.lifetime.end.p0i8(i64 24, i8* nonnull %.sub120)
  call void @llvm.lifetime.start.p0i8(i64 27, i8* nonnull %.sub123)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(27) %.sub123, i8* noundef nonnull align 16 dereferenceable(27) getelementptr inbounds ([27 x i8], [27 x i8]* @_j_const39, i64 0, i64 0), i64 27, i1 false)
  %status.i77 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub123) #1
  call void @llvm.lifetime.end.p0i8(i64 27, i8* nonnull %.sub123)
  %260 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 15)
  store i8 97, i8* %260, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %261 = getelementptr i8, i8* %260, i64 1
  store i8 115, i8* %261, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %262 = getelementptr i8, i8* %260, i64 2
  store i8 115, i8* %262, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %263 = getelementptr i8, i8* %260, i64 3
  store i8 101, i8* %263, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %264 = getelementptr i8, i8* %260, i64 4
  store i8 116, i8* %264, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %265 = getelementptr i8, i8* %260, i64 5
  store i8 115, i8* %265, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %266 = getelementptr i8, i8* %260, i64 6
  store i8 47, i8* %266, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %267 = getelementptr i8, i8* %260, i64 7
  store i8 109, i8* %267, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %268 = getelementptr i8, i8* %260, i64 8
  store i8 97, i8* %268, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %269 = getelementptr i8, i8* %260, i64 9
  store i8 112, i8* %269, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %270 = getelementptr i8, i8* %260, i64 10
  store i8 46, i8* %270, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %271 = getelementptr i8, i8* %260, i64 11
  store i8 112, i8* %271, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %272 = getelementptr i8, i8* %260, i64 12
  store i8 110, i8* %272, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %273 = getelementptr i8, i8* %260, i64 13
  store i8 103, i8* %273, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %274 = getelementptr i8, i8* %260, i64 14
  store i8 0, i8* %274, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %275 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 15)
  %276 = load i8, i8* %260, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %276, i8* %275, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %277 = getelementptr i8, i8* %275, i64 1
  %278 = load i8, i8* %261, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %278, i8* %277, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %279 = getelementptr i8, i8* %275, i64 2
  %280 = load i8, i8* %262, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %280, i8* %279, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %281 = getelementptr i8, i8* %275, i64 3
  %282 = load i8, i8* %263, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %282, i8* %281, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %283 = getelementptr i8, i8* %275, i64 4
  %284 = load i8, i8* %264, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %284, i8* %283, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %285 = getelementptr i8, i8* %275, i64 5
  %286 = load i8, i8* %265, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %286, i8* %285, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %287 = getelementptr i8, i8* %275, i64 6
  %288 = load i8, i8* %266, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %288, i8* %287, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %289 = getelementptr i8, i8* %275, i64 7
  %290 = load i8, i8* %267, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %290, i8* %289, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %291 = getelementptr i8, i8* %275, i64 8
  %292 = load i8, i8* %268, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %292, i8* %291, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %293 = getelementptr i8, i8* %275, i64 9
  %294 = load i8, i8* %269, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %294, i8* %293, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %295 = getelementptr i8, i8* %275, i64 10
  %296 = load i8, i8* %270, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %296, i8* %295, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %297 = getelementptr i8, i8* %275, i64 11
  %298 = load i8, i8* %271, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %298, i8* %297, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %299 = getelementptr i8, i8* %275, i64 12
  %300 = load i8, i8* %272, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %300, i8* %299, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %301 = getelementptr i8, i8* %275, i64 13
  %302 = load i8, i8* %273, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %302, i8* %301, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %303 = getelementptr i8, i8* %275, i64 14
  %304 = load i8, i8* %274, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  store i8 %304, i8* %303, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %305 = ptrtoint i8* %275 to i64
  %306 = getelementptr i8, i8* %275, i64 15
  store i8 0, i8* %306, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %307 = call fastcc i64 @load_sprite_1312(i64 zeroext %0, i64 zeroext %305, i32 signext 0, i32 signext 0, i32 signext 640, i32 signext 640, i32 signext 640, i32 signext 640) #4
  store i64 %307, i64* %191, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  call fastcc void @julia_init_sprite_system_1328u1337(i8* nonnull %275)
  %308 = load i64, i64* %191, align 1, !tbaa !2, !alias.scope !6, !noalias !9
  %.not136 = icmp eq i64 %308, 0
  br i1 %.not136, label %L851, label %L882

L851:                                             ; preds = %L756
  %309 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 100)
  %310 = call fastcc i8* @julia_init_sprite_system_1328u1335(i8* %309, i32 100)
  call void @llvm.lifetime.start.p0i8(i64 11, i8* nonnull %.sub124)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(11) %.sub124, i8* noundef nonnull align 1 dereferenceable(11) getelementptr inbounds ([11 x i8], [11 x i8]* @_j_const38, i64 0, i64 0), i64 11, i1 false)
  %status.i146 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub124, i8* %310) #1
  call void @llvm.lifetime.end.p0i8(i64 11, i8* nonnull %.sub124)
  call fastcc void @julia_init_sprite_system_1328u1337(i8* %309)
  br label %L882

L882:                                             ; preds = %L851, %L756, %L747
  %311 = ptrtoint i8* %182 to i64
  ret i64 %311
}

define internal fastcc i8* @julia_j_init_game_state_1252u1256() unnamed_addr {
entry:
  %result = call i8* @SDL_GetPlatform()
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @SDL_GetPlatform() local_unnamed_addr #1

define internal fastcc i32 @julia_j_init_game_state_1252u1264(i32 %flags) unnamed_addr {
entry:
  %result = call i32 @Mix_Init(i32 %flags)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @Mix_Init(i32) local_unnamed_addr #1

define internal fastcc i32 @julia_j_init_game_state_1252u1270(i32 %frequency, i16 %format, i32 %channels, i32 %chunksize) unnamed_addr {
entry:
  %result = call i32 @Mix_OpenAudio(i32 %frequency, i16 %format, i32 %channels, i32 %chunksize)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @Mix_OpenAudio(i32, i16, i32, i32) local_unnamed_addr #1

define internal fastcc i8* @julia_j_init_game_state_1252u1278(i8* %file) unnamed_addr {
entry:
  %result = call i8* @Mix_LoadWAV(i8* %file)
  ret i8* %result
}

; Function Attrs: nounwind
declare i8* @Mix_LoadWAV(i8*) local_unnamed_addr #1

define internal fastcc i32 @julia_j_init_game_state_1252u1279(i32 %channel, i8* %chunk, i32 %loops) unnamed_addr {
entry:
  %result = call i32 @Mix_PlayChannel(i32 %channel, i8* %chunk, i32 %loops)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @Mix_PlayChannel(i32, i8*, i32) local_unnamed_addr #1

define internal fastcc i32 @julia_init_sprite_system_1328() unnamed_addr {
top:
  %0 = alloca [28 x i8], align 16
  %.sub = getelementptr inbounds [28 x i8], [28 x i8]* %0, i64 0, i64 0
  %1 = alloca [52 x i8], align 16
  %.sub11 = getelementptr inbounds [52 x i8], [52 x i8]* %1, i64 0, i64 0
  %2 = alloca [61 x i8], align 16
  %.sub12 = getelementptr inbounds [61 x i8], [61 x i8]* %2, i64 0, i64 0
  %3 = alloca [15 x i8], align 16
  %.sub13 = getelementptr inbounds [15 x i8], [15 x i8]* %3, i64 0, i64 0
  %4 = alloca [40 x i8], align 16
  %.sub14 = getelementptr inbounds [40 x i8], [40 x i8]* %4, i64 0, i64 0
  call void @llvm.lifetime.start.p0i8(i64 28, i8* nonnull %.sub)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(28) %.sub, i8* noundef nonnull align 16 dereferenceable(28) getelementptr inbounds ([28 x i8], [28 x i8]* @_j_const50, i64 0, i64 0), i64 28, i1 false)
  %status.i = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub) #1
  call void @llvm.lifetime.end.p0i8(i64 28, i8* nonnull %.sub)
  %5 = call fastcc i32 @julia_init_sprite_system_1328u1331(i32 2)
  call void @llvm.lifetime.start.p0i8(i64 52, i8* nonnull %.sub11)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(52) %.sub11, i8* noundef nonnull align 16 dereferenceable(52) getelementptr inbounds ([52 x i8], [52 x i8]* @_j_const51, i64 0, i64 0), i64 52, i1 false)
  %status.i6 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub11, i32 %5) #1
  %6 = and i32 %5, 2
  %.not = icmp eq i32 %6, 0
  call void @llvm.lifetime.end.p0i8(i64 52, i8* nonnull %.sub11)
  br i1 %.not, label %L37, label %L76

common.ret:                                       ; preds = %L76, %L37
  %common.ret.op = phi i32 [ -1, %L37 ], [ 0, %L76 ]
  call void @llvm.lifetime.end.p0i8(i64 40, i8* nonnull %.sub14)
  ret i32 %common.ret.op

L37:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 61, i8* nonnull %.sub12)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(61) %.sub12, i8* noundef nonnull align 16 dereferenceable(61) getelementptr inbounds ([61 x i8], [61 x i8]* @_j_const52, i64 0, i64 0), i64 61, i1 false)
  %status.i8 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub12) #1
  call void @llvm.lifetime.end.p0i8(i64 61, i8* nonnull %.sub12)
  %7 = call fastcc i8* @julia_init_sprite_system_1328u1334(i32 1024)
  %8 = call fastcc i8* @julia_init_sprite_system_1328u1335(i8* %7, i32 1024)
  call void @llvm.lifetime.start.p0i8(i64 15, i8* nonnull %.sub13)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(15) %.sub13, i8* noundef nonnull align 1 dereferenceable(15) getelementptr inbounds ([15 x i8], [15 x i8]* @_j_const8, i64 0, i64 0), i64 15, i1 false)
  %status.i16 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub13, i8* %8) #1
  call void @llvm.lifetime.end.p0i8(i64 15, i8* nonnull %.sub13)
  call fastcc void @julia_init_sprite_system_1328u1337(i8* %7)
  br label %common.ret

L76:                                              ; preds = %top
  call void @llvm.lifetime.start.p0i8(i64 40, i8* nonnull %.sub14)
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(40) %.sub14, i8* noundef nonnull align 16 dereferenceable(40) getelementptr inbounds ([40 x i8], [40 x i8]* @_j_const53, i64 0, i64 0), i64 40, i1 false)
  %status.i10 = call i32 (i8*, ...) @printf(i8* noundef nonnull %.sub14) #1
  br label %common.ret
}

define internal fastcc i32 @julia_init_sprite_system_1328u1331(i32 %flags) unnamed_addr {
entry:
  %result = call i32 @IMG_Init(i32 %flags)
  ret i32 %result
}

; Function Attrs: nounwind
declare i32 @IMG_Init(i32) local_unnamed_addr #1

define internal fastcc i8* @julia_init_sprite_system_1328u1334(i32 %size) unnamed_addr {
entry:
  %ptr = call noalias i8* @malloc(i32 %size)
  ret i8* %ptr
}

define internal fastcc i8* @julia_init_sprite_system_1328u1335(i8* %errstr, i32 %maxlen) unnamed_addr {
entry:
  %result = call i8* @SDL_GetErrorMsg(i8* %errstr, i32 %maxlen)
  ret i8* %result
}

define internal fastcc void @julia_init_sprite_system_1328u1337(i8* %ptr) unnamed_addr {
entry:
  call void @free(i8* %ptr)
  ret void
}

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0i8(i64 immarg, i8* nocapture) #2

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0i8(i64 immarg, i8* nocapture) #2

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #3

attributes #0 = { argmemonly nofree nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { argmemonly nofree nosync nounwind willreturn }
attributes #3 = { argmemonly nofree nounwind willreturn writeonly }
attributes #4 = { "probe-stack"="inline-asm" }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = !{!3, !3, i64 0}
!3 = !{!"jtbaa_data", !4, i64 0}
!4 = !{!"jtbaa", !5, i64 0}
!5 = !{!"jtbaa"}
!6 = !{!7}
!7 = !{!"jnoalias_data", !8}
!8 = !{!"jnoalias"}
!9 = !{!10, !11, !12, !13}
!10 = !{!"jnoalias_gcframe", !8}
!11 = !{!"jnoalias_stack", !8}
!12 = !{!"jnoalias_typemd", !8}
!13 = !{!"jnoalias_const", !8}
!14 = !{!4, !4, i64 0}
!15 = !{!11, !7}
!16 = !{!10, !12, !13}
